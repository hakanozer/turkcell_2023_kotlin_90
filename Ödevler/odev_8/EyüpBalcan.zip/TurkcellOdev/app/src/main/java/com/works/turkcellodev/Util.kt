import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.widget.ProgressBar
import androidx.core.content.ContextCompat
import com.works.turkcellodev.R

fun placeholderProgressBar(context: Context): ProgressBar {
    val progressBar = ProgressBar(context, null, android.R.attr.progressBarStyleSmall)
    progressBar.isIndeterminate = true
    progressBar.indeterminateDrawable = createCircularProgressDrawable(context)

    return progressBar
}

private fun createCircularProgressDrawable(context: Context): GradientDrawable {
    val color = ContextCompat.getColor(context, R.color.colorAccent)
    val gradientDrawable = GradientDrawable()
    gradientDrawable.shape = GradientDrawable.OVAL
    gradientDrawable.setSize(40.dpToPx(context), 40.dpToPx(context))
    gradientDrawable.setColor(color)
    return gradientDrawable
}

private fun Int.dpToPx(context: Context): Int {
    val scale = context.resources.displayMetrics.density
    return (this * scale + 0.5f).toInt()
}
