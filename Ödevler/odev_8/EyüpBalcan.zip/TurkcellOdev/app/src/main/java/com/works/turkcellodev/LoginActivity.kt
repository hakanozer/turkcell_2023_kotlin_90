package com.works.turkcellodev


import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

    private lateinit var dummyService: DummyService
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var sharedEditor: SharedPreferences.Editor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val usernameEditText: EditText = findViewById(R.id.girisKullaniciAdi)
        val passwordEditText: EditText = findViewById(R.id.girisParola)
        val loginButton: Button = findViewById(R.id.btnGirisYap)

        dummyService = ApiClient.getClient().create(DummyService::class.java)

        sharedPreferences = getSharedPreferences("userdata", MODE_PRIVATE)
        sharedEditor = sharedPreferences.edit()

        loginButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()
            //val userSend = UserSend("kminchelle", "0lelplR")


            if (username.isNotEmpty() && password.isNotEmpty()) {
                // Retrofit ile login işlemi
                val userSend = UserSend(username, password)
                dummyService.login(userSend).enqueue(object : Callback<UserModel> {
                    override fun onResponse(call: Call<UserModel>, response: Response<UserModel>) {
                        if (response.isSuccessful) {
                            val userModel = response.body()

                            sharedEditor.putString("token", userModel?.token)
                            sharedEditor.apply()

                            val intent = Intent(this@LoginActivity, MainActivity::class.java)
                            startActivity(intent)
                            finish()
                        } else {

                            val errorMessage = when (response.code()) {
                                401 -> "Kullanıcı adı veya şifre hatalı."
                                403 -> "Yetkisiz erişim."
                                else -> "Bir hata oluştu. Lütfen tekrar deneyin."
                            }
                            Toast.makeText(this@LoginActivity, errorMessage, Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<UserModel>, t: Throwable) {

                        Toast.makeText(this@LoginActivity, "Bağlantı hatası. Lütfen internet bağlantınızı kontrol edin.", Toast.LENGTH_SHORT).show()
                    }
                })
            } else {

                Toast.makeText(this@LoginActivity, "Kullanıcı adı ve şifre boş olamaz!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
