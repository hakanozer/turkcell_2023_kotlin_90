package com.works.turkcellodev


import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface DummyService {

    @POST("auth/login")
    fun login( @Body userSend: UserSend) : Call<UserModel>


    @GET("products?limit=10")
    fun allProducts() : Call<Products>

    @GET("products/search")
    fun filterProducts(@Query("q") keyword:String):Call<Products>
}