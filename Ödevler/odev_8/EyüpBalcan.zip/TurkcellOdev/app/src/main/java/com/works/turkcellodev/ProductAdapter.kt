import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.works.turkcellodev.Product
import com.works.turkcellodev.R

class ProductAdapter(private var productList: List<Product>) : RecyclerView.Adapter<ProductAdapter.ViewHolder>() {



    private var filteredList: List<Product> = productList

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_view, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return filteredList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val product = productList[position]

        holder.apply {
            productName.text = product.title
            productPrice.text = product.price.toString()

            Picasso.get()
                .load(product.images.firstOrNull()).into(productImage)
        }



    }
    fun setProducts(products: List<Product>) {
        productList = products
        notifyDataSetChanged()
    }

    fun filter(query: String?) {
        query?.let {
            filteredList = productList.filter { product ->
                product.title?.contains(it, ignoreCase = true) ?: false
            }
        } ?: run {
            filteredList = productList
        }

        notifyDataSetChanged()
    }



    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val productImage: ImageView = view.findViewById(R.id.imageViewProduct)
        val productName: TextView = view.findViewById(R.id.textName)
        val productPrice: TextView = view.findViewById(R.id.textPrice)
    }
}
