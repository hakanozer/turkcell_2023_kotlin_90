package com.works.turkcellodev

data class UserSend(
    val username: String,
    val password: String
)
