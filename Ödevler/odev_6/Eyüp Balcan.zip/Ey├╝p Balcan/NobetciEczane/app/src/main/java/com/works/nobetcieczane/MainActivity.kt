package com.works.nobetcieczane

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

            val eczResult = EczaneResult()
            val result = eczResult.gaziAntep()

            result.forEach { (ilceler, eczaneler) ->
                println("İlçe: $ilceler")
                eczaneler.forEach { eczaneler ->
                    println("Eczane: $eczaneler")
                }
            }

            runOnUiThread {
                val eczaneList = result.flatMap { it.value }.toTypedArray()
                val adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, eczaneList)
                val listView = findViewById<ListView>(R.id.eczane_list)
                listView.adapter = adapter
            }

    }
}
