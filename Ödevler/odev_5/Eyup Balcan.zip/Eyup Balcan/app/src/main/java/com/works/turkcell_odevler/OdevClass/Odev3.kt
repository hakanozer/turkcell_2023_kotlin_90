package com.works.turkcell_odevler.OdevClass

import java.io.File
import java.io.FileWriter
import java.io.PrintWriter
import kotlin.random.Random

class Odev3 {

    fun newFile(path: String, dosyaAdi: String): File? {
        try {
            val dosyaYolu = File(path, dosyaAdi)

            if (dosyaYolu.createNewFile()) {
                println("$dosyaAdi dosyası başarıyla $path dizininde oluşturuldu.")
                return dosyaYolu
            } else {
                println("$dosyaAdi dosyası zaten $path dizininde mevcut.")
            }
        } catch (e: Exception) {
            println("Dosya oluşturma hatası")
        }
        return null
    }
    /*
    Soru-1 : Notepad++ İle Bir Dosya Oluşturun
    İçine 15 Tane Sayı Yazın (Arada Pozitif, Negatif Sayılarda Olsun)

    Uygulamanıza Bu Dosyanın Yolunu Vereceksiniz.Uygulamanız Ekrana
    Dosyada Kaç Tane :
    - Pozitif
    - Negatif
    - Tek
    - Çift Sayı Olduğunu Bastıracak.
     */
    val file = "C:\\Users\\balca\\Desktop\\KotlinSayilar.txt"
    val files = File(file)

    fun soru1(){
        println("Soru1")
        var positive = 0
        var negative = 0
        var evenNumber =0
        var oddNumber =0
        val fileRead = files.readLines()
        for (i in fileRead){
            try {
                val number = i.toInt()

                if (number > 0) positive++
                if (number < 0) negative++
                if (number % 2 == 0) evenNumber++
                else oddNumber++
            } catch (e: NumberFormatException) {
                println("Değerlerin hepsini sayı giriniz. ")
            }


        }
        println("""        
        -Pozitif Sayisi $positive
        -Negatif Sayisi $negative
        -Tek Sayi $oddNumber
        -Cift Sayi $evenNumber        
    """.trimIndent())
        println("--------------------------")

    }

    //2.Soru  1. Sorudaki Dosyayı -1000, +1000 Arası 500 Tane Random Sayıyla Dolduran Bir Uygulama Yazın.

    fun soru2() {
        println("Soru2")
        val numberOfRandomNumbers = 500
        //dosya yolunu temizledim
        (files).writeText("")

        try {
            FileWriter(files, true).use { writer -> // "true" dosyanın sonuna eklemek için kullanılır eğer dosya yoksa oluşturu
                //use writer FileWriter'ı otomatik kapatır.
                for (i in 1..numberOfRandomNumbers) {
                    val randomNumber = Random.nextInt(-1000, 1000)
                    writer.write("$randomNumber\n")
                    println(randomNumber)
                }
            }
            println("Rastgele sayılar dosyaya başarıyla yazıldı.")
        } catch (e: Exception) {
            println("Dosya yazma hatası")

        }
        println("--------------------------")

    }
    /* 3.Soru
    2. Soruda Oluşturduğunuz Dosyayı Açıp Okuyan, Input Dosyasının Bulunduğu Klasore
    C.txt Adında Bir Dosya Oluşturup, Input Dosyasının İçindeki Cift Sayıları Yazan,
    T.txt Adında Bir Dosya Olusturup, Tek Sayıları Yazan Bir Uygulama Yazın
    */

    fun soru3(){
        var path = "C:\\Users\\balca\\Desktop\\"
        val tdosyaAdi = "T.txt"
        val cdosyaAdi = "C.txt"
        try {
            val fileRead = files.readLines()
            newFile(path,tdosyaAdi)
            newFile(path,cdosyaAdi)
            FileWriter(cdosyaAdi, true).use { writer ->
                println("Çift Dosyasına Yazdırılıyor")
                for(i in fileRead){
                    val number = i.toInt()
                    if (number % 2 == 0){
                        writer.write("$number\n")
                        println(number)}
                        }
                }
            FileWriter(tdosyaAdi, true).use { writer ->
                println("Tek Dosyasına Yazdırılıyor")
                for(i in fileRead){
                    val number = i.toInt()
                    if (number % 2 == 1){
                        writer.write("$number\n")
                        println(number)}
                }
            }
        } catch (e : Exception) {
            println("Dosya oluşturma hatası")
        }
        }
    //#4. İçindeki dump.txt Dosyasını
    //Masaüstüne Çıkartın.
    //
    //Uygulamaya Bu Dosyayı Okuttuğunuz Zaman,
    //Bu Dosyada Kaç Satır, Kaç Kelime Var,
    //Harflerin Kaçı Sessiz, Kaçı Sesli Bu Bilgileri Konsola Yazan Bir Uygulama Yazın
    val dumps = File("C:\\Users\\balca\\Desktop\\dump.txt")

    fun soru4(){
        val read =dumps.readText()
        val kelimeSayisi = read.split(Regex("\\s+")).size
        var sessizHarf = 0
        var sesliHarf = 0
        for (harf in read) {
            val kucukHarf = harf.toLowerCase()
            if (kucukHarf in "bcdfgğhjklmnpqrstvwxyz") {
                sessizHarf++
            }else if (kucukHarf in "aeıioöuü") {
                sesliHarf++
            }
        }
        println("Dosyada ki toplam kelime sayisi: $kelimeSayisi")
        println("Sessiz Harf Sayisi: $sessizHarf")
        println("Sesli Harf Sayisi: $sesliHarf")
    }


    //4. Sorudaki dump.txt yi, dump_rev_1.txt Dosyasına Tersten Yazdırın
    fun soru5(){
        val dumpRev = File("dump_rev_1.txt")
        dumpRev.createNewFile()
        val read =dumps.readText()
        val writer = FileWriter(dumpRev)
        writer.write(read.reversed())
        writer.close()
    }


//    #6. 4. Sorudaki dump.txt yi, dump_rev_2.txt Dosyasına,
//    Kelime Sırasını Bozmadan Tersten Yazdırın
//
//    Örnek : ali topu at 		-->  ila upot ta
    fun soru6(){
        val dumpRev1 = File("dump_rev_2.txt")
        dumpRev1.createNewFile()

        val dumpWords = dumps.readText().split(" ")
        val reversedDump2Text = dumpWords.map { it.reversed() }.joinToString().trimIndent()

        dumpRev1.writeText(reversedDump2Text)
    }

//    #7. 4. Sorudaki dump.txt'de Her Kelimeden Kaç Kez Geçtiğini,
//    En Uzun Kelimenin Hangisi Olduğunu, Kaç Harf Olduğunu
//    En Kısa Kelimenin Hangisi Olduğunu ve Kaç Harf Olduğunu Ekrana Bastırın

    fun soru7() {
        // Önce dosyayı açın ve metni okuyun

        val read = dumps.readText()

        // Metni boşluk karakterlerine göre ayırın
        val words = read.split("\\s+".toRegex())

        // Kelime sayılarını tutmak için bir sözlük oluşturun
        val wordCounts = mutableMapOf<String, Int>()

        for (word in words) {
            val cleanedWord = word.replace(Regex("[^A-Za-z0-9]+"), "")
            if (cleanedWord.isNotEmpty()) {
                wordCounts[cleanedWord] = wordCounts.getOrDefault(cleanedWord, 0) + 1
            }
        }

        val longestWord = wordCounts.maxByOrNull { it.key.length }
        val shortestWord = wordCounts.minByOrNull { it.key.length }

        println("Her kelimenin kaç kez geçtiği:")
        wordCounts.forEach { (word, count) ->
            println("$word: $count")
        }

        println("En uzun kelime: ${longestWord?.key}, ${longestWord?.key?.length} harf")
        println("En kısa kelime: ${shortestWord?.key}, ${shortestWord?.key?.length} harf")
    }

//    #8. Kullanıcıdan Bir Klasörün Yolunu Alın.
//    O Klasör ve O Klasörün Altındaki Tüm Klasörlerde Dahil Olmak Üzere
//    (Burada Recursive Bir Method Yazmanız Gerek)
//    Toplam Boyutu Bulup Ekrana Yazdırın



    fun formatBoyut(boyut: Long): String {
        return when {
            boyut < 1024 -> "$boyut bayt"
            boyut < 1024 * 1024 -> "${boyut / 1024} KB"
            boyut < 1024 * 1024 * 1024 -> "${boyut / (1024 * 1024)} MB"
            else -> "${boyut / (1024 * 1024 * 1024)} GB"
        }
    }

    fun hesaplaToplamBoyut(klasor: File): Long {
        var toplamBoyut: Long = 0

        if (klasor.isDirectory) {
            val dosyalar = klasor.listFiles()

            if (dosyalar != null) {
                for (dosya in dosyalar) {
                    if (dosya.isFile) {
                        toplamBoyut += dosya.length()
                    } else if (dosya.isDirectory) {
                        toplamBoyut += hesaplaToplamBoyut(dosya)
                    }
                }
            }
        }

        return toplamBoyut
    }

    fun soru8() {
        // Kullanıcıdan klasör yolunu alın
        println("Klasör yolunu girin: ")
        val klasorYolu = readLine()

        val klasor = File(klasorYolu)
        val toplamBoyut = hesaplaToplamBoyut(klasor)

        println("Klasör ve altındaki tüm klasörlerin toplam boyutu: ${formatBoyut(toplamBoyut)}")
    }

    fun kelimeIcerenDosyalariAra(dizin: File, kelime: String) {
        if (dizin.isDirectory) {
            val dosyalar = dizin.listFiles()

            if (dosyalar != null) {
                for (dosya in dosyalar) {
                    if (dosya.isDirectory) {
                        kelimeIcerenDosyalariAra(dosya, kelime)
                    } else if (dosya.isFile) {
                        // Eğer bir dosyaysa, dosya adında kelimeyi arayın
                        if (dosya.name.contains(kelime, ignoreCase = true)) {
                            println("Dosya Adı: ${dosya.name}")
                            println("Bulunduğu Klasör: ${dosya.parent}")
                            println("Boyut: ${dosya.length()} byte")
                            println()
                        }
                    }
                }
            }
        }
    }
    fun soru9() {
        println("Arama yapılacak dizini girin: ")
        val dizinYolu = readLine()

        if (dizinYolu != null) {
            val dizin = File(dizinYolu)

            if (dizin.exists() && dizin.isDirectory) {
                println("Aranacak kelimeyi girin: ")
                val aranacakKelime = readLine()

                if (aranacakKelime != null) {
                    kelimeIcerenDosyalariAra(dizin, aranacakKelime)
                } else {
                    println("Hatalı kelime girişi.")
                }
            } else {
                println("Belirtilen dizin bulunamadı veya bir klasör değil.")
            }
        } else {
            println("Hatalı dizin girişi.")
        }
    }
}


