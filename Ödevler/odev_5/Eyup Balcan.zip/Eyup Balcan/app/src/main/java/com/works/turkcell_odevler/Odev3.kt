package com.works.turkcell_odevler

import com.works.turkcell_odevler.OdevClass.Odev3

fun main() {
    val odev3 = Odev3()

//    odev3.soru1();
//    odev3.soru2();
    odev3.soru3();
//    odev3.soru4();

}