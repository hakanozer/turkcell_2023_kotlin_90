import com.works.turkcell_odevler.Odev4.Kisiler
import com.works.turkcell_odevler.Odev4.Sorular

fun main(args: Array<String>) {
    val soru = Sorular();
    val kisilerUygulamasi = Kisiler()


//    soru.soru1();
//    soru.soru2();
//    kisilerUygulamasi.soru3()
//    soru.soru4();
//    soru.soru5();
//    soru.soru6();
//    soru.soru7();
//    soru.soru8();
//    soru.soru9();
//    soru.soru10();
//    soru.soru11();
//    soru.soru12();

}