package com.works.turkcell_odevler.Odev5


class Polymorphism {
//    Polimorfizm, farklı nesnelerin aynı metotları
//    çağırabilmesini ve bu metotların farklı
//    davranışlara sahip olabilmesini ifade eder.
//    Bu, kodun daha esnek, yeniden kullanılabilir
//    ve genel olarak daha kolay bakım yapılabilir olmasını sağlar.
}
open class Calisan {
    open fun göreviniSöyle() {
        println("Bilinmeyen bir ses çıkarıyor.")
    }
}

class Mudur : Calisan() {
    override fun göreviniSöyle() {
        println("Yönetirim")
    }
}

class Sofor : Calisan() {
    override fun göreviniSöyle() {
        println("Araç sürerim")
    }
}

fun main() {
    val calisanlar: Array<Calisan> = arrayOf(Mudur(), Sofor())

    for (görev in calisanlar) {
        görev.göreviniSöyle()
    }
}
