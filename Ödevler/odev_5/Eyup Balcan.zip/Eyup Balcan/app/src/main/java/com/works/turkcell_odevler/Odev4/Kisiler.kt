package com.works.turkcell_odevler.Odev4

class Kisiler {
    data class Kisi(val ad: String, val soyad: String, val tel: String)

    private val kisiler = mutableListOf<Kisi>()

    fun soru3() {
        while (true) {
            println("Lütfen bir seçenek girin:")
            println("1 - Tüm Kayıtları Göster")
            println("2 - Yeni Kayıt Ekle")
            println("3 - Kayıt Sil")
            println("4 - Kayıt Güncelle")
            println("5 - Tümünü Temizle")
            println("6 - Kayıt Ara (Ad veya Soyada Göre)")
            println("7 - Kayıt Ara (Telefon Numarasına Göre)")
            println("8 - Çıkış")

            when (readLine()) {
                "1" -> {
                    if (kisiler.isNotEmpty()) {
                        println("Kayıtlar:")
                        kisiler.forEachIndexed { index, kisi ->
                            println("$index - Ad: ${kisi.ad}, Soyad: ${kisi.soyad}, Tel: ${kisi.tel}")
                        }
                    } else {
                        println("Kayıtlı kişi bulunmamaktadır.")
                    }
                }
                "2" -> {
                    println("Adı girin:")
                    val ad = readLine() ?: ""
                    println("Soyadı girin:")
                    val soyad = readLine() ?: ""
                    println("Telefon numarasını girin:")
                    val tel = readLine() ?: ""
                    val yeniKisi = Kisi(ad, soyad, tel)
                    kisiler.add(yeniKisi)
                    println("Yeni kayıt eklendi.")
                }
                "3" -> {
                    println("Silinecek kaydın indeksini girin:")
                    val index = readLine()?.toIntOrNull()
                    if (index != null && index >= 0 && index < kisiler.size) {
                        kisiler.removeAt(index)
                        println("Kayıt silindi.")
                    } else {
                        println("Geçersiz indeks.")
                    }
                }
                "4" -> {
                    println("Güncellenecek kaydın indeksini girin:")
                    val index = readLine()?.toIntOrNull()
                    if (index != null && index >= 0 && index < kisiler.size) {
                        println("Yeni adı girin:")
                        val yeniAd = readLine() ?: ""
                        println("Yeni soyadı girin:")
                        val yeniSoyad = readLine() ?: ""
                        println("Yeni telefon numarasını girin:")
                        val yeniTel = readLine() ?: ""
                        kisiler[index] = Kisi(yeniAd, yeniSoyad, yeniTel)
                        println("Kayıt güncellendi.")
                    } else {
                        println("Geçersiz indeks.")
                    }
                }
                "5" -> {
                    kisiler.clear()
                    println("Tüm kayıtlar temizlendi.")
                }
                "6" -> {
                    println("Aranacak adı veya soyadı girin:")
                    val aramaMetni = readLine() ?: ""
                    val sonuclar = kisiler.filter { it.ad.contains(aramaMetni, ignoreCase = true) || it.soyad.contains(aramaMetni, ignoreCase = true) }
                    if (sonuclar.isNotEmpty()) {
                        println("Arama Sonuçları:")
                        sonuclar.forEachIndexed { index, kisi ->
                            println("$index - Ad: ${kisi.ad}, Soyad: ${kisi.soyad}, Tel: ${kisi.tel}")
                        }
                    } else {
                        println("Aranan kriterlere uygun kayıt bulunamadı.")
                    }
                }
                "7" -> {
                    println("Aranacak telefon numarasını girin:")
                    val aramaMetni = readLine() ?: ""
                    val sonuclar = kisiler.filter { it.tel.contains(aramaMetni) }
                    if (sonuclar.isNotEmpty()) {
                        println("Arama Sonuçları:")
                        sonuclar.forEachIndexed { index, kisi ->
                            println("$index - Ad: ${kisi.ad}, Soyad: ${kisi.soyad}, Tel: ${kisi.tel}")
                        }
                    } else {
                        println("Aranan telefon numarasına uygun kayıt bulunamadı.")
                    }
                }
                "8" -> {
                    println("Uygulama kapatılıyor. İyi günler!")
                    return
                }
                else -> {
                    println("Hatalı seçim. Lütfen 1-8 arasında bir seçenek girin.")
                }
            }
        }
    }
}


