package com.works.turkcell_odevler.Odev4

import java.math.BigInteger
import kotlin.random.Random

class Sorular {
//    1. 1-49 Arası, 6 Farklı Sayı Seçip Gösterecek Bir Uygulama Yapın

    fun soru1(): List<Int> {
        val sayilar = mutableListOf<Int>()

        while (sayilar.size < 6) {
            val randomSayi = Random.nextInt(1, 50)
            if (randomSayi !in sayilar) {
                sayilar.add(randomSayi)
                println("Şu anki sayınız: $randomSayi")
            }
        }

        return sayilar
    }

//    2. 2 Tane Çok Uzun String Değeriniz Var
//
//    String a  = "23456789876543234567890987654567890";
//    String b =  "99999999999988888888882222222688981";
//
//    Bu İki Sayiyi Toplayacak Bir Uygulama Yazın


    fun soru2(): BigInteger {

        val sayi1 = "23456789876543234567890987654567890"
        val sayi2 = "99999999999988888888882222222688981"

        val result = sayi1.toBigInteger() + sayi2.toBigInteger()

        return result
    }

//    soru3 farklı clasta



//    4. Bir Kotlin List oluşturun ve bu listede bulunan elemanları ekrana yazdırmak için bir
//    döngü kullanarak her elemanı dolaşan bir program yazın.

    fun soru4(){
        val kotlinListe = listOf<String>("Java","Sdk","Kotlin","Try-Catch")
        for(isim in kotlinListe) println(isim)
    }

//    5. Bir Set ve bir List oluşturun. Set'teki benzersiz elemanları, List'teki sırayla bulunan elemanları koruyarak birleştirin.
//    Sonuçta nasıl bir koleksiyon elde edersiniz, bunu ekrana yazdırın.
fun soru5() {
    val set = hashSetOf(1, 2, 20, "ali", "celil", "mehmet")
    val list = listOf(1, 7, 8, "kotlin", "java", "react")
    val sonuc = mutableListOf<Any>()

    for (i in set) {
        if (i !in list) {
            sonuc.add(i)
        }
    }

    println(sonuc)
}

    }

//    6. Verilen bir List içinde belirli bir değerin kaç kez tekrarlandığını hesaplayan bir Kotlin işlevi yazın.

fun soru6() {
    val list = mutableListOf(1, 1, 2, 3, 5, 7, 7, 5, 8, 7, 7, 6, 3, 5, 5, 6)
    val deger = 5
    var j = 0

    for (i in list) {
        if (i == deger) j++
    }

    println("Değeriniz $j tekrarlandı.")
}

//    7. İçinde çeşitli yaşları bulunduran bir List oluşturun. Bu yaşları gruplayarak yaş gruplarını
//    içeren bir Map oluşturun. Örneğin, "18-24" yaş aralığındaki kişileri bir grup olarak tutun.


fun soru7() {
    val yaslar = mutableListOf(1, 5, 7, 8, 9, 15, 17, 19, 23, 27, 32, 15, 45, 52, 46, 22)
    val grup1 = mutableListOf<Int>()
    val grup2 = mutableListOf<Int>()
    val grup3 = mutableListOf<Int>()

    for (i in yaslar) {
        if (i < 15) {
            grup1.add(i)
        } else if (i >= 15 && i < 35) {
            grup2.add(i)
        } else {
            grup3.add(i)
        }
    }

    println("Grup 1: $grup1")
    println("Grup 2: $grup2")
    println("Grup 3: $grup3")
}

//    8. Bir List'teki tüm elemanların toplamını hesaplayan bir Kotlin işlevi yazın. Ayrıca,
//    bu işlevin sadece pozitif sayıları dikkate almasını sağlayın.

fun soru8() {
    val liste = mutableListOf(1, 5, 7, -8, 9, 15, 17, -19, 23, -27, 32, 15, 45, 52, 46, 22)
    var topla = 0

    for (i in liste) {
        if (i > 0) {
            topla += i
        }
    }

    println("Pozitif Sayıların Toplamı: $topla")
}

//    9. Bir List içinde null değerler de dahil olmak üzere karmaşık veriler bulunduğunu varsayalım. Bu verileri filtreleyerek
//    null olmayan elemanları yeni bir List'e ekleyen bir işlev yazın.
    fun soru9(){
    val liste = listOf(null,"Ayse",27,"12",null,"sol","la","si",4,8,null)
    val nullList = mutableListOf<Any>()
    for (i in liste) {
        if (i !=null) {
            nullList.add(i)
        }
    }

    }



//    10. İçinde metin içeren bir List oluşturun. Bu metinleri uzunluğuna göre sıralayarak en kısa ve en uzun metinleri bulun.

fun soru10() {
    val metin = mutableListOf(
        "Kotlin yazıyorum.",
        "Javascript ile kafam rahat.",
        "React mı ratatata :)",
        "Hello World"
    )

//    val enKisaMetin = metin.minByOrNull { it.length } farklı çözüm
//    val enUzunMetin = metin.maxByOrNull { it.length }

    for (i in 0 until metin.size) {
        for (j in i + 1 until metin.size) {
            if (metin[i].length > metin[j].length) {
                // Metinleri yer değiştir
                val temp = metin[i]
                metin[i] = metin[j]
                metin[j] = temp
            }
        }
    }

    println("Metinlerin Uzunluğuna Göre Sıralanmış Hali:")
    for (i in metin) {
        println(i)
    }

    println("En Kısa Metin: ${metin[0]}")
    println("En Uzun Metin: ${metin[metin.size - 1]}")
}

//    11. Bir List içinde rastgele sayılar bulunsun. Bu sayıları büyükten küçüğe sıralayarak sıralama işlemini gerçekleştiren bir Kotlin işlevi yazın.

    fun soru11(){
        val liste = mutableListOf<Int>(1,15,33,2,17,6,3,48,5,12,45,6,3,2,5,)

//        val siraliListe = common.sortedDescending()  > Kullanılabilir bir yöntem, daha kısa.

        for (i in 0 until liste.size - 1) {
            for (j in 0 until liste.size - 1 - i) {
                if (liste[j] < liste[j + 1]) {
                    val sayi = liste[j]
                    liste[j] = liste[j + 1]
                    liste[j + 1] = sayi
                }
            }
        }
        println("Sıralanmış Liste: $liste")

    }

//    12. İki Set'i karşılaştırarak, her iki Set'in de içinde bulunan ortak elemanları bulan bir Kotlin programı yazın.

    fun soru12(){
        val set1 = hashSetOf(27,80, 34,7, 4, 53)
        val set2 = hashSetOf(34, 4, 53, 6, 7,81,27)
        val common = mutableListOf<Int>()

//        val common = set1.intersect(set2).toMutableList()   > Kullanılabilir bir yöntem, daha kısa.
        for (i in set1){
            for (j in set2){
                if (i == j){
                    common.add(i)
                }
            }
        }
        println("Ortak Eleman Listei $common")
}

