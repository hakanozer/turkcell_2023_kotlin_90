package com.works.turkcell_odevler.Odev5

open class Hayvan(val isim: String) {
    open fun sesCikar() {
        println("$isim bilinmeyen bir ses çıkarıyor.")
    }
}

class Köpek(isim: String) : Hayvan(isim) {
    override fun sesCikar() {
        println("$isim hav! hav!")
    }
}

class Kedi(isim: String) : Hayvan(isim) {
    override fun sesCikar() {
        println("$isim miyav! miyav!")
    }
}

fun main() {
    val hayvanlar: Array<Hayvan> = arrayOf(
        Köpek("Karabaş"),
        Kedi("Pamuk"),
        Köpek("Fido"),
        Kedi("Whiskers")
    )

    for (hayvan in hayvanlar) {
        hayvan.sesCikar()
    }
}