package com.works.turkcell_odevler.Odev5

abstract class TelefonGorusmesi(val kisiAdi: String) {
    abstract fun gorusmeBaslat()
}

interface Hoparlorlu {
    fun hoparloruAc()
}

class CepTelefonu(kisiAdi: String) : TelefonGorusmesi(kisiAdi), Hoparlorlu {
    override fun gorusmeBaslat() {
        println("$kisiAdi ile telefon görüşmesi başlatılıyor...")
    }

    override fun hoparloruAc() {
        println("Hoparlör açıldı.")
    }
}

fun main() {
    val cepTelefonu = CepTelefonu("Ahmet")

    cepTelefonu.gorusmeBaslat()
    cepTelefonu.hoparloruAc()
}