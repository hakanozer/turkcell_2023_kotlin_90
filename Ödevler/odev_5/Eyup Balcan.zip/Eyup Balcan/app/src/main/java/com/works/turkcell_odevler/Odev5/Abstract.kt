package com.works.turkcell_odevler.Odev5

 class Abstract {
 //Sınıflar arasında pek çok ortak özellik ve davranış bulunduğu durumlarda tasarlanan soyut sınıflardır.
 // Kod tekrarını engelleyerek hem daha derli toplu bir görüntü sağlar hem de hata yapma riskini azaltır.
 // Ortak bir şablon üzerinden ilerleme imkanı sunar ve bu sınıfların temel amacı da budur.
}

abstract class Dersler {
 abstract fun ortalamaHesapla(): Double
}

class Mat(val vize: Int, val final: Int) : Dersler() {
 override fun ortalamaHesapla(): Double {
  return (vize * final).toDouble()
 }
}

class Fizik(val vize: Int, val final: Int, val sozlu: Int) : Dersler() {
 override fun ortalamaHesapla(): Double {
  return (vize * final + sozlu).toDouble()
 }
}

fun main() {
 val matDersi = Mat(50, 70)
 val fizikDersi = Fizik(80, 45, 20)

 println("Matematik notu: ${matDersi.ortalamaHesapla()}")
 println("Fizik notu: ${fizikDersi.ortalamaHesapla()}")
}