package com.works.turkcell_odevler.Odev5

class Inheritance {
//    //Inheritance (miras), nesne yönelimli programlamada (OOP) önemli bir kavramdır.
//    Bir sınıfın özelliklerinin ve metotlarının başka sınıflara aktarılarak işlevinin artırılmasını sağlar.
//    Oluşturulan ve genel özellikler içeren ilk sınıfa temel sınıf(base) ,
//    ondan miras alınarak özelleştirilen alt sınıflara türetilmiş(devired) sınıflar denir

}

open class Arac(val isim: String, val beygirGucu: Int) {
    open fun hareketEt() {
        println("$isim hareket ediyor.")
    }
}

  class Motor(isim: String, beygirGucu: Int) : Arac(isim, beygirGucu) {
    fun gazVer() {
        println("$isim gaz veriyor.")
    }
}

  class Araba(isim: String, beygirGucu: Int) : Arac(isim, beygirGucu) {
    fun kornaCal() {
        println("$isim korna çalıyor.")
    }
}

fun main() {
    val motor = Motor("Harley Davidson", 100)
    val araba = Araba("Audi A6", 250)

    motor.hareketEt()
    motor.gazVer()

    araba.hareketEt()
    araba.kornaCal()
}