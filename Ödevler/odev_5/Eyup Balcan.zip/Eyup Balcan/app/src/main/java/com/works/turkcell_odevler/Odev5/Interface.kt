package com.works.turkcell_odevler.Odev5


interface Surucu {
    fun aracıSur()
}

class Sofor1(adi: String) : Surucu {
    val ad: String = adi

    override fun aracıSur() {
        println("$ad aracı sürüyor.")
    }
}


// Birinci interface
interface Arayuz1 {
    fun metot1()
}

// İkinci interface
interface Arayuz2 {
    fun metot2()
}

// Her iki interface'i uygulayan sınıf oluşturma
class Sinif : Arayuz1, Arayuz2 {
    override fun metot1() {
        println("Arayüz 1 - Metot 1 çalıştı.")
    }

    override fun metot2() {
        println("Arayüz 2 - Metot 2 çalıştı.")
    }
}

fun main() {

    // Şoför sınıfından bir örnek oluşturma
    val şofor1 = Sofor1("Ahmet")

    // Aracı sürme metodu çağırma
    şofor1.aracıSur()


    val nesne = Sinif()
    nesne.metot1()
    nesne.metot2()
}