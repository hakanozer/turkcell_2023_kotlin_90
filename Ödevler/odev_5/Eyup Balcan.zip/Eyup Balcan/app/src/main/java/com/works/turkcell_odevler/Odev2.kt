import com.works.turkcell_odevler.OdevClass.Odev2

fun main() {
    val odev2 = Odev2()

//    odev2.isPrime(52)
//    odev2.soru2(50,100)
//    odev2.soru3(9,3)
//    odev2.soru4(999)
//    odev2.soru5(58.0,180.0) /
//    odev2.soru6(1253)
//    odev2.soru7(1232)
//    odev2.soru8(intArrayOf(12,15,85))
//    odev2.soru9(intArrayOf(12,15,20,25),15)
//    odev2.soru10(5,10,15,12)
//    odev2.soru11(intArrayOf(12,15,20,25),intArrayOf(12,15,20,25))
//    odev2.soru12(10,0)
//    odev2.soru13()
//    odev2.soru14()
//    odev2.soru15()
//    odev2.soru15()
//    odev2.soru16()
//    odev2.soru17()
//    odev2.soru18()
//    odev2.soru19()
//    odev2.soru20()
//    odev2.soru21()
//    odev2.soru22()
//    odev2.soru23()
//    odev2.soru24()
//    odev2.soru25()
//    odev2.soru26()
//    odev2.soru27()
//    odev2.soru28()
//    odev2.soru29()
//    odev2.soru30()









}