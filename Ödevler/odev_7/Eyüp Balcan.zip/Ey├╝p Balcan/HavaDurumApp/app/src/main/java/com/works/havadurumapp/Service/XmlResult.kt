package com.works.havadurumapp.Service

import android.R
import android.os.AsyncTask
import android.os.StrictMode
import android.os.StrictMode.ThreadPolicy
import android.util.Log
import android.widget.TextView
import com.works.havadurumapp.Model.Meteroloji
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.parser.Parser
import org.jsoup.select.Elements
import java.io.IOException

class XmlResult{

    fun xml(): List<Meteroloji>{
        val policy = ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)

        val arr = mutableListOf<Meteroloji>()

        try {
            val url="https://www.mgm.gov.tr/FTPDATA/analiz/sonSOA.xml"
            val stData = Jsoup.connect(url).ignoreContentType(true).timeout(15000).get().toString()
            Log.d("XmlResult", "Raw XML Data: $stData")
            val doc: Document = Jsoup.parse(stData, Parser.xmlParser())
            val elements:Elements = doc.getElementsByTag("sehirler")
            for (item in elements){
                val bolge = item.getElementsByTag("Bolge").text()
                val il = item.getElementsByTag("ili").text()
                val durum = item.getElementsByTag("Durum").text()
                val vakit = item.getElementsByTag("Peryot").text()
                val derece = item.getElementsByTag("Mak").text()
                val met = Meteroloji(bolge,il,durum,vakit,derece)
                arr.add(met)
            }

        }catch (e: Exception){
            Log.e("Xml Error",e.toString())
        }
        return arr
    }
}