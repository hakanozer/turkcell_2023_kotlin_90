package com.works.havadurumapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.works.havadurumapp.Model.Meteroloji
import com.works.havadurumapp.Service.XmlResult
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: HavaDurumuAdapter
    private lateinit var havadList: List<Meteroloji>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val xmlResult = XmlResult()
        havadList = xmlResult.xml()

        adapter = HavaDurumuAdapter(havadList)
        recyclerView.adapter = adapter
    }
    
    private fun filterList(query: String?) {
        if (query != null) {
            val filteredList = ArrayList<Meteroloji>()
            havadList.forEach { weatherData ->
                val cityLowerCase = weatherData.il.lowercase(Locale.ROOT)
                val queryLowerCase = query.lowercase(Locale.ROOT)

                if (cityLowerCase.contains(queryLowerCase)) {
                    filteredList.add(weatherData)
                }
            }
            if (filteredList.isEmpty()) {
                return
            } else {
                adapter.setFilteredList(filteredList)
            }
        } else {
            adapter.setFilteredList(havadList)
        }
    }



}
