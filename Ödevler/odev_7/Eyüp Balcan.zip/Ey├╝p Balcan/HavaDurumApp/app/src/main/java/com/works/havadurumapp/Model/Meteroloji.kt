package com.works.havadurumapp.Model

data class Meteroloji(
    val bolge:String,
    val il:String,
    val durum:String,
    val vakit:String,
    val derece:String
)
