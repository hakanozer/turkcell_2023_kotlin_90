package com.works.havadurumapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.works.havadurumapp.Model.Meteroloji


class HavaDurumuAdapter(var havadList:List<Meteroloji>) : RecyclerView.Adapter<HavaDurumuAdapter.HavaDurumu>() {

    class HavaDurumu(view: View) : RecyclerView.ViewHolder(view){
        val bolge = view.findViewById<TextView>(R.id.txt_Bolge)
        val derece = view.findViewById<TextView>(R.id.txt_Derece)
        val sehir = view.findViewById<TextView>(R.id.txt_sehir)
        val durum = view.findViewById<TextView>(R.id.txt_Durum)
        val vakit = view.findViewById<TextView>(R.id.txt_Vakit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HavaDurumu {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.card_view_design, parent, false)
        return HavaDurumu(view)
    }

    override fun getItemCount(): Int {
        return havadList.size
    }

    override fun onBindViewHolder(holder: HavaDurumu, position: Int) {
        val havaDurumu = havadList[position]
        //min bazılarında olmadığı için derece olarak aldım
        holder.apply {
            derece.text = " ${havaDurumu.derece}'C \n Derece \n"
            durum.text = havaDurumu.durum
            bolge.text = havaDurumu.bolge
            sehir.text = havaDurumu.il
            vakit.text = havaDurumu.vakit
        }
        //BURADAN DİREKT CONTEXT'i ALMA! MEMORY LEAK OLUŞUR (BELLEK SIZINTISI)
        //CONTEXT holder'ın içinde itemView seçilir context oradan alınır.
        holder.itemView.context

        //Fragment açma kapama toast vb diğer apiden veri çekme işlemlerini onClick yönteminyle
        //ilgili activity yada fragment'ta yapmalısın!!.
    }

    fun setFilteredList(havadList: List<Meteroloji>) {
        this.havadList = havadList
        notifyDataSetChanged()
    }

}