package com.example.final_project_turkcell.model.info_model

data class Address(
    val address: String,
    val city: String,
    val coordinates: Coordinates,
    val postalCode: String,
    val state: String,
)
