package com.example.final_project_turkcell.ui.product_list.adapter.product_list

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.final_project_turkcell.R
import com.example.final_project_turkcell.databinding.RowProductInfoBinding
import com.example.final_project_turkcell.model.main_model.Product
import com.example.final_project_turkcell.ui.product_list.activity.ProductListDetailsActivity
import com.example.final_project_turkcell.util.Constants.SHARED_PREF_KEY
import com.example.final_project_turkcell.util.Constants.SHARED_PREF_KEY_FAVORITE_LIST
import com.squareup.picasso.Picasso
import java.io.Serializable

class ProductListAdapter(
    private val context: Context,
    private var productsList: List<Product>
) :
    RecyclerView.Adapter<ProductListAdapter.ProductHolder>() {

    inner class ProductHolder(val binding: RowProductInfoBinding) :
        RecyclerView.ViewHolder(binding.root) {
        var imageViewProduct: ImageView = binding.imageViewProduct
        var textViewTitle: TextView = binding.textViewTitle
        var textViewPrice: TextView = binding.textViewPrice
        var imageViewFavorite: ImageView = binding.imageViewFavorite
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductHolder {
        val bindingItem =
            RowProductInfoBinding.inflate(LayoutInflater.from(context), parent, false)
        return ProductHolder(bindingItem)
    }

    override fun getItemCount(): Int = productsList.size

    override fun onBindViewHolder(holder: ProductHolder, position: Int) {
        val productsList = productsList[position]
        with(holder) {
            Picasso.get().load(productsList.images.firstOrNull()).into(imageViewProduct)
            textViewTitle.text = productsList.title
            textViewPrice.text = "Price: ${productsList.price}$"
            itemView.setOnClickListener {
                val intent = Intent(context, ProductListDetailsActivity::class.java)
                intent.putExtra("product", productsList as Serializable)
                context.startActivity(intent)
            }
            imageViewFavorite.setImageResource(
                if (isFav(context, productsList.id)) R.drawable.ic_love else R.drawable.ic_love
            )
            imageViewFavorite.setOnClickListener {
                val favStatus = isFav(context, productsList.id)
                if (favStatus) {
                    removeFavorites(context, productsList.id)
                } else {
                    addFavorites(context, productsList.id)
                }
                imageViewFavorite.setImageResource(
                    if (isFav(context, productsList.id)) R.drawable.ic_love else R.drawable.ic_love
                )
            }
        }
    }

    fun updateProductsList(newList: List<Product>) {
        productsList = newList
        notifyDataSetChanged()
    }

    private fun addFavorites(context: Context, productId: Long) {
        val prefs = context.getSharedPreferences(SHARED_PREF_KEY, Context.MODE_PRIVATE)
        val favoriteSet: MutableSet<String> = getFavoriteSet(context).toMutableSet()
        favoriteSet.add(productId.toString())
        prefs.edit().putStringSet(SHARED_PREF_KEY_FAVORITE_LIST, favoriteSet).apply()
    }

    private fun removeFavorites(context: Context, productId: Long) {
        val prefs = context.getSharedPreferences(SHARED_PREF_KEY, Context.MODE_PRIVATE)
        val favoriteSet: MutableSet<String> = getFavoriteSet(context).toMutableSet()
        favoriteSet.remove(productId.toString())
        prefs.edit().putStringSet(SHARED_PREF_KEY_FAVORITE_LIST, favoriteSet).apply()
    }

    private fun getFavoriteSet(context: Context): Set<String> {
        val prefs = context.getSharedPreferences(SHARED_PREF_KEY, Context.MODE_PRIVATE)
        return prefs.getStringSet(SHARED_PREF_KEY_FAVORITE_LIST, HashSet()) ?: HashSet()
    }

    private fun isFav(context: Context, productId: Long): Boolean {
        val favoriteSet: Set<String> = getFavoriteSet(context)
        return favoriteSet.contains(productId.toString())
    }
}
