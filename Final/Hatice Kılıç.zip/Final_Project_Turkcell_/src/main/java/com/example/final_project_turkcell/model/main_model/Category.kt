package com.example.final_project_turkcell.model.main_model

data class Category(
    val categoryName: String,
    val categoryImage: Int
)
