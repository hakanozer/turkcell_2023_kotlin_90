package com.example.final_project_turkcell.ui.main.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.final_project_turkcell.databinding.ActivityMainBinding
import com.example.final_project_turkcell.model.service_model.ServiceAccountModel
import com.example.final_project_turkcell.model.service_model.ServiceModel
import com.example.final_project_turkcell.network.ApiClient
import com.example.final_project_turkcell.network.ServiceResponse
import com.example.final_project_turkcell.ui.product_list.activity.ProductsListActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val serviceResponse by lazy {
        ApiClient.getClient().create(ServiceResponse::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.loginButton.setOnClickListener {
            val username = binding.editTextUsername.text.toString().trim()
            val password = binding.editTextPassword.text.toString().trim()

            if (username == "kminchelle" && password == "0lelplR") {
                serviceResponse.login(ServiceAccountModel(username, password))
                    .enqueue(object : Callback<ServiceModel> {
                        override fun onResponse(
                            call: Call<ServiceModel>,
                            response: Response<ServiceModel>
                        ) {
                            val user = response.body()
                            if (user != null) {
                                startActivity(Intent(applicationContext, ProductsListActivity::class.java))
                            }
                        }

                        override fun onFailure(call: Call<ServiceModel>, t: Throwable) {
                            Toast.makeText(applicationContext, t.toString(), Toast.LENGTH_SHORT)
                                .show()
                        }
                    })
            } else {
                Toast.makeText(applicationContext, "Username or Password Error", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }
}