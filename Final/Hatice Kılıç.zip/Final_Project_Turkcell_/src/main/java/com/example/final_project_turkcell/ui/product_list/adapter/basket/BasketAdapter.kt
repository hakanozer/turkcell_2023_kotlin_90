package com.example.final_project_turkcell.ui.product_list.adapter.basket

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.final_project_turkcell.databinding.RowCartInfoItemBinding
import com.example.final_project_turkcell.model.main_model.Product
import com.example.final_project_turkcell.util.Constants.SHARED_PREF_KEY
import com.example.final_project_turkcell.util.Constants.SHARED_PREF_KEY_CART_LIST
import com.squareup.picasso.Picasso


class BasketAdapter(private val mContext: Context, private val productList: MutableList<Product>) :
    RecyclerView.Adapter<BasketAdapter.CartViewHolder>() {

    inner class CartViewHolder(val binding: RowCartInfoItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val bindingItem =
            RowCartInfoItemBinding.inflate(LayoutInflater.from(mContext), parent, false)
        return CartViewHolder(bindingItem)
    }

    override fun getItemCount(): Int {
        return productList.size
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val product = productList[position]

        holder.binding.textViewCartPrice.text = "Price: ${product.price}$"
        holder.binding.textViewCartPrice.text = product.title

        if (product.quantity == 0) {
            product.quantity = 1
        }
        holder.binding.textViewQuantity.text = "Quantity: ${product.quantity}"

        Picasso.get().load(product.thumbnail).into(holder.binding.imageViewCart)

        holder.binding.imageViewDelete.setOnClickListener {
            productList.removeAt(position)
            notifyDataSetChanged()
            removeCart(mContext, product.id)
        }

        holder.binding.imageViewPlus.setOnClickListener {
            val currentQuantity = product.quantity
            if (currentQuantity > 0) {
                product.quantity = currentQuantity - 1
                notifyDataSetChanged()
            }
        }

        holder.binding.imageViewMinus.setOnClickListener {
            val currentQuantity = product.quantity
            product.quantity = currentQuantity + 1
            notifyDataSetChanged()
        }
    }

    private fun removeCart(context: Context, productId: Long) {
        val prefs = context.getSharedPreferences(SHARED_PREF_KEY, Context.MODE_PRIVATE)
        val cardSet: MutableSet<String> = getCartSet().toMutableSet()
        cardSet.remove(productId.toString())
        prefs.edit().putStringSet(SHARED_PREF_KEY_CART_LIST, cardSet).apply()
    }

    private fun getCartSet(): Set<String> {
        val prefs = mContext.getSharedPreferences(SHARED_PREF_KEY, Context.MODE_PRIVATE)
        return prefs.getStringSet(SHARED_PREF_KEY_CART_LIST, HashSet()) ?: HashSet()
    }
}