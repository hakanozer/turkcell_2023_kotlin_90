package com.example.final_project_turkcell.ui.home.fragment

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.final_project_turkcell.R
import com.example.final_project_turkcell.databinding.FragmentHomeBinding
import com.example.final_project_turkcell.model.main_model.Category
import com.example.final_project_turkcell.model.main_model.Product
import com.example.final_project_turkcell.model.main_model.Products
import com.example.final_project_turkcell.network.ApiClient
import com.example.final_project_turkcell.network.ServiceResponse
import com.example.final_project_turkcell.ui.category.adapter.CategoryAdapter
import com.example.final_project_turkcell.ui.product_list.adapter.basket.BasketAdapter
import com.example.final_project_turkcell.ui.product_list.adapter.product_list.ProductListAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeFragment : Fragment(), CategoryAdapter.CategoryClick {

    private lateinit var binding: FragmentHomeBinding
    private lateinit var serviceResponse: ServiceResponse
    private lateinit var categoryList: ArrayList<Category>
    private lateinit var productsList: ArrayList<Product>
    private lateinit var productListAdapter: ProductListAdapter
    private lateinit var categoryAdapter: CategoryAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        serviceResponse = ApiClient.getClient().create(ServiceResponse::class.java)

        with(binding) {
            recyclerViewHome.setHasFixedSize(true)
            recyclerViewHome.layoutManager = GridLayoutManager(requireContext(), 2)
            editTextSearch.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {}

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    if (s.toString().isNotEmpty()) {
                        filterProducts(s.toString())
                    } else {
                        loadAllProducts()
                    }
                }
            })

            val btn = activity?.findViewById<FloatingActionButton>(R.id.fab)
            btn?.setOnClickListener { linearCategory.visibility = View.VISIBLE }
            imageViewFilter.setOnClickListener { getMyCard() }
        }

        getCategory()
        setSize()
    }

    private fun filterProducts(query: String) {
        serviceResponse.filterProducts(query).enqueue(object : Callback<Products> {
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                handleResponse(response)
            }

            override fun onFailure(call: Call<Products>, t: Throwable) {
                handleFailure()
            }
        })
    }

    private fun loadAllProducts() {
        serviceResponse.allProducts(20).enqueue(object : Callback<Products> {
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                handleResponse(response)
            }

            override fun onFailure(call: Call<Products>, t: Throwable) {
                handleFailure()
            }
        })
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun handleResponse(response: Response<Products>) {
        if (response.isSuccessful) {
            response.body()?.let {
                productsList = ArrayList(it.products)
                productListAdapter = ProductListAdapter(requireContext(), productsList)
                binding.recyclerViewHome.adapter = productListAdapter
                productListAdapter.notifyDataSetChanged()
            }
        } else {
            Toast.makeText(
                requireContext(),
                "Failed to retrieve products. Response code: ${response.code()}",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun handleFailure() {
        Toast.makeText(requireContext(), "Service Error", Toast.LENGTH_SHORT).show()
    }

    private fun getCategory() = with(binding) {
        val categories = arrayOf(
            "smartphones",
            "laptops",
            "tops"
        )

        val categoriesIcon = intArrayOf(
            R.drawable.ic_phone,
            R.drawable.ic_laptop,
            R.drawable.ic_star
        )

        recyclerViewCategory.layoutManager =
            GridLayoutManager(requireContext(), 1, GridLayoutManager.HORIZONTAL, false)
        recyclerViewCategory.setHasFixedSize(true)

        categoryAdapter = CategoryAdapter(requireContext(), categoryList, this@HomeFragment)
        recyclerViewCategory.adapter = categoryAdapter
        for (i in categories.indices) {
            categoryList.add(Category(categories[i], categoriesIcon[i]))
        }
    }

    override fun clickCategory(category: Category) {
        serviceResponse.filterCategory(category.categoryName).enqueue(object : Callback<Products> {
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        productsList = ArrayList(it.products)
                        productListAdapter.updateProductsList(productsList)
                    }
                } else {
                    Toast.makeText(
                        requireContext(),
                        "onResponse: ${response.code()}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<Products>, t: Throwable) {
                Toast.makeText(requireContext(), "Service Error", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun setSize() {
        val cartIdList = getCartSet().size
        binding.textViewCartPoint.text = cartIdList.toString()
    }

    private fun getMyCard() {
        val dialog = Dialog(requireContext()).apply {
            requestWindowFeature(Window.FEATURE_NO_TITLE)
            setContentView(R.layout.row_cart_info)
            window?.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            window?.setGravity(Gravity.CENTER)
            show()
        }

        val recyclerViewCart = dialog.findViewById<RecyclerView>(R.id.recyclerViewCart)
        val imageViewClose = dialog.findViewById<ImageView>(R.id.imageViewClose)
        val textViewTotal = dialog.findViewById<TextView>(R.id.textViewTotal)

        imageViewClose.setOnClickListener { dialog.dismiss() }
        textViewTotal.visibility = View.GONE

        recyclerViewCart.apply {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
        }

        val serviceResponse = ApiClient.getClient().create(ServiceResponse::class.java)
        serviceResponse.allProducts(20).enqueue(object : Callback<Products> {
            @SuppressLint("NotifyDataSetChanged")
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        val allProducts: List<Product> = it.products
                        recyclerViewCart.adapter = BasketAdapter(
                            requireContext(),
                            allProducts.filter { getCartSet().contains(it.id.toString()) }
                                .toMutableList()
                        )
                        (recyclerViewCart.adapter as? BasketAdapter)?.notifyDataSetChanged()
                    }
                }
            }

            override fun onFailure(call: Call<Products>, t: Throwable) {
                Toast.makeText(requireContext(), "onFailure: $t ", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun getCartSet(): Set<String> =
        requireContext().getSharedPreferences("PREFS", Context.MODE_PRIVATE)
            .getStringSet("KEY_CART_LIST", HashSet()) ?: HashSet()
}