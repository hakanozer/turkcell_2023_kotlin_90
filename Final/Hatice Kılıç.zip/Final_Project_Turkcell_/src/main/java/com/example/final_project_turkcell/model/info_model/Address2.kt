package com.example.final_project_turkcell.model.info_model

data class Address2(
    val address: String,
    val city: String,
    val coordinates: Coordinates2,
    val postalCode: String,
    val state: String,
)