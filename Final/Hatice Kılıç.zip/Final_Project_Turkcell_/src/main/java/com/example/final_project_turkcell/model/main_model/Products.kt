package com.example.final_project_turkcell.model.main_model

data class Products(
    val products: List<Product>,
    val total: Long,
    val skip: Long,
    val limit: Long
)
