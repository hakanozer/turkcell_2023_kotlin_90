package com.example.final_project_turkcell.util

object Constants {

    const val BASU_URL = "https://dummyjson.com/"
    const val SHARED_PREF_KEY = "PREFS"
    const val SHARED_PREF_KEY_FAVORITE_LIST = "KEY_FAVORITE_LIST"
    const val SHARED_PREF_KEY_CART_LIST = "KEY_CART_LIST"
}