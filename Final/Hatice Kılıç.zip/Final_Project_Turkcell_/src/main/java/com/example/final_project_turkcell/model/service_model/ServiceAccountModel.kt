package com.example.final_project_turkcell.model.service_model

data class ServiceAccountModel(
    val username: String,
    val password: String
)
