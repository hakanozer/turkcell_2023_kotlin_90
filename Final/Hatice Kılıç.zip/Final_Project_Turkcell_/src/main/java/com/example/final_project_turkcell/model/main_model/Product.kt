package com.example.final_project_turkcell.model.main_model

import java.io.Serializable

data class Product(
    val id: Long,
    val title: String,
    val description: String,
    val price: Long,
    val discountPercentage: Double,
    val rating: Double,
    val stock: Long,
    val brand: String,
    val category: String,
    val thumbnail: String,
    val images: List<String>,
    var quantity: Int
): Serializable
