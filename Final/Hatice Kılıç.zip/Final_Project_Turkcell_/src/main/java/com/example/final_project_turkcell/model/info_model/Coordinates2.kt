package com.example.final_project_turkcell.model.info_model

data class Coordinates2(
    val lat: Double,
    val lng: Double,
)
