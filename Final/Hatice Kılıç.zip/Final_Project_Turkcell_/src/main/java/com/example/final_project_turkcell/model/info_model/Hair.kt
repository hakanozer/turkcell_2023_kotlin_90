package com.example.final_project_turkcell.model.info_model

data class Hair(
    val color: String,
    val type: String,

)
