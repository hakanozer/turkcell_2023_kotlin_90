package com.example.final_project_turkcell.ui.category.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.final_project_turkcell.databinding.RowCategoryInfoBinding
import com.example.final_project_turkcell.model.main_model.Category

class CategoryAdapter(
    private val mContext: Context,
    private val categoryList: List<Category>,
    private val categoryClick: CategoryClick
) : RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder>() {

    inner class CategoryViewHolder(val binding: RowCategoryInfoBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val inflater = LayoutInflater.from(mContext)
        val bindingItem = RowCategoryInfoBinding.inflate(inflater, parent, false)
        return CategoryViewHolder(bindingItem)
    }

    override fun getItemCount(): Int = categoryList.size

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        val categoryData = categoryList[position]
        with(holder.binding) {
            textViewCategory.text = categoryData.categoryName
            imageViewCategory.setImageResource(categoryData.categoryImage)
            root.setOnClickListener {
                categoryClick.clickCategory(categoryData)
            }
        }
    }

    interface CategoryClick {
        fun clickCategory(category: Category)
    }
}