package com.example.final_project_turkcell.ui.favorite.fragment

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.example.final_project_turkcell.databinding.FragmentFavoriteBinding
import com.example.final_project_turkcell.model.main_model.Product
import com.example.final_project_turkcell.model.main_model.Products
import com.example.final_project_turkcell.network.ApiClient
import com.example.final_project_turkcell.network.ServiceResponse
import com.example.final_project_turkcell.ui.product_list.adapter.product_list.ProductListAdapter
import com.example.final_project_turkcell.util.Constants.SHARED_PREF_KEY
import com.example.final_project_turkcell.util.Constants.SHARED_PREF_KEY_FAVORITE_LIST
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FavoriteFragment : Fragment() {

    private lateinit var binding: FragmentFavoriteBinding
    private lateinit var serviceResponse: ServiceResponse
    private lateinit var productListAdapter: ProductListAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFavoriteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        serviceResponse = ApiClient.getClient().create(ServiceResponse::class.java)

        with(binding.recyclerViewHome) {
            setHasFixedSize(true)
            layoutManager = GridLayoutManager(requireContext(), 2)
        }

        getBasket()
    }

    private fun getFavoriteSet(context: Context): Set<String> {
        return context.getSharedPreferences(SHARED_PREF_KEY, Context.MODE_PRIVATE)
            .getStringSet(SHARED_PREF_KEY_FAVORITE_LIST, HashSet()) ?: HashSet()
    }

    private fun getBasket() {
        serviceResponse.allProducts(20).enqueue(object : Callback<Products> {
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                handleResponse(response)
            }

            override fun onFailure(call: Call<Products>, t: Throwable) {
                handleFailure(t)
            }
        })
    }

    private fun handleResponse(response: Response<Products>) {
        if (response.isSuccessful) {
            response.body()?.let {
                val allProducts: List<Product> = it.products
                productListAdapter = ProductListAdapter(
                    requireContext(),
                    allProducts.filter { getFavoriteSet(requireContext()).contains(it.id.toString()) })
                binding.recyclerViewHome.adapter = productListAdapter
                productListAdapter.notifyDataSetChanged()
            }
        }
    }

    private fun handleFailure(t: Throwable) {
        Toast.makeText(requireContext(), "onFailure: $t ", Toast.LENGTH_SHORT).show()
    }
}