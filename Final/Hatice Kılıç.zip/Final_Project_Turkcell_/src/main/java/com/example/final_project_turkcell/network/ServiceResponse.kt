package com.example.final_project_turkcell.network

import com.example.final_project_turkcell.model.response_model.CartResponse
import com.example.final_project_turkcell.model.main_model.Category
import com.example.final_project_turkcell.model.service_model.ServiceModel
import com.example.final_project_turkcell.model.service_model.ServiceAccountModel
import com.example.final_project_turkcell.model.main_model.Products
import com.example.final_project_turkcell.model.main_model.Root
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface ServiceResponse {


    @GET("products")
    fun allProducts(@Query("limit") limit: Int): Call<Products>

    @POST("carts/add")
    fun addProduct(): Call<Products>

    @GET("users/1")
    fun getUser(): Call<Root>

    @POST("auth/login")
    fun login(@Body serviceAccountModel: ServiceAccountModel): Call<ServiceModel>

    @GET("products/categories")
    fun getCategory(): Call<List<Category>>

    @GET("carts/user/5")
    fun getCart(): Call<CartResponse>

    @GET("products/search")
    fun filterProducts(@Query("q") keyword: String): Call<Products>

    @GET("products/category/{category}")
    fun filterCategory(@Path("category") categoryname: String): Call<Products>
}