package com.example.final_project_turkcell.model.main_model

import com.example.final_project_turkcell.model.info_model.Address
import com.example.final_project_turkcell.model.info_model.Bank
import com.example.final_project_turkcell.model.info_model.Company
import com.example.final_project_turkcell.model.info_model.Hair

data class Root(
    val id: Long,
    val firstName: String,
    val lastName: String,
    val maidenName: String,
    val age: Long,
    val gender: String,
    val email: String,
    val phone: String,
    val username: String,
    val password: String,
    val birthDate: String,
    val image: String,
    val bloodGroup: String,
    val height: Long,
    val weight: Double,
    val eyeColor: String,
    val hair: Hair,
    val domain: String,
    val ip: String,
    val address: Address,
    val macAddress: String,
    val university: String,
    val bank: Bank,
    val company: Company,
    val ein: String,
    val ssn: String,
    val userAgent: String,
)
