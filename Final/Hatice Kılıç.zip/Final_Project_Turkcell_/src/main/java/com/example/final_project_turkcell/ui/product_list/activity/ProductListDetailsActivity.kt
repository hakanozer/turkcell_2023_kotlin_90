package com.example.final_project_turkcell.ui.product_list.activity

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.final_project_turkcell.databinding.ActivityProductListDetailsBinding
import com.example.final_project_turkcell.model.main_model.Product
import com.example.final_project_turkcell.network.ApiClient
import com.example.final_project_turkcell.network.ServiceResponse
import com.example.final_project_turkcell.util.Constants.SHARED_PREF_KEY
import com.example.final_project_turkcell.util.Constants.SHARED_PREF_KEY_CART_LIST
import com.squareup.picasso.Picasso

class ProductListDetailsActivity : AppCompatActivity() {

    private lateinit var serviceResponse: ServiceResponse
    private lateinit var binding: ActivityProductListDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductListDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        serviceResponse = ApiClient.getClient().create(ServiceResponse::class.java)

        val product: Product? = intent.getSerializableExtra("product") as? Product

        product?.let { productDetails(it) }

        binding.addButton.setOnClickListener {
            product?.let {
                addCart(it.id)
            }
        }

        product?.let {
            binding.ratingBar.isEnabled = false
            binding.ratingBar.rating = it.rating.toFloat()
        }

        binding.imageViewCloseDetails.setOnClickListener {
            finish()
        }
    }

    private fun productDetails(product: Product) {
        with(binding) {
            textViewPriceDetails.text = "Price: ${product.price}$"
            textViewTitleDetails.text = product.title
            textViewDescriptionDetails.text = product.description
            textViewBrandDetails.text = "Brand: ${product.brand}"
            textViewStockDetails.text = "Stock: ${product.stock}"
            textViewCategoryDetails.text = "Category: ${product.category}"
            Picasso.get().load(product.images.firstOrNull()).into(imageViewProductDetails)
        }
    }

    private fun addCart(productId: Long) {
        val cartSet: MutableSet<String> = getCartSet().toMutableSet()
        cartSet.add(productId.toString())
        getSharedPreferences(SHARED_PREF_KEY, Context.MODE_PRIVATE).edit()
            .putStringSet(SHARED_PREF_KEY_CART_LIST, cartSet).apply()
    }

    private fun getCartSet(): Set<String> {
        val prefs = getSharedPreferences(SHARED_PREF_KEY, Context.MODE_PRIVATE)
        return prefs.getStringSet(SHARED_PREF_KEY_CART_LIST, HashSet()) ?: HashSet()
    }
}
