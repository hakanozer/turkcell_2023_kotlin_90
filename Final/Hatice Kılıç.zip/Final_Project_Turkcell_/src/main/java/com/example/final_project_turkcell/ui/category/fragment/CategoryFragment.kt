package com.example.final_project_turkcell.ui.category.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.final_project_turkcell.databinding.FragmentCategoryBinding
import com.example.final_project_turkcell.model.main_model.Category
import com.example.final_project_turkcell.network.ApiClient
import com.example.final_project_turkcell.network.ServiceResponse
import com.example.final_project_turkcell.ui.category.adapter.CategoryAdapter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CategoryFragment : Fragment(), CategoryAdapter.CategoryClick {

    private lateinit var binding: FragmentCategoryBinding
    private lateinit var categoryAdapter: CategoryAdapter
    private lateinit var serviceResponse: ServiceResponse

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentCategoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        serviceResponse = ApiClient.getClient().create(ServiceResponse::class.java)
        binding.recyclerViewHome.apply {
            setHasFixedSize(true)
            layoutManager = LinearLayoutManager(requireContext())
        }

        serviceResponse.getCategory().enqueue(object : Callback<List<Category>> {
            override fun onResponse(
                call: Call<List<Category>>,
                response: Response<List<Category>>
            ) {
                handleCategoryResponse(response.body())
            }

            override fun onFailure(call: Call<List<Category>>, t: Throwable) {
                Toast.makeText(requireContext(), "onFailure: $t ", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun handleCategoryResponse(categoryList: List<Category>?) {
        if (categoryList != null) {
            categoryAdapter = CategoryAdapter(requireContext(), categoryList, this@CategoryFragment)
            binding.recyclerViewHome.adapter = categoryAdapter
            categoryAdapter.notifyDataSetChanged()
        } else {
            Toast.makeText(requireContext(), "Category list is null", Toast.LENGTH_SHORT).show()
        }
    }

    override fun clickCategory(category: Category) {
    }
}
