package com.example.final_project_turkcell.model.response_model

import com.example.final_project_turkcell.model.main_model.Cart

data class CartResponse(
    val carts: List<Cart>,
    val total: Int,
    val skip: Int,
    val limit: Int
)
