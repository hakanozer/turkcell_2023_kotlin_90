package com.example.final_project_turkcell.ui.product_list.activity

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.final_project_turkcell.R
import com.example.final_project_turkcell.databinding.ActivityProductsListBinding
import com.example.final_project_turkcell.model.main_model.Product
import com.example.final_project_turkcell.model.main_model.Products
import com.example.final_project_turkcell.model.main_model.Root
import com.example.final_project_turkcell.model.response_model.CartResponse
import com.example.final_project_turkcell.network.ApiClient
import com.example.final_project_turkcell.network.ServiceResponse
import com.example.final_project_turkcell.ui.favorite.fragment.FavoriteFragment
import com.example.final_project_turkcell.ui.home.fragment.HomeFragment
import com.example.final_project_turkcell.ui.product_list.adapter.basket.BasketItemAdapter
import com.example.final_project_turkcell.ui.user.fragment.UserFragment
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProductsListActivity : AppCompatActivity() {

    private var selectorFragment: Fragment? = null
    private lateinit var binding: ActivityProductsListBinding
    private lateinit var serviceResponse: ServiceResponse
    private lateinit var basketItemAdapter: BasketItemAdapter
    private lateinit var userProfile: View
    private lateinit var textUserProfile: TextView
    private lateinit var numberProfile: TextView
    private lateinit var emailUser: TextView
    private lateinit var locationUser: TextView
    private lateinit var depUser: TextView
    private lateinit var imgUser: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductsListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        serviceResponse = ApiClient.getClient().create(ServiceResponse::class.java)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction().replace(
                R.id.fragment_container,
                HomeFragment()
            ).commit()
        }

        userProfile = binding.mainNav.getHeaderView(0)
        textUserProfile = userProfile.findViewById(R.id.textViewUserLastName)
        numberProfile = userProfile.findViewById(R.id.textViewUserNumber)
        imgUser = userProfile.findViewById(R.id.imageViewUser)
        emailUser = userProfile.findViewById(R.id.textViewUserEmail)
        locationUser = userProfile.findViewById(R.id.textViewUserLocation)
        depUser = userProfile.findViewById(R.id.userDepartmentInfo)

        val toggle = ActionBarDrawerToggle(
            this, binding.productListDrawer,
            R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        binding.productListDrawer.addDrawerListener(toggle)

        toggle.syncState()

        binding.bottomNavigationView.setOnItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menuHomeItem -> if (selectorFragment !is HomeFragment) {
                    selectorFragment = HomeFragment()
                }

                R.id.menuFavoritesItem -> if (selectorFragment !is FavoriteFragment) {
                    selectorFragment = FavoriteFragment()
                }

                R.id.menuBasketItem -> {
                    cartDialog()
                }

                R.id.menuProfileItem -> if (selectorFragment !is FavoriteFragment) {
                    selectorFragment = UserFragment()

                }
            }
            if (selectorFragment != null) {
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, selectorFragment!!).commit()
            }
            true
        }

        serviceResponse.getUser().enqueue(object : Callback<Root> {
            override fun onResponse(call: Call<Root>, response: Response<Root>) {
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        Glide.with(this@ProductsListActivity)
                            .load(responseBody.image)
                            .into(imgUser)
                        textUserProfile.text = "${responseBody.firstName} ${responseBody.lastName}"
                        numberProfile.text = responseBody.phone
                        emailUser.text = "${responseBody.email}"
                        locationUser.text = "${responseBody.address.address}"
                        depUser.text = "${responseBody.company.department}"
                    }
                } else {
                    Toast.makeText(
                        this@ProductsListActivity,
                        "Error",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<Root>, t: Throwable) {
                Toast.makeText(
                    this@ProductsListActivity,
                    "Error",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    private fun cartDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.row_cart_info)

        dialog.window?.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        dialog.window?.setGravity(Gravity.CENTER)
        dialog.show()

        val rv = dialog.findViewById<RecyclerView>(R.id.recyclerViewCart)
        val totalPrice = dialog.findViewById<TextView>(R.id.textViewTotal)
        val closeBtn = dialog.findViewById<ImageView>(R.id.imageViewClose)
        val buyButton = dialog.findViewById<Button>(R.id.textViewPaid)

        closeBtn.setOnClickListener {
            dialog.dismiss()
        }

        rv.layoutManager = LinearLayoutManager(this)
        rv.setHasFixedSize(true)

        serviceResponse = ApiClient.getClient().create(ServiceResponse::class.java)
        serviceResponse.getCart().enqueue(object : Callback<CartResponse> {
            override fun onResponse(call: Call<CartResponse>, response: Response<CartResponse>) {
                if (response.isSuccessful) {
                    response.body()?.let { _ ->
                        val cartResponse = response.body()
                        val allProducts = mutableListOf<Product>()

                        for (cart in cartResponse!!.carts) {
                            allProducts.addAll(cart.products)
                            totalPrice.text = "Total: ${cart.total}$"
                        }

                        basketItemAdapter = BasketItemAdapter(this@ProductsListActivity, allProducts)
                        rv.adapter = basketItemAdapter
                        basketItemAdapter.notifyDataSetChanged()

                        buyButton.setOnClickListener {
                            serviceResponse.addProduct().enqueue(object : Callback<Products> {
                                override fun onResponse(
                                    call: Call<Products>,
                                    response: Response<Products>
                                ) {
                                }

                                override fun onFailure(call: Call<Products>, t: Throwable) {
                                    Toast.makeText(
                                        this@ProductsListActivity,
                                        t.toString(),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            })
                        }

                    }
                } else {
                    Toast.makeText(
                        this@ProductsListActivity,
                        "Error",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<CartResponse>, t: Throwable) {
                Toast.makeText(
                    this@ProductsListActivity,
                    "Error",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }
}