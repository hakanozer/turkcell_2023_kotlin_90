package com.example.final_project_turkcell.model.info_model

data class Company(
    val address: Address2,
    val department: String,
    val name: String,
    val title: String,
)