package com.example.final_project_turkcell.ui.user.fragment

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.final_project_turkcell.databinding.FragmentUserBinding
import com.example.final_project_turkcell.model.main_model.Root
import com.example.final_project_turkcell.network.ApiClient
import com.example.final_project_turkcell.network.ServiceResponse
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserFragment : Fragment() {

    private lateinit var binding: FragmentUserBinding
    private lateinit var serviceResponse: ServiceResponse

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentUserBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        serviceResponse = ApiClient.getClient().create(ServiceResponse::class.java)

        serviceResponse.getUser().enqueue(object : Callback<Root> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(call: Call<Root>, response: Response<Root>) {
                if (response.isSuccessful) {
                    response.body()?.let { responseBody ->
                        with(binding) {
                            Picasso.get().load(responseBody.image).into(imageViewUserInfo)
                            textViewFirstName.text =
                                "${responseBody.firstName} ${responseBody.lastName}"
                            textViewEmail.text = responseBody.email
                            textViewNumber.text = responseBody.phone
                            textViewLocation.text = responseBody.address.address
                            textViewDepartment.text = responseBody.company.department
                        }
                    }
                } else {
                    showErrorToast(response.code())
                }
            }

            override fun onFailure(call: Call<Root>, t: Throwable) {
                showErrorToast()
            }
        })
    }

    private fun showErrorToast(responseCode: Int? = null) {
        val errorMessage = responseCode ?: "Service Error"
        Toast.makeText(requireContext(), errorMessage.toString(), Toast.LENGTH_SHORT).show()
    }
}
