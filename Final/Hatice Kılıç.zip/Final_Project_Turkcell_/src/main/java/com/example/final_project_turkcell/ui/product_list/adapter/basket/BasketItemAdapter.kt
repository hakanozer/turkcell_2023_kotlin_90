package com.example.final_project_turkcell.ui.product_list.adapter.basket

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.final_project_turkcell.databinding.RowCartInfoItemBinding
import com.example.final_project_turkcell.model.main_model.Product
import com.squareup.picasso.Picasso

class BasketItemAdapter(
    private val mContext: Context,
    private val productList: MutableList<Product>
) :
    RecyclerView.Adapter<BasketItemAdapter.CartViewHolder>() {

    inner class CartViewHolder(val binding: RowCartInfoItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val bindingItem =
            RowCartInfoItemBinding.inflate(LayoutInflater.from(mContext), parent, false)
        return CartViewHolder(bindingItem)
    }

    override fun getItemCount(): Int {
        return productList.size
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) = with(holder.binding) {
        val product = productList[position]
        textViewCartPrice.text = "Price: ${product.price}$"
        textViewCartTitle.text = product.title
        textViewQuantity.text = "Quantity: ${product.quantity}"
        Picasso.get().load(product.thumbnail).into(holder.binding.imageViewCart)

        imageViewMinus.setOnClickListener {
            val currentQuantity = product.quantity
            if (currentQuantity > 0) {
                product.quantity = currentQuantity - 1
                notifyDataSetChanged()
            }
        }

        imageViewPlus.setOnClickListener {
            val currentQuantity = product.quantity
            product.quantity = currentQuantity + 1
            notifyDataSetChanged()
        }

        imageViewDelete.setOnClickListener {
            productList.removeAt(position)
            notifyDataSetChanged()
        }
    }
}