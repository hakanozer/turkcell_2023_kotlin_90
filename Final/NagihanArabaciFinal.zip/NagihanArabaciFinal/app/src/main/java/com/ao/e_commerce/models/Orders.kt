package com.ao.e_commerce.models
//
//data class Orders(
//    val discountedTotal: Int,
//    val id: Int,
//    val products: List<ProductOrders>,
//    val total: Int,
//    val totalProducts: Int,
//    val totalQuantity: Int,
//    val userId: Int
//    val skip :
//)
//
//data class ProductOrders(
//    val discountPercentage: Double,
//    val id: Int,
//    val price: Int,
//    val quantity: Int,
//    val thumbnail: String,
//    val title: String,
//    val discountedPrice: Int,
//    val total : Int,
//)