package com.ao.e_commerce.models.user

data class Hair(
    val color: String,
    val type: String
)