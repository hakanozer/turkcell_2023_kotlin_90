package com.ao.e_commerce.models

data class User(
    val username: String,
    val password: String,
)
