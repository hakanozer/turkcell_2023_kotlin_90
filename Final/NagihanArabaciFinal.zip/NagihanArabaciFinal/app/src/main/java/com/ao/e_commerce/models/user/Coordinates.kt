package com.ao.e_commerce.models.user

data class Coordinates(
    val lat: Double,
    val lng: Double
)