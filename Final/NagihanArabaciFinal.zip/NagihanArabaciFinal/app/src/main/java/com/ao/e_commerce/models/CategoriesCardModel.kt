package com.ao.e_commerce.models

import java.io.Serializable

data class CategoriesCardModel(
    var name:String,
    var isSelect:Boolean
):Serializable