package com.ao.e_commerce.models

data class ProductCartModel(
    val id: String,
    val count: Int
)