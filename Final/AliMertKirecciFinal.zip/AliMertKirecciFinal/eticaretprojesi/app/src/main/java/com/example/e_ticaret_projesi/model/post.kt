package com.example.e_ticaret_projesi.model

import android.provider.ContactsContract.CommonDataKinds.Email
import org.w3c.dom.Comment

data class post( val comment: String,val ErkekGym:String,val KadinGym:String,val Montkaban :String,val Pc:String,val Saat:String,val downloadUrl:String) {
}