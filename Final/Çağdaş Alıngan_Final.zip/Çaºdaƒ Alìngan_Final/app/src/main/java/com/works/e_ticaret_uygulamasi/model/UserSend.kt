package com.works.e_ticaret_uygulamasi.model

data class UserSend (
    val username : String,
    val password : String
    )