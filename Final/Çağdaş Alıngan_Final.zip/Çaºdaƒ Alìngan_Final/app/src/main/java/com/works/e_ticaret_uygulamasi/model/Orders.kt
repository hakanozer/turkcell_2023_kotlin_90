package com.works.e_ticaret_uygulamasi.model

import java.io.Serializable

data class Orders (
    val carts: List<Cart>,
    val total: Long,
    val skip: Long,
    val limit: Long
)

data class Cart (
    val id: Long,
    val products: List<ProductOrder>,
    val total: Long,
    val discountedTotal: Long,
    val userID: Long,
    val totalProducts: Long,
    val totalQuantity: Long
)

data class ProductOrder (
    val id: Long,
    val title: String,
    val price: Long,
    val quantity: Long,
    val total: Long,
    val discountPercentage: Double,
    val discountedPrice: Long,
    val thumbnail: String
) : Serializable

