package com.works.e_ticaret_uygulamasi.Adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.works.e_ticaret_uygulamasi.databinding.RecyclerItemBinding
import com.works.e_ticaret_uygulamasi.databinding.RecyclerSiparisBinding
import com.works.e_ticaret_uygulamasi.model.Cart
import com.works.e_ticaret_uygulamasi.model.ProductOrder

class OrderAdapter(private var list: List<ProductOrder>) : RecyclerView.Adapter<OrderAdapter.Holder>() {
    class Holder(val binding: RecyclerSiparisBinding): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val inflater = LayoutInflater.from(parent.context)
        val view = RecyclerSiparisBinding.inflate(inflater,parent,false)
        return Holder(view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val currentItem = list[position]

        holder.binding.apply {
            textView3.text = currentItem.title
            textView5.text = "Price : ${currentItem.price}"





            Glide.with(root.context)
                .load(currentItem.thumbnail)
                .into(imageView3)

        }


    }


}