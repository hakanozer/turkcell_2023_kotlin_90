package com.works.e_ticaret_uygulamasi.model

data class UpdateProfile(
    val id: String,
    val firstName: String,
    val lastName: String,
    val email: String,
    val phone: String,
    val gender: String
)
