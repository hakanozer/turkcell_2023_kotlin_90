package com.works.e_ticaret_uygulamasi.Adapter


import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.works.e_ticaret_uygulamasi.config.ApiClient
import com.works.e_ticaret_uygulamasi.databinding.KategoriRecyclerBinding
import com.works.e_ticaret_uygulamasi.model.KategoriyeAitUrunler
import com.works.e_ticaret_uygulamasi.sevices.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class KategoriAdapter(private var list: List<String> ): RecyclerView.Adapter<KategoriAdapter.KategoriHolder>() {

     private val dummyService: DummyService = ApiClient.getClient().create(DummyService::class.java)

    class KategoriHolder(val binding: KategoriRecyclerBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): KategoriHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = KategoriRecyclerBinding.inflate(inflater, parent, false)
        return KategoriHolder(view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: KategoriHolder, position: Int) {
        val currentItem = list[position]

        holder.binding.apply {
            btnKategori.text = currentItem


            btnKategori.setOnClickListener {



                dummyService.categoryProduct("smartphones").enqueue(object : Callback<KategoriyeAitUrunler>{
                    override fun onResponse(call: Call<KategoriyeAitUrunler>, response: Response<KategoriyeAitUrunler>) {
                        if (response.isSuccessful){
                            response.body()?.let {

                                Log.d("smartphones",it.products.toString())


                            }
                        }
                    }

                    override fun onFailure(call: Call<KategoriyeAitUrunler>, t: Throwable) {
                        Log.e("Service Error", t.toString())
                    }
                })
            }
        }




        fun updateList(newList: List<String>) {
            list = newList
            notifyDataSetChanged()
        }
    }


}