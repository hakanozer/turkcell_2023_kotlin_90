package com.works.e_ticaret_uygulamasi

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.bumptech.glide.Glide
import com.works.e_ticaret_uygulamasi.config.ApiClient
import com.works.e_ticaret_uygulamasi.databinding.ActivityProductDetailsBinding
import com.works.e_ticaret_uygulamasi.model.Product
import com.works.e_ticaret_uygulamasi.model.Products
import com.works.e_ticaret_uygulamasi.sevices.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProductDetails : AppCompatActivity() {

    private lateinit var dummyService: DummyService
    private lateinit var binding: ActivityProductDetailsBinding
    private lateinit var list: ArrayList<Product>
    private  var selectedProduct: Product? = null





    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)




        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        dummyService = ApiClient.getClient().create(DummyService::class.java)
        list = ArrayList()


        dummyService.twentyProducts().enqueue(object : Callback<Products>{
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                if (response.isSuccessful){
                    response.body()?.let {products ->
                        if (products.products.isNotEmpty()){
                             selectedProduct = intent.getSerializableExtra("product") as? Product

                            selectedProduct?.let {
                                binding.apply {
                                    txtBaslik.text = it.title
                                    txtPrice.text = "Price: ${it.price}"
                                    txtRating.text = "Rate : ${it.rating}"
                                    txtStock.text = "Stock : ${it.stock}"
                                }

                                Glide.with(this@ProductDetails)
                                    .load(it.thumbnail)
                                    .into(binding.imageView2)

                                binding.btnEkle.setOnClickListener {



                                }
                            }
                        }else{
                            Log.e("Response", "Products list is empty")
                        }
                    }
                } else {
                    Log.e("Response", "Fail")
                }



            }

            override fun onFailure(call: Call<Products>, t: Throwable) {
                Log.e("Fail", t.toString())
            }
        })

        }






    }


