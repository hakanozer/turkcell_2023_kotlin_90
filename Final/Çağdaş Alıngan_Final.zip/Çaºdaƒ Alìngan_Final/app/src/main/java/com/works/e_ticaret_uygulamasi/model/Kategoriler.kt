package com.works.e_ticaret_uygulamasi.model

typealias Kategoriler = ArrayList<String>
