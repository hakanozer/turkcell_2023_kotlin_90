package com.works.e_ticaret_uygulamasi.sevices


import com.works.e_ticaret_uygulamasi.model.AddCartRequest
import com.works.e_ticaret_uygulamasi.model.Addcart
import com.works.e_ticaret_uygulamasi.model.AddcartResponse
import com.works.e_ticaret_uygulamasi.model.JWTUser
import com.works.e_ticaret_uygulamasi.model.Kategoriler
import com.works.e_ticaret_uygulamasi.model.KategoriyeAitUrunler
import com.works.e_ticaret_uygulamasi.model.Orders
import com.works.e_ticaret_uygulamasi.model.Products
import com.works.e_ticaret_uygulamasi.model.Profile
import com.works.e_ticaret_uygulamasi.model.UpdateProfile
import com.works.e_ticaret_uygulamasi.model.UserSend
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

interface DummyService {
    @POST("auth/login")
    fun login(@Body userSend: UserSend): Call<JWTUser>

    @GET("products")
    fun allProducts () : Call<Products>

    @GET("products?limit=20")
    fun twentyProducts() : Call<Products>

    @GET("products/search?")
    fun filter(@Query("q") q:String) : Call<Products>

    @GET("products/categories")
    fun categories(): Call<Kategoriler>

    @GET("products/category/{category}")
    fun categoryProduct(@Path("category") category: String): Call<KategoriyeAitUrunler>

    @GET("carts/user/5")
    fun order(): Call<Orders>

    @POST("carts/add")
    fun cartsAdd(@Body request: AddCartRequest): Call<AddcartResponse>

    @GET("users/1")
    fun profile(): Call<Profile>

    @PUT("users/1")
    fun update(): Call<UpdateProfile>


}