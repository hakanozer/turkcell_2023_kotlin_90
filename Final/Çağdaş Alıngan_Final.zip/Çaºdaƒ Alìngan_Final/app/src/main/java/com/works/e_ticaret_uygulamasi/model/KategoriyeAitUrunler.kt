package com.works.e_ticaret_uygulamasi.model

data class KategoriyeAitUrunler (
    val products: List<ProductKategori>,
    val total: Long,
    val skip: Long,
    val limit: Long
)

data class ProductKategori (
    val id: Long,
    val title: String,
    val description: String,
    val price: Long,
    val discountPercentage: Double,
    val rating: Double,
    val stock: Long,
    val brand: String,
    val category: String,
    val thumbnail: String,
    val images: List<String>
)
