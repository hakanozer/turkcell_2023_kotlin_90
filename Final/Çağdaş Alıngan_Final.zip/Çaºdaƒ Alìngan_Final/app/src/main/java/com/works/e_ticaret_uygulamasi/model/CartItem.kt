package com.works.e_ticaret_uygulamasi.model

data class CartItem(
    val id: Long,
    val quantity: Long
)

data class AddCartRequest(
    val userId: Long,
    val products: List<CartItem>
)

data class AddcartResponse(
    val id: Long,
    val products: List<ProductAddCart>,
    val total: Long,
    val discountedTotal: Long,
    val userId: Long,
    val totalProducts: Long,
    val totalQuantity: Long
)
