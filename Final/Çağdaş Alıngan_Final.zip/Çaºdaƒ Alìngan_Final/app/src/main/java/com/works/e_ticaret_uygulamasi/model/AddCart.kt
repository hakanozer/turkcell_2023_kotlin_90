package com.works.e_ticaret_uygulamasi.model

data class Addcart (
    val id: Long,
    val products: List<ProductAddCart>,
    val total: Long,
    val discountedTotal: Long,
    val userID: Long,
    val totalProducts: Long,
    val totalQuantity: Long
)

data class ProductAddCart (
    val id: Long,
    val title: String,
    val price: Long,
    val quantity: Long,
    val total: Long,
    val discountPercentage: Double,
    val discountedPrice: Long,
    val thumbnail: String
)
