package com.works.e_ticaret_uygulamasi.Adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.works.e_ticaret_uygulamasi.config.ApiClient
import com.works.e_ticaret_uygulamasi.databinding.ProfileRecyclerItemBinding
import com.works.e_ticaret_uygulamasi.model.Profile
import com.works.e_ticaret_uygulamasi.model.UpdateProfile
import com.works.e_ticaret_uygulamasi.sevices.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProfileAdapter(private var list: List<Profile>) : RecyclerView.Adapter<ProfileAdapter.HolderProfile>() {
    class HolderProfile(val binding: ProfileRecyclerItemBinding) : RecyclerView.ViewHolder(binding.root)

    lateinit var dummyService: DummyService

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolderProfile {
        val inflater = LayoutInflater.from(parent.context)
        val view = ProfileRecyclerItemBinding.inflate(inflater, parent, false)
        return HolderProfile(view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: HolderProfile, position: Int) {
        val currentItem = list[position]

        holder.binding.apply {
            txtOrder.text = "Firstname: ${currentItem.firstName}"
            txtOrderFiyat.text = "Lastname : ${currentItem.lastName}"
            textView10.text = "Age : ${currentItem.age}"
            textView11.text = "E-Mail : ${currentItem.email}"
            textView12.text = "Gender : ${currentItem.gender}"
            btnUpdate.setOnClickListener {

                dummyService = ApiClient.getClient().create(DummyService::class.java)

                dummyService.update().enqueue(object : Callback<UpdateProfile> {
                    override fun onResponse(call: Call<UpdateProfile>, response: Response<UpdateProfile>) {
                        if (response.isSuccessful){

                            response.body()?.let {
                                Log.d("UPDATE SUCCESS", response.code().toString())
                                Toast.makeText(holder.binding.root.context,"Profil güncellendi",Toast.LENGTH_SHORT).show()
                            }
                        }else{
                            Log.e("UPDATE Error", "Response not successful: ${response.code()}")
                        }
                    }

                    override fun onFailure(call: Call<UpdateProfile>, t: Throwable) {
                        Log.e("UPDATE Error", t.toString())
                    }
                })
            }





            Glide.with(root.context)
                .load("https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_1280.png")
                .into(imgOrder)
        }
    }




}




