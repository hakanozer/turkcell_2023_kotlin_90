package com.works.e_ticaret_uygulamasi.Adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.works.e_ticaret_uygulamasi.databinding.RecyclerSiparisBinding
import com.works.e_ticaret_uygulamasi.model.ProductAddCart

class SiparisAdapter(private var list: List<ProductAddCart>) : RecyclerView.Adapter<SiparisAdapter.HolderSiparis>() {
    class HolderSiparis(val binding : RecyclerSiparisBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolderSiparis {
        val inflater = LayoutInflater.from(parent.context)
        val view = RecyclerSiparisBinding.inflate(inflater,parent,false)
        return HolderSiparis(view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: HolderSiparis, position: Int) {
        val currentIem = list[position]

        holder.binding.apply {
            textView3.text = currentIem.title
            textView5.text = "Price : ${currentIem.price}"

            Glide.with(root.context)
                .load(currentIem.thumbnail)
                .into(imageView3)
        }
    }
}