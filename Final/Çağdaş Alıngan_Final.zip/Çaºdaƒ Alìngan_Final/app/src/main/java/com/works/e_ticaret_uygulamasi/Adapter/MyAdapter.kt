package com.works.e_ticaret_uygulamasi.Adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.works.e_ticaret_uygulamasi.ProductDetails
import com.works.e_ticaret_uygulamasi.databinding.RecyclerItemBinding
import com.works.e_ticaret_uygulamasi.model.Product

class MyAdapter(private var list: List<Product>) : RecyclerView.Adapter<MyAdapter.Hold>() {
    class Hold(val binding: RecyclerItemBinding):RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Hold {
        val inflater = LayoutInflater.from(parent.context)
        val view = RecyclerItemBinding.inflate(inflater,parent,false)
        return Hold(view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: Hold, position: Int) {
        val currentItem = list[position]

        holder.binding.apply {

            root.setOnClickListener {
                val intent = Intent(it.context, ProductDetails::class.java)
                intent.putExtra("product", currentItem)
                it.context.startActivity(intent)
            }


            txtTitle.text = currentItem.title
            txtFiyat.text = "Price : ${currentItem.price}"

            Glide.with(root.context)
                .load(currentItem.thumbnail)
                .into(imgUrun)


        }
    }
    fun updateList(newList: List<Product>) {
        list = newList
        notifyDataSetChanged()
    }
}