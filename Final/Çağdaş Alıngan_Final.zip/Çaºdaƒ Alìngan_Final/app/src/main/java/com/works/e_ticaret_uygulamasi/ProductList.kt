package com.works.e_ticaret_uygulamasi

import android.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.widget.SearchView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.works.e_ticaret_uygulamasi.Adapter.KategoriAdapter
import com.works.e_ticaret_uygulamasi.Adapter.MyAdapter
import com.works.e_ticaret_uygulamasi.Adapter.OrderAdapter
import com.works.e_ticaret_uygulamasi.Adapter.ProfileAdapter
import com.works.e_ticaret_uygulamasi.config.ApiClient
import com.works.e_ticaret_uygulamasi.databinding.ActivityProductListBinding
import com.works.e_ticaret_uygulamasi.model.AddCartRequest
import com.works.e_ticaret_uygulamasi.model.AddcartResponse
import com.works.e_ticaret_uygulamasi.model.Cart
import com.works.e_ticaret_uygulamasi.model.CartItem
import com.works.e_ticaret_uygulamasi.model.Kategoriler
import com.works.e_ticaret_uygulamasi.model.Orders
import com.works.e_ticaret_uygulamasi.model.Product
import com.works.e_ticaret_uygulamasi.model.Products
import com.works.e_ticaret_uygulamasi.model.Profile
import com.works.e_ticaret_uygulamasi.sevices.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProductList : AppCompatActivity() {

    private lateinit var binding: ActivityProductListBinding
    private lateinit var toggle: ActionBarDrawerToggle
    private lateinit var dummyService: DummyService
    private lateinit var adapter: MyAdapter
    private lateinit var orderAdapter: OrderAdapter
    private lateinit var kategoriAdapter: KategoriAdapter
    private lateinit var kategoriList: Kategoriler
    private lateinit var list : ArrayList<Product>
    private lateinit var _list : ArrayList<Cart>
    private lateinit var profile: ArrayList<Profile>
    private lateinit var profileAdapter: ProfileAdapter



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dummyService = ApiClient.getClient().create(DummyService::class.java)

        binding.rcyclrView.setHasFixedSize(true)
        binding.rcyclrView.layoutManager = GridLayoutManager(this,2)



        dummyService.twentyProducts().enqueue(object : Callback<Products>{

            override fun onResponse(call: Call<Products>, response: Response<Products>) {

                if (response.isSuccessful){
                    response.body()?.let {
                        Log.d("products", it.products.toString())
                        list = ArrayList(it.products)
                        adapter = MyAdapter(list)
                        binding.rcyclrView.adapter = adapter

                    }
                }else{
                    Log.e("list", "${response.code()}" )
                }
            }

            override fun onFailure(call: Call<Products>, t: Throwable) {
                Log.e("Service Error", t.toString() )
            }
        })




        binding.srchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                Log.d("Search", "Query: $newText")
                if(newText.orEmpty().isNotEmpty()){
                    dummyService.filter(newText.orEmpty()).enqueue(object : Callback<Products>{
                        override fun onResponse(call: Call<Products>, response: Response<Products>) {
                            if (response.isSuccessful){
                                response.body()?.let {
                                    list.clear()
                                    list.addAll(it.products)
                                    adapter.notifyDataSetChanged()
                                }
                        }
                        }

                        override fun onFailure(call: Call<Products>, t: Throwable) {
                            Log.e("Error", "Filter request failed", t)
                        }
                    })
                }else{

                    adapter.updateList(list)
                    adapter.notifyDataSetChanged()
                }
                return true
            }
        })



        binding.apply {
            toggle = ActionBarDrawerToggle(this@ProductList,drawerlayout,R.string.open,R.string.close)
            drawerlayout.addDrawerListener(toggle)
            toggle.syncState()




            supportActionBar?.setDisplayHomeAsUpEnabled(true)

            navView.setNavigationItemSelectedListener {
                when(it.itemId){
                    R.id.anasayfa_menu->{
                        dummyService = ApiClient.getClient().create(DummyService::class.java)

                        binding.rcyclrView.setHasFixedSize(true)
                        binding.rcyclrView.layoutManager = GridLayoutManager(applicationContext,2)


                        dummyService.allProducts().enqueue(object : Callback<Products>{
                            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                                if (response.isSuccessful){
                                    response.body()?.let {
                                        list = ArrayList(it.products)
                                        adapter = MyAdapter(list)
                                        binding.rcyclrView.adapter=adapter
                                    }
                                }else{
                                    Log.e("list","${response.code()}" )
                                }
                            }

                            override fun onFailure(call: Call<Products>, t: Throwable) {
                                Log.e("Service Error", t.toString() )
                            }
                        })

                    }
                    R.id.kategori_menu -> {
                        dummyService = ApiClient.getClient().create(DummyService::class.java)

                        kategoriList = Kategoriler()

                        binding.rcyclrView.setHasFixedSize(true)
                        binding.rcyclrView.layoutManager = GridLayoutManager(applicationContext, 2)


                        dummyService.categories().enqueue(object : Callback<Kategoriler> {
                            override fun onResponse(call: Call<Kategoriler>, response: Response<Kategoriler>) {
                                if (response.isSuccessful) {
                                    response.body()?.let {
                                        Log.d("Kategoriler", it.toString())
                                        kategoriList = ArrayList(it)
                                        kategoriAdapter = KategoriAdapter(kategoriList)
                                        binding.rcyclrView.adapter=kategoriAdapter
                                    }
                                }
                            }

                            override fun onFailure(call: Call<Kategoriler>, t: Throwable) {
                                Log.e("Service Error", t.toString())
                            }
                        })


                    }

                    R.id.sepetim_menu->{
                        dummyService = ApiClient.getClient().create(DummyService::class.java)
                        binding.rcyclrView.setHasFixedSize(true)
                        binding.rcyclrView.layoutManager = GridLayoutManager(applicationContext,2)

                        dummyService.order().enqueue(object : Callback<Orders>{
                            override fun onResponse(call: Call<Orders>, response: Response<Orders>) {
                                if(response.isSuccessful){
                                    response.body()?.let {
                                        Log.d("order", it.carts.toString())
                                        _list = ArrayList(it.carts)
                                        orderAdapter= OrderAdapter(_list[0].products)
                                        binding.rcyclrView.adapter=orderAdapter

                                    }

                                }else {
                                    Log.e("sipariş", "${response.code()}")
                                }
                            }

                            override fun onFailure(call: Call<Orders>, t: Throwable) {
                                Log.e("Sipariş Error", t.toString())
                            }
                        })





                    }
                    R.id.siparis_menu->{
                        dummyService = ApiClient.getClient().create(DummyService::class.java)
                        binding.rcyclrView.setHasFixedSize(true)
                        binding.rcyclrView.layoutManager = GridLayoutManager(applicationContext,2)
                        val cartItems = listOf(
                            CartItem(id = 1, quantity = 1),
                            CartItem(id = 50, quantity = 2)
                        )

                        val addCartRequest = AddCartRequest(userId = 1, products = cartItems)

                        dummyService.cartsAdd(request = addCartRequest).enqueue(object :Callback<AddcartResponse>{
                            override fun onResponse(call: Call<AddcartResponse>, response: Response<AddcartResponse>) {
                                if (response.isSuccessful) {

                                    response.body()?.let { addcartResponse ->

                                        Log.d("SİPARİŞ", addcartResponse.products.toString())

                                        Log.d("RESPONSE KOD", response.code().toString())

                                        Toast.makeText(applicationContext,"Sipariş verildi",Toast.LENGTH_SHORT).show()
                                    }
                                } else {

                                    Log.e("Sipariş Error", "Response not successful: ${response.code()}")

                                    Log.e("Sipariş Error", "Response body: ${response.errorBody()?.string()}")
                                }

                            }

                            override fun onFailure(call: Call<AddcartResponse>, t: Throwable) {
                                Log.e("Sipariş Error", "Failure: ${t.message}")
                            }
                        })


                    }
                    R.id.profil_menu->{
                        dummyService = ApiClient.getClient().create(DummyService::class.java)
                        binding.rcyclrView.setHasFixedSize(true)
                        binding.rcyclrView.layoutManager = GridLayoutManager(applicationContext,1)


                        dummyService.profile().enqueue(object : Callback<Profile>{
                            override fun onResponse(call: Call<Profile>, response: Response<Profile>) {
                                if (response.isSuccessful){
                                    response.body()?.let {
                                        Log.d("PRofile", it.toString())
                                        profile= ArrayList(listOf(it))
                                        profileAdapter = ProfileAdapter(profile)
                                        binding.rcyclrView.adapter=profileAdapter
                                    }
                                }
                            }

                            override fun onFailure(call: Call<Profile>, t: Throwable) {
                                Log.e("Profil Error", t.toString())
                            }
                        })


                    }
                    R.id.bildirim_menu->{


                    }
                    R.id.ayarlar_menu->{

                    }
                    R.id.exit_menu->{

                        exit()
                    }
                }
                true
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if (toggle.onOptionsItemSelected(item))
            true

        return super.onOptionsItemSelected(item)
    }



    fun fragmentCall(fragment: Fragment){
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()

        Log.d("FragmentCall", "Replacing fragment with ${fragment.javaClass.simpleName}")

        fragmentTransaction.replace(R.id.fragmentConteiner,fragment)
        fragmentTransaction.commit()
    }

     fun exit() {
        val builder = AlertDialog.Builder(this)

        builder.setTitle("Çıkış")
            .setMessage("Çıkış yapmak istiyor musunuz?")
            .setPositiveButton("Evet") { dialog, which ->

                finish()
            }
            .setNegativeButton("Hayır") { dialog, which ->

                dialog.dismiss()
            }
            .setCancelable(false)

        val dialog = builder.create()
        dialog.show()
    }


}
