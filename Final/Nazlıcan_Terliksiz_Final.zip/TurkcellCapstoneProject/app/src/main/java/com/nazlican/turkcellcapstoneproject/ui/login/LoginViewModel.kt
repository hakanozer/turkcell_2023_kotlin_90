package com.nazlican.turkcellcapstoneproject.ui.login

import android.util.Patterns
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nazlican.turkcellcapstoneproject.common.Resource
import com.nazlican.turkcellcapstoneproject.data.model.login.UserInfo
import com.nazlican.turkcellcapstoneproject.data.model.login.User
import com.nazlican.turkcellcapstoneproject.data.repo.LoginRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(private val loginRepository: LoginRepository) :
    ViewModel() {

    private var _loginState = MutableLiveData<LoginState>()

    val loginState: LiveData<LoginState> get() = _loginState

    fun login(user: User) = viewModelScope.launch {
        if (checkFields(user)) {
            _loginState.value = LoginState.Loading

            _loginState.value = when (val result = loginRepository.login(user)) {
                is Resource.Success -> LoginState.SuccessLoginState(result.data)
                is Resource.Error -> LoginState.ShowPopUp(result.errorMessage)
                is Resource.Fail -> LoginState.ShowPopUp(result.failMessage)
            }
        }
    }

    private fun checkFields(user: User): Boolean {
        return when {
            user.username?.isEmpty() == true -> {
                _loginState.value = LoginState.ShowPopUp("username can't be empty")
                false
            }

            user.password?.isEmpty() == true -> {
                _loginState.value = LoginState.ShowPopUp("password can't be empty")
                false
            }

            else -> true
        }
    }
}

sealed interface LoginState {

    object Loading : LoginState

    data class SuccessLoginState(val user: UserInfo) : LoginState

    data class ShowPopUp(val errorMessage: String) : LoginState
}