package com.nazlican.turkcellcapstoneproject.util.storage

import android.content.Context
import com.nazlican.turkcellcapstoneproject.data.model.login.Token

class SharedPrefManager private constructor(mCtx: Context) {

    val sharedPreferences =
        mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
    val editor = sharedPreferences.edit()

    val data: Token
        get() {
            return Token(
                sharedPreferences.getString("token", null) ?: "",
            )
        }

    fun saveUser(token: Token) {
        editor.putString("token", token.token)
        editor.apply()
    }

    //sign out oldugunda cagir
    fun clear() {
        editor.clear()
        editor.apply()
    }

    companion object {
        private val SHARED_PREF_NAME = "my_shared_preff"
        private var mInstance: SharedPrefManager? = null

        @Synchronized
        fun getInstance(mCtx: Context): SharedPrefManager {
            if (mInstance == null) {
                mInstance = SharedPrefManager(mCtx)
            }
            return mInstance as SharedPrefManager
        }
    }
}