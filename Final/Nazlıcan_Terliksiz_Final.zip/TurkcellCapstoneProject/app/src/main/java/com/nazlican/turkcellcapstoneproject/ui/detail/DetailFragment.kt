package com.nazlican.turkcellcapstoneproject.ui.detail

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.nazlican.turkcellcapstoneproject.R
import com.nazlican.turkcellcapstoneproject.common.viewBinding
import com.nazlican.turkcellcapstoneproject.data.model.product.ProductEntity
import com.nazlican.turkcellcapstoneproject.data.model.product.Products
import com.nazlican.turkcellcapstoneproject.databinding.FragmentDetailBinding
import com.nazlican.turkcellcapstoneproject.util.extension.downloadFromUrl
import com.nazlican.turkcellcapstoneproject.util.extension.gone
import com.nazlican.turkcellcapstoneproject.util.extension.snackbar
import com.nazlican.turkcellcapstoneproject.util.extension.visible
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class DetailFragment : Fragment(R.layout.fragment_detail) {

    private val binding by viewBinding(FragmentDetailBinding::bind)
    private val viewModel: DetailViewModel by viewModels()
    private val args: DetailFragmentArgs by navArgs()
    private lateinit var products: Products

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val id = args.id
        viewModel.getDetailProduct(id)
        detailProductObserve()

        with(binding) {
            back.setOnClickListener {
                findNavController().popBackStack()
            }
            AddToCartbutton.setOnClickListener {
                val productEntity =  ProductEntity(
                    products.id,
                    products.images.get(0),
                    products.price,
                    products.rating,
                    products.title,
                    products.isFav
                )
                viewModel.addToCart(productEntity)
                view?.snackbar("Product added!")

            }
        }
    }

    private fun detailProductObserve() = with(binding) {
        viewModel.detailState.observe(viewLifecycleOwner) { state ->
            when (state) {
                DetailState.Loading -> {
                    detailProgressBar.visible()
                }

                is DetailState.SuccessState -> {
                    detailProgressBar.gone()
                    products = state.products
                    detailProductIv.downloadFromUrl(state.products.images.get(0))
                    detailProductTitleTv.text = state.products.title
                    detailProductCategoryNameTv.text = state.products.category
                    detailProductDescriptionTv.text = state.products.description
                    detailProductRatingBar.rating = state.products.rating.toFloat()
                    priceTv.text = "${state.products.price.toString()} ₺"
                }

                is DetailState.EmptyScreen -> {
                    detailProgressBar.gone()
                    detailEmptyIv.visible()
                    detailEmptyTv.visible()
                    detailEmptyTv.text = state.failMessage
                }

                is DetailState.ShowPopUp -> {
                    detailProgressBar.gone()
                    view?.snackbar(state.errorMessage)
                }
            }
        }
    }
}