package com.nazlican.turkcellcapstoneproject.di

import com.nazlican.turkcellcapstoneproject.data.repo.CartRepository
import com.nazlican.turkcellcapstoneproject.data.repo.DetailRepository
import com.nazlican.turkcellcapstoneproject.data.repo.HomeRepository
import com.nazlican.turkcellcapstoneproject.data.repo.LoginRepository
import com.nazlican.turkcellcapstoneproject.data.repo.ProfileRepository
import com.nazlican.turkcellcapstoneproject.data.source.local.ProductDao
import com.nazlican.turkcellcapstoneproject.data.source.remote.ProductService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    @Singleton
    fun provideHomeRepository(productService: ProductService) = HomeRepository(productService)

    @Provides
    @Singleton
    fun provideDetailRepository(productService: ProductService) =
        DetailRepository(productService)

    @Provides
    @Singleton
    fun provideCartRepository(productDao: ProductDao) = CartRepository(productDao)

    @Provides
    @Singleton
    fun provideLoginRepository(productService: ProductService) = LoginRepository(productService)

    @Provides
    @Singleton
    fun provideProfileRepository(productService: ProductService) = ProfileRepository(productService)

}