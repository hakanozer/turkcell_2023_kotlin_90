package com.nazlican.turkcellcapstoneproject.data.repo

import com.nazlican.turkcellcapstoneproject.common.Resource
import com.nazlican.turkcellcapstoneproject.data.model.login.UserInfo
import com.nazlican.turkcellcapstoneproject.data.model.login.User
import com.nazlican.turkcellcapstoneproject.data.source.remote.ProductService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.lang.Exception

class LoginRepository(private val productService: ProductService) {

    suspend fun login(user: User): Resource<UserInfo> =
        withContext(Dispatchers.IO) {
            try {
                val response = productService.login(user)
                val user = response.body()
                if (response.isSuccessful && user != null){
                    Resource.Success(user)
                }else {
                    Resource.Fail("An error occurred")
                }
            } catch (e: Exception) {
                Resource.Error(e.message.orEmpty())
            }
        }
}
