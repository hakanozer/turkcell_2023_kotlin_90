package com.nazlican.turkcellcapstoneproject.MessagingService

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        Log.d("Token", "onNewToken: $token")
    }

    override fun onMessageReceived(message: RemoteMessage) {
        Log.d("Message",  "${message.messageId}")
        Log.d("Message",  "${message.from}")

        if (message.data.isNotEmpty()){
            Log.d("message", "${message.data}")
        }

        message.notification?.let {
            Log.d("Message", "${it.body}")
        }
    }
}