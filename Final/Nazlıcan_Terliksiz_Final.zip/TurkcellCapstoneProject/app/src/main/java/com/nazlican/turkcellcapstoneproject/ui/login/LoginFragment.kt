package com.nazlican.turkcellcapstoneproject.ui.login

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.nazlican.turkcellcapstoneproject.R
import com.nazlican.turkcellcapstoneproject.common.viewBinding
import com.nazlican.turkcellcapstoneproject.data.model.login.Token
import com.nazlican.turkcellcapstoneproject.data.model.login.User
import com.nazlican.turkcellcapstoneproject.databinding.FragmentLoginBinding
import com.nazlican.turkcellcapstoneproject.util.extension.gone
import com.nazlican.turkcellcapstoneproject.util.extension.snackbar
import com.nazlican.turkcellcapstoneproject.util.extension.visible
import com.nazlican.turkcellcapstoneproject.util.storage.SharedPrefManager
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoginFragment : Fragment(R.layout.fragment_login) {

    private val binding by viewBinding(FragmentLoginBinding::bind)
    private val loginViewModel: LoginViewModel by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        with(binding) {
            loginButton.setOnClickListener {
                val userName = userNameEt.text.toString()
                val password = passwordEt.text.toString()

                loginViewModel.login(User(userName, password))
            }
        }
        detailProductObserve()

        val savedToken = SharedPrefManager.getInstance(requireContext()).data

        if (savedToken.token.isNotEmpty()) {
            findNavController().navigate(R.id.action_loginFragment_to_homeFragment)
        }
    }

    private fun detailProductObserve() = with(binding) {
        loginViewModel.loginState.observe(viewLifecycleOwner) { state ->
            when (state) {
                LoginState.Loading -> {
                    loginProgressBar.visible()
                }

                is LoginState.SuccessLoginState -> {
                    loginProgressBar.gone()
                    findNavController().navigate(R.id.action_loginFragment_to_homeFragment)

                    SharedPrefManager.getInstance(requireContext())
                        .saveUser(Token("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTUsInVzZXJuYW1lIjoia21pbmNoZWxsZSIsImVtYWlsIjoia21pbmNoZWxsZUBxcS5jb20iLCJmaXJzdE5hbWUiOiJKZWFubmUiLCJsYXN0TmFtZSI6IkhhbHZvcnNvbiIsImdlbmRlciI6ImZlbWFsZSIsImltYWdlIjoiaHR0cHM6Ly9yb2JvaGFzaC5vcmcvYXV0cXVpYXV0LnBuZz9zaXplPTUweDUwJnNldD1zZXQxIiwiaWF0IjoxNjM1NzczOTYyLCJleHAiOjE2MzU3Nzc1NjJ9.n9PQX8w8ocKo0dMCw3g8bKhjB8Wo7f7IONFBDqfxKhs"))
                }

                is LoginState.ShowPopUp -> {
                    view?.snackbar(state.errorMessage)
                }
            }
        }
    }
}