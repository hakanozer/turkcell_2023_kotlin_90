package com.nazlican.turkcellcapstoneproject.data.source.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.nazlican.turkcellcapstoneproject.data.model.product.ProductEntity

@Dao
interface ProductDao {

    @Query("SELECT * FROM cart_products")
    suspend fun getProducts(): List<ProductEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addProduct(productEntity: ProductEntity)

    @Delete
    suspend fun deleteProduct(productEntity: ProductEntity)

    @Query("DELETE FROM cart_products")
    suspend fun clearAllCarts()
}