package com.nazlican.turkcellcapstoneproject.ui.profile

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.nazlican.turkcellcapstoneproject.R
import com.nazlican.turkcellcapstoneproject.common.viewBinding
import com.nazlican.turkcellcapstoneproject.databinding.FragmentProfileBinding
import com.nazlican.turkcellcapstoneproject.util.extension.gone
import com.nazlican.turkcellcapstoneproject.util.extension.snackbar
import com.nazlican.turkcellcapstoneproject.util.extension.visible
import com.nazlican.turkcellcapstoneproject.util.storage.SharedPrefManager
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ProfileFragment : Fragment(R.layout.fragment_profile) {

    private val binding by viewBinding(FragmentProfileBinding::bind)
    private val viewModel: ProfileViewModel by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.getUserInfo()
        getUserInfoObserve()

        with(binding) {
            myOrdersTv.setOnClickListener {
                findNavController().navigate(R.id.action_profileFragment_to_myOrdersFragment)
            }
            updateProfileTv.setOnClickListener {
                findNavController().navigate(R.id.action_profileFragment_to_updateProfileFragment)
            }
            logout.setOnClickListener {
                SharedPrefManager.getInstance(requireContext()).clear()
                findNavController().navigate(R.id.action_profileFragment_to_loginFragment)
            }
        }
    }

    fun getUserInfoObserve() = with(binding) {
        viewModel.profileState.observe(viewLifecycleOwner) { state ->
            when (state) {
                ProfileState.Loading -> profileProgressBar.visible()

                is ProfileState.SuccesState -> {
                    profileProgressBar.gone()
                    firstNameTv.text = "Name: ${state.profile.firstName}"
                    lasttNameTv.text = "Surname: ${state.profile.lastName}"
                    mailTv.text = state.profile.email
                    phoneNumberTv.text = "Phone Number: ${state.profile.phone}"
                    adressTv.text = "Adress: ${state.profile.address.toString()}"
                }

                is ProfileState.EmptyScreen -> {
                    view?.snackbar(state.failMessage)
                }

                is ProfileState.ShowPopUp -> {
                    profileProgressBar.gone()
                    view?.snackbar(state.errorMessage)
                }
            }

        }
    }
}