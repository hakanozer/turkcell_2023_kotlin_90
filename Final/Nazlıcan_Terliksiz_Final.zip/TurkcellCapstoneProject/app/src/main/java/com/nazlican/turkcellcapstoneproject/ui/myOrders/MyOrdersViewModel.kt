package com.nazlican.turkcellcapstoneproject.ui.myOrders

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nazlican.turkcellcapstoneproject.common.Resource
import com.nazlican.turkcellcapstoneproject.data.model.orders.Cart
import com.nazlican.turkcellcapstoneproject.data.repo.ProfileRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MyOrdersViewModel @Inject constructor(private val profileRepository: ProfileRepository) : ViewModel() {

    private var _myOrdersState = MutableLiveData<MyOrdersState>()
    val myOrdersState: LiveData<MyOrdersState> get() = _myOrdersState

    fun getMyOrders() = viewModelScope.launch{
        _myOrdersState.value = MyOrdersState.Loading

        _myOrdersState.value = when(val result = profileRepository.getUserOrders()){
            is Resource.Success  -> MyOrdersState.SuccessState(result.data)
            is Resource.Error  -> MyOrdersState.ShowPopUp(result.errorMessage)
            is Resource.Fail  -> MyOrdersState.EmptyScreen(result.failMessage)
        }

    }
}
sealed interface MyOrdersState{
    object Loading : MyOrdersState
    data class SuccessState(val cart: List<Cart>) : MyOrdersState
    data class EmptyScreen(val failMessage: String) : MyOrdersState
    data class ShowPopUp(val errorMessage: String) : MyOrdersState
}