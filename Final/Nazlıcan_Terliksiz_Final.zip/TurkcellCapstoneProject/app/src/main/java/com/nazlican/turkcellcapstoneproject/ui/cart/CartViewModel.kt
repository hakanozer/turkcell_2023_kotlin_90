package com.nazlican.turkcellcapstoneproject.ui.cart

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nazlican.turkcellcapstoneproject.common.Resource
import com.nazlican.turkcellcapstoneproject.data.model.product.ProductEntity
import com.nazlican.turkcellcapstoneproject.data.repo.CartRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CartViewModel @Inject constructor(private val cartRepository: CartRepository) : ViewModel() {

    private var _cartState = MutableLiveData<CartState>()
    val cartState: LiveData<CartState> get() = _cartState

    fun getCartProduct() = viewModelScope.launch {
        _cartState.value = CartState.Loading

        _cartState.value = when (val result = cartRepository.getCarts()) {
            is Resource.Success -> CartState.SuccessState(result.data)
            is Resource.Fail -> CartState.EmptyScreen(result.failMessage)
            is Resource.Error -> CartState.ShowPopUp(result.errorMessage)
        }
    }

    fun deleteToCart(productEntity: ProductEntity) = viewModelScope.launch {
        cartRepository.deleteFromCart(productEntity)
        getCartProduct()
    }

    fun clearAllCarts() {
        viewModelScope.launch {
            cartRepository.clearAllCarts()
            _cartState.value = CartState.Loading
            getCartProduct()
        }
    }

    fun totalPrice(productEntity: List<ProductEntity>): Int {
        var totalPrice = 0
        for (i in productEntity.indices) {
            val productPrice = productEntity[i].price
            if (productPrice != null) {
                totalPrice += productPrice
            }
        }
        return totalPrice
    }
}

sealed interface CartState {
    object Loading : CartState
    data class SuccessState(val productEntity: List<ProductEntity>) : CartState
    data class EmptyScreen(val failMessage: String) : CartState
    data class ShowPopUp(val errorMessage: String) : CartState
}