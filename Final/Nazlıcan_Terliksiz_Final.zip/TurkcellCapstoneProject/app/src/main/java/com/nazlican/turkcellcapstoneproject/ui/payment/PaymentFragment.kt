package com.nazlican.turkcellcapstoneproject.ui.payment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.nazlican.turkcellcapstoneproject.R
import com.nazlican.turkcellcapstoneproject.common.viewBinding
import com.nazlican.turkcellcapstoneproject.databinding.FragmentPaymentBinding
import com.nazlican.turkcellcapstoneproject.ui.cart.CartViewModel
import com.nazlican.turkcellcapstoneproject.util.extension.snackbar
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class PaymentFragment : Fragment(R.layout.fragment_payment) {

    private val binding by viewBinding(FragmentPaymentBinding::bind)
    private val paymentViewModel: PaymentViewModel by viewModels()
    private val cartViewModel: CartViewModel by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.paymentButton.setOnClickListener {
            with(binding) {
                paymentViewModel.checkFields(
                    paymentNameEt.text.toString(),
                    paymentCartNumberEt.text.toString(),
                    paymentMonthEt.text.toString(),
                    paymentYearEt.text.toString(),
                    paymentCvvEt.text.toString(),
                    paymentAddressEt.text.toString()
                )
            }
            cartViewModel.clearAllCarts()
        }

        binding.back.setOnClickListener {
            findNavController().popBackStack()
        }

        paymentObserve()
    }

    private fun paymentObserve() =
        paymentViewModel.paymentState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is PaymentState.PaymentSuccessState -> {
                    findNavController().navigate(R.id.action_paymentFragment_to_paymentSuccessFragment)
                }

                is PaymentState.ShowPopUp -> {
                    view?.snackbar(state.errorMessage)
                }
            }
        }
}
