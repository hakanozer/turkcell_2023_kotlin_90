package com.nazlican.turkcellcapstoneproject.ui.cart

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.nazlican.turkcellcapstoneproject.data.model.product.ProductEntity
import com.nazlican.turkcellcapstoneproject.databinding.ItemViewCartBinding
import com.nazlican.turkcellcapstoneproject.util.extension.downloadFromUrl

class CartAdapter(
    private val onDeleteClick: (ProductEntity) -> Unit,

) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {
    private val cartProductList = ArrayList<ProductEntity>()

    inner class CartViewHolder(private val binding: ItemViewCartBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(cartProducts: ProductEntity) {
            binding.apply {
                cartProducts.images?.let { cartProductIv.downloadFromUrl(it) }
                cartProductNameTv.text = cartProducts.title
                priceTv.text = "${cartProducts.price.toString()} ₺"

                cartDeleteIv.setOnClickListener {
                    onDeleteClick.invoke(cartProducts)
                }
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val binding =
            ItemViewCartBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CartViewHolder(binding)
    }

    override fun getItemCount(): Int = cartProductList.size

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val cartProduct = cartProductList[position]
        holder.bind(cartProduct)
    }

    fun updateList(updateList: List<ProductEntity>) {
        cartProductList.clear()
        cartProductList.addAll(updateList)
        notifyDataSetChanged()
    }
}