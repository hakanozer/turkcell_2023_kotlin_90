package com.nazlican.turkcellcapstoneproject.ui.profile

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nazlican.turkcellcapstoneproject.common.Resource
import com.nazlican.turkcellcapstoneproject.data.model.profile.Profile
import com.nazlican.turkcellcapstoneproject.data.repo.ProfileRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProfileViewModel @Inject constructor(private val profileRepository: ProfileRepository) :
    ViewModel() {

    private var _profileState = MutableLiveData<ProfileState>()
    val profileState: LiveData<ProfileState> get() = _profileState

    fun getUserInfo() = viewModelScope.launch{
        _profileState.value = ProfileState.Loading

        _profileState.value = when(val result = profileRepository.getUserInfo()){
            is Resource.Success -> ProfileState.SuccesState(result.data)
            is Resource.Fail -> ProfileState.EmptyScreen(result.failMessage)
            is Resource.Error -> ProfileState.ShowPopUp(result.errorMessage)
        }
    }

}

sealed interface ProfileState{
    object Loading : ProfileState
    data class SuccesState(val profile: Profile) : ProfileState
    data class EmptyScreen(val failMessage: String) : ProfileState
    data class ShowPopUp(val errorMessage: String) : ProfileState
}