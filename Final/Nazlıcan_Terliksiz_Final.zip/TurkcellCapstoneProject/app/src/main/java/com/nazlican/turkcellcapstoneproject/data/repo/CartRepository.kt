package com.nazlican.turkcellcapstoneproject.data.repo

import com.nazlican.turkcellcapstoneproject.common.Resource
import com.nazlican.turkcellcapstoneproject.data.model.product.ProductEntity
import com.nazlican.turkcellcapstoneproject.data.source.local.ProductDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.lang.Exception
import javax.inject.Inject

class CartRepository @Inject constructor(private val productDao: ProductDao) {

    suspend fun addToCart(productEntity: ProductEntity) {
        productDao.addProduct(productEntity)
    }

    suspend fun deleteFromCart(productEntity: ProductEntity) {
        productDao.deleteProduct(productEntity)
    }

    suspend fun getCarts(): Resource<List<ProductEntity>> =
        withContext(Dispatchers.IO) {
            try {
                val products = productDao.getProducts()

                if (products.isEmpty()) {
                    Resource.Fail("There are no products in your cart")
                } else {
                    Resource.Success(products)
                }
            } catch (e: Exception) {
                Resource.Error(e.message.orEmpty())
            }
        }
    suspend fun clearAllCarts() {
        productDao.clearAllCarts()
    }
}