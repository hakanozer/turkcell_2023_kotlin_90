package com.nazlican.turkcellcapstoneproject.data.repo

import com.nazlican.turkcellcapstoneproject.common.Resource
import com.nazlican.turkcellcapstoneproject.data.model.orders.Cart
import com.nazlican.turkcellcapstoneproject.data.model.profile.Profile
import com.nazlican.turkcellcapstoneproject.data.source.remote.ProductService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.lang.Exception

class ProfileRepository (private val productService: ProductService) {

    suspend fun getUserInfo(): Resource<Profile> =
        withContext(Dispatchers.IO) {
            try {
                val response = productService.getUserInfo()
                val userInfo = response.body()
                if (response.isSuccessful && userInfo != null){
                    Resource.Success(userInfo)
                }else {
                    Resource.Fail("An error occurred")
                }
            } catch (e: Exception) {
                Resource.Error(e.message.orEmpty())
            }
        }

    suspend fun getUserOrders(): Resource<List<Cart>> =
        withContext(Dispatchers.IO) {
            try {
                val response = productService.getUserOrders()
                val orderList = response.body()?.carts
                if (response.isSuccessful && orderList != null){
                    Resource.Success(orderList)
                }else {
                    Resource.Fail("An error occurred")
                }
            } catch (e: Exception) {
                Resource.Error(e.message.orEmpty())
            }
        }
    suspend fun updateUserInfo(): Resource<Profile> =
        withContext(Dispatchers.IO) {
            try {
                val response = productService.updateUserInfo()
                val updateuser = response.body()
                if (response.isSuccessful && updateuser != null){
                    Resource.Success(updateuser)
                }else {
                    Resource.Fail("An error occurred")
                }
            } catch (e: Exception) {
                Resource.Error(e.message.orEmpty())
            }
        }
}