package com.nazlican.turkcellcapstoneproject.data.repo

import com.nazlican.turkcellcapstoneproject.common.Resource
import com.nazlican.turkcellcapstoneproject.data.model.product.Products
import com.nazlican.turkcellcapstoneproject.data.source.remote.ProductService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.lang.Exception

class HomeRepository(private val productService: ProductService) {

    suspend fun getAllProducts(): Resource<List<Products>> =
        withContext(Dispatchers.IO) {
            try {
                val response = productService.getProducts()
                if (response.isSuccessful) {
                    val productList = response.body()?.products.orEmpty()
                    Resource.Success(productList)
                }else{
                    Resource.Fail("An error occurred")
                }
            }catch (e:Exception){
                Resource.Error(e.message.orEmpty())
            }
        }

    suspend fun searchProducts(search: String): Resource<List<Products>> =
        withContext(Dispatchers.IO) {
            try {
                val response = productService.searchProduct(search)
                if (response.isSuccessful) {
                    val productList = response.body()?.products.orEmpty()
                    Resource.Success(productList)
                }else{
                    Resource.Fail("An error occurred")
                }
            }catch (e:Exception){
                Resource.Error(e.message.orEmpty())
            }
        }
    suspend fun getCategoryName(): Resource<List<String>> {
        return try {
            val response = productService.getCategoryName()
            val category = response.body()
            if (response.isSuccessful && category != null) {
                Resource.Success(category)
            } else {
                Resource.Fail("An error occurred")
            }
        } catch (e: Exception) {
            Resource.Error(e.message.orEmpty())
        }
    }

    suspend fun getProductsByCategory(category: String): Resource<List<Products>> {
        return try {
            val response = productService.getProductsByCategory(category)
            if (response.isSuccessful) {
                val categoryList = response.body()?.products.orEmpty()
                Resource.Success(categoryList)
            } else {
                Resource.Fail("An error occurred")
            }
        } catch (e: Exception) {
            Resource.Error(e.message.orEmpty())
        }
    }
}