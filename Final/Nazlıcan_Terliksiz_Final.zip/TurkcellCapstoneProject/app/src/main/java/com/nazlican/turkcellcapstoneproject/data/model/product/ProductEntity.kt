package com.nazlican.turkcellcapstoneproject.data.model.product

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName ="cart_products")
data class ProductEntity(

    @PrimaryKey(autoGenerate = false)
    @ColumnInfo(name = "productId")
    val productId: Int?,

    @ColumnInfo(name = "images")
    val images: String?,

    @ColumnInfo(name = "price")
    val price: Int?,

    @ColumnInfo(name = "rating")
    val rating: Double?,

    @ColumnInfo(name = "title")
    val title: String?,

    @ColumnInfo(name = "isFav")
    val isFav: Boolean,
)
