package com.nazlican.turkcellcapstoneproject.data.source.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.nazlican.turkcellcapstoneproject.data.model.product.ProductEntity

@Database(entities = [ProductEntity::class], version =1)
abstract class ProductRoomDB : RoomDatabase() {
    abstract fun productDao(): ProductDao
}