package com.nazlican.turkcellcapstoneproject.data.model.product

class Categories : ArrayList<String>()