package com.nazlican.turkcellcapstoneproject.data.model.login

data class Token(
    val token : String
)
