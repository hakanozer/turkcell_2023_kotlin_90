package com.nazlican.turkcellcapstoneproject.data.model.login

data class User(
    val username: String?,
    val password: String?
)
