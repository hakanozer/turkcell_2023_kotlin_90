package com.nazlican.turkcellcapstoneproject.ui.profile

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nazlican.turkcellcapstoneproject.common.Resource
import com.nazlican.turkcellcapstoneproject.data.model.profile.Profile
import com.nazlican.turkcellcapstoneproject.data.repo.ProfileRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UpdateProfileViewModel  @Inject constructor(private val profileRepository: ProfileRepository) :
    ViewModel() {

    private var _udtadeProfileState = MutableLiveData<UpdateProfileState>()
    val udtadeProfileState: LiveData<UpdateProfileState> get() = _udtadeProfileState

    fun getUpdateProfile() = viewModelScope.launch{
        _udtadeProfileState.value = UpdateProfileState.Loading

        _udtadeProfileState.value = when(val result = profileRepository.updateUserInfo()){
            is Resource.Success -> UpdateProfileState.SuccesState(result.data)
            is Resource.Fail -> UpdateProfileState.EmptyScreen(result.failMessage)
            is Resource.Error -> UpdateProfileState.ShowPopUp(result.errorMessage)
        }
    }

}

sealed interface UpdateProfileState{
    object Loading : UpdateProfileState
    data class SuccesState(val profile: Profile) : UpdateProfileState
    data class EmptyScreen(val failMessage: String) : UpdateProfileState
    data class ShowPopUp(val errorMessage: String) : UpdateProfileState
}