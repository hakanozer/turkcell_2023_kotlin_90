package com.nazlican.turkcellcapstoneproject.ui.cart

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.nazlican.turkcellcapstoneproject.R
import com.nazlican.turkcellcapstoneproject.common.viewBinding
import com.nazlican.turkcellcapstoneproject.data.model.product.ProductEntity
import com.nazlican.turkcellcapstoneproject.databinding.FragmentCartBinding
import com.nazlican.turkcellcapstoneproject.util.extension.gone
import com.nazlican.turkcellcapstoneproject.util.extension.snackbar
import com.nazlican.turkcellcapstoneproject.util.extension.visible
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CartFragment : Fragment(R.layout.fragment_cart) {

    private val binding by viewBinding(FragmentCartBinding::bind)
    private val cartViewModel: CartViewModel by viewModels()
    private lateinit var cartAdapter: CartAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        cartAdapter = CartAdapter( ::deleteToCart)
        binding.cartProductRv.adapter = cartAdapter

        cartViewModel.getCartProduct()
        cartProductObserve()

        binding.confirmCartButton.setOnClickListener{
            findNavController().navigate(R.id.action_cartFragment_to_paymentFragment)
        }

    }
    private fun cartProductObserve() = with(binding) {
        cartViewModel.cartState.observe(viewLifecycleOwner) { state ->
            when (state) {
                CartState.Loading -> {
                    cartProgressBar.visible()
                }

                is CartState.SuccessState -> {
                    cartProgressBar.gone()
                    cartAdapter.updateList(state.productEntity)
                    Log.d("message", state.productEntity.toString())
                    val totalPrice = cartViewModel.totalPrice(state.productEntity)
                    binding.cartRroductsTotalPriceTv.text = "Total price : $totalPrice ₺"
                }

                is CartState.EmptyScreen -> {
                    cartProgressBar.gone()
                    cartEmptyIv.visible()
                    cartEmptyTv.visible()
                    cartProductRv.gone()
                    cartEmptyTv.text = state.failMessage
                }

                is CartState.ShowPopUp -> {
                    cartProgressBar.gone()
                    view?.snackbar(state.errorMessage)
                }
            }
        }
    }
    private fun deleteToCart(productEntity: ProductEntity){
        cartViewModel.deleteToCart(productEntity)
        view?.snackbar("Product deleted!")
    }
}