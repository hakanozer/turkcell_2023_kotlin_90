package com.nazlican.turkcellcapstoneproject.ui.myOrders

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.nazlican.turkcellcapstoneproject.R
import com.nazlican.turkcellcapstoneproject.common.viewBinding
import com.nazlican.turkcellcapstoneproject.databinding.FragmentMyOrdersBinding
import com.nazlican.turkcellcapstoneproject.util.extension.gone
import com.nazlican.turkcellcapstoneproject.util.extension.snackbar
import com.nazlican.turkcellcapstoneproject.util.extension.visible
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MyOrdersFragment : Fragment(R.layout.fragment_my_orders) {

    private val binding by viewBinding(FragmentMyOrdersBinding::bind)
    private val viewModel: MyOrdersViewModel by viewModels()
    private lateinit var myOrdersAdapter: MyOrdersAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        with(binding){
            myOrdersAdapter = MyOrdersAdapter()
            ordersRv.adapter= myOrdersAdapter

            back.setOnClickListener{
                findNavController().popBackStack()
            }
        }
        viewModel.getMyOrders()
        getUserOrders()
    }

    fun getUserOrders() = with(binding){
        viewModel.myOrdersState.observe(viewLifecycleOwner){state ->

            when(state){
                is MyOrdersState.Loading -> ordersProgressBar.visible()

                is MyOrdersState.SuccessState -> {
                    ordersProgressBar.gone()
                    myOrdersAdapter.updateList(state.cart.get(0).products)
                    Log.d("messageMyOrders", state.cart.toString())
                }
                is MyOrdersState.EmptyScreen -> {
                    ordersProgressBar.gone()
                    ordersEmptyIv.visible()
                    ordersEmptyTv.visible()
                    ordersEmptyTv.text = state.failMessage
                }
                is MyOrdersState.ShowPopUp -> {
                    ordersProgressBar.gone()
                    view?.snackbar(state.errorMessage)
                }
            }
        }
    }
}