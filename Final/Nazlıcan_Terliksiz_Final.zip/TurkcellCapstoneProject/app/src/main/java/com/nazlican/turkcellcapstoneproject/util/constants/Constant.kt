package com.nazlican.turkcellcapstoneproject.util.constants

object Constant {
    const val BASE_URL = "https://dummyjson.com/"
}