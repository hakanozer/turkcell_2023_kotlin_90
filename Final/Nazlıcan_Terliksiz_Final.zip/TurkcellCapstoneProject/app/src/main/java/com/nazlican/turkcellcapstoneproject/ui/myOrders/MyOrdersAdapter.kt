package com.nazlican.turkcellcapstoneproject.ui.myOrders

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.nazlican.turkcellcapstoneproject.data.model.orders.Product
import com.nazlican.turkcellcapstoneproject.databinding.ItemViewOrderBinding
import com.nazlican.turkcellcapstoneproject.util.extension.downloadFromUrl

class MyOrdersAdapter() : RecyclerView.Adapter<MyOrdersAdapter.MyOrdersViewHolder>() {
    private val orderList = ArrayList<Product>()

    inner class MyOrdersViewHolder(private val binding: ItemViewOrderBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(product: Product) {
            binding.apply {

                orderProductIv.downloadFromUrl(product.thumbnail)
                orderProductNameTv.text = product.title
                priceTv.text = "${product.price.toString()} ₺"

                /*root.setOnClickListener{
                    onDetailClickListener.invoke(productUI.id)
                }*/
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyOrdersViewHolder {
       val binding = ItemViewOrderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyOrdersViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return orderList.size
    }

    override fun onBindViewHolder(holder: MyOrdersViewHolder, position: Int) {
        val orderProduct = orderList[position]
        holder.bind(orderProduct)
    }
    fun updateList(updateList:List<Product>){
        orderList.clear()
        orderList.addAll(updateList)
        notifyDataSetChanged()
    }
}
