package com.nazlican.turkcellcapstoneproject.data.source.remote

import com.nazlican.turkcellcapstoneproject.data.model.product.Categories
import com.nazlican.turkcellcapstoneproject.data.model.product.ProductResponse
import com.nazlican.turkcellcapstoneproject.data.model.product.Products
import com.nazlican.turkcellcapstoneproject.data.model.profile.Profile
import com.nazlican.turkcellcapstoneproject.data.model.login.UserInfo
import com.nazlican.turkcellcapstoneproject.data.model.login.User
import com.nazlican.turkcellcapstoneproject.data.model.orders.OrderResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

interface ProductService {

    @GET("products")
    suspend fun getProducts(): Response<ProductResponse>

    @GET("products/{id}")
    suspend fun getProductDetail(@Path("id") id: Int): Response<Products>

    @GET("products/search?")
    suspend fun searchProduct(@Query("q") query: String): Response<ProductResponse>

    @GET("products/category/{category}")
    suspend fun getProductsByCategory(
        @Path("category") category: String
    ): Response<ProductResponse>

    @GET("products/categories")
    suspend fun getCategoryName(): Response<Categories>

    @POST("auth/login")
    suspend fun login(@Body user: User): Response<UserInfo>

    @GET("users/15")
    suspend fun getUserInfo(): Response<Profile>

    @PUT("users/15")
    suspend fun updateUserInfo(): Response<Profile>

    @GET("users/15/carts")
    suspend fun getUserOrders(): Response<OrderResponse>

}