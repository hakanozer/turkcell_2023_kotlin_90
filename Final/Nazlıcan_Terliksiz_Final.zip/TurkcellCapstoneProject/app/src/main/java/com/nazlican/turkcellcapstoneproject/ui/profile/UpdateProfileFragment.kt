package com.nazlican.turkcellcapstoneproject.ui.profile

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.nazlican.turkcellcapstoneproject.R
import com.nazlican.turkcellcapstoneproject.common.viewBinding
import com.nazlican.turkcellcapstoneproject.databinding.FragmentUpdateProfileBinding
import com.nazlican.turkcellcapstoneproject.util.extension.snackbar
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class UpdateProfileFragment : Fragment(R.layout.fragment_update_profile) {

    private val binding by viewBinding(FragmentUpdateProfileBinding::bind)
    private val viewModel: UpdateProfileViewModel by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.updateButton.setOnClickListener{
            viewModel.getUpdateProfile()
        }
        getUpdateProfilObserve()

        binding.back.setOnClickListener {
            findNavController().popBackStack()
        }

    }

    fun getUpdateProfilObserve() = with(binding) {
        viewModel.udtadeProfileState.observe(viewLifecycleOwner) { state ->
            when (state) {
                UpdateProfileState.Loading -> Unit

                is UpdateProfileState.SuccesState -> {
                    findNavController().popBackStack()
                }

                is UpdateProfileState.EmptyScreen -> {
                    view?.snackbar(state.failMessage)
                }

                is UpdateProfileState.ShowPopUp -> {
                    view?.snackbar(state.errorMessage)
                }
            }

        }
    }

}