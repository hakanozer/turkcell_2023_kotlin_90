package com.nazlican.turkcellcapstoneproject.data.model.orders

data class OrderResponse(
    val carts: List<Cart>,
    val limit: Int,
    val skip: Int,
    val total: Int
)