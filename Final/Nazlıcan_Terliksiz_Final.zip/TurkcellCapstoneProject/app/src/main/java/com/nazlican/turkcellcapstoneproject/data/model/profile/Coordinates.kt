package com.nazlican.turkcellcapstoneproject.data.model.profile

data class Coordinates(
    val lat: Double,
    val lng: Double
)