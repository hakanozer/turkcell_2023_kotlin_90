package com.example.esmasalkim_finalprojesi.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.esmasalkim_finalprojesi.R
import com.example.esmasalkim_finalprojesi.confige.ApiClient
import com.example.esmasalkim_finalprojesi.databinding.FragmentProDetailBinding
import com.example.esmasalkim_finalprojesi.models.OrderRequest
import com.example.esmasalkim_finalprojesi.models.Product
import com.example.esmasalkim_finalprojesi.models.ProductOrder
import com.example.esmasalkim_finalprojesi.services.DummyService
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProDetailFragment : Fragment() {

    private lateinit var binding: FragmentProDetailBinding
    private lateinit var apiService: DummyService
    private var selectedProduct: Product? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentProDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        apiService = ApiClient.getClient().create(DummyService::class.java)
        selectedProduct = arguments?.getSerializable("product") as? Product

        if (selectedProduct != null) {
            productDetails(selectedProduct!!)
        }

        binding.btnProductOrder.setOnClickListener {
            if (selectedProduct != null) {
                createOrder(selectedProduct!!)
            }
        }
    }
    private fun productDetails(product: Product) {
        Picasso.get()
            .load(product.images.firstOrNull())
            .into(binding.imgDetails)

        binding.txtDetailsTitle.text = product.title
        binding.txtDescription.text = product.description
        binding.txtBrandDetail.text = "Brand: ${product.brand}"
        binding.txtStockDetail.text = "Stock: ${product.stock}"
        binding.txtRaiting.text = "Raiting: ${product.rating}/5"
        binding.txtCategoryDetail.text = "Category: ${product.category}"
        binding.txtPriceDetail.text = "Price: ${product.price}$"
    }

    private fun createOrder(product: Product) {
        val orderRequest = OrderRequest(
            userId = 1,
            products = listOf(
                ProductOrder(title = product.title, price = product.price.toDouble())
            )
        )
        val call = apiService.createOrder(orderRequest)
        call.enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    Log.d("siparis basarili", response.toString())
                    Toast.makeText(requireContext(), "Ürün Başarıyla Sipariş Verildi!", Toast.LENGTH_SHORT).show()
                } else {
                    Log.d("siparis basarisiz", response.toString())
                    Toast.makeText(requireContext(), "Hata oluştu!", Toast.LENGTH_SHORT).show()

                }
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                Log.d("hata:", t.message.toString())
            }
        })
    }
}

