package com.example.esmasalkim_finalprojesi

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage


class MyFirebaseInstanceIDService : FirebaseMessagingService () {

    override fun onNewToken(token: String) {
        Log.d("Token", "onNewToken: $token")
    }

    override fun onMessageReceived(message: RemoteMessage) {
        Log.d("Message", " (${message.messageId})")
        Log.d("Message", " (${message.from})")

        if (message.data.isEmpty()){
            Log.d("XMessage", " (${message.data})")
        }
        message.notification?.let {
            Log.d("XMessage", " (${it.body})")

        }

    }
}