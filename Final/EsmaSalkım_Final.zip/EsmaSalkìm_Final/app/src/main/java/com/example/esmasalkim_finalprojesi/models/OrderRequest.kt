package com.example.esmasalkim_finalprojesi.models

data class OrderRequest(
    val userId: Int,
    val products: List<ProductOrder>
)

data class ProductOrder(
    val title: String,
    val price: Double
)
