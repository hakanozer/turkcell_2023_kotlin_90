package com.example.esmasalkim_finalprojesi.confige

import com.example.esmasalkim_finalprojesi.services.DummyService
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiClient {



    private val Base_URL = "https://dummyjson.com/"
    private var retrofit: Retrofit? = null

    private val client = OkHttpClient
        .Builder()
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun getClient():Retrofit {
        if (retrofit == null) {
            retrofit = Retrofit
                .Builder()
                .baseUrl(Base_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build()
        }
        return retrofit as Retrofit

    }
        val dummyService: DummyService by lazy {
            val retrofit = Retrofit.Builder()
                .baseUrl(Base_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            retrofit.create(DummyService::class.java)
        }
}
