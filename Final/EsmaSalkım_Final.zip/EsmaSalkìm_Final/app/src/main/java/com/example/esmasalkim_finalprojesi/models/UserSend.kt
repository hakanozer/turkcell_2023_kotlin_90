package com.example.esmasalkim_finalprojesi.models

data class UserSend(
    // username ve password bu şekilde yazılmalı yoksa çalışmaz. sunucuda bu şekilde yazılı. yoksa veriyi göndermez
    val username: String,
    val password : String
)
