import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.esmasalkim_finalprojesi.databinding.ItemBasketBinding
import com.example.esmasalkim_finalprojesi.models.Product2
import com.squareup.picasso.Picasso

class MyOrdersAdapter(private var productList: List<Product2>) : RecyclerView.Adapter<MyOrdersAdapter.ProductViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemBasketBinding.inflate(inflater, parent, false)
        return ProductViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = productList[position]
        holder.bind(product)
    }

    override fun getItemCount(): Int {
        return productList.size
    }

    fun setData(newList: List<Product2>) {
        productList = newList
        notifyDataSetChanged()
    }

    inner class ProductViewHolder(private val binding: ItemBasketBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(product: Product2) {

            if (product.thumbnail.isNotEmpty()) {
                val imageUrl = product.thumbnail.toString()
                val imageUri = Uri.parse(imageUrl)
                Picasso.get().load(imageUri).into(binding.imgViewBasketThumbnail)
            }

            binding.txtBasketTittle.text = product.title
            binding.txtBasketPrice.text = "Fiyat: ${product.price}$"
            binding.txtBasketQuantity.text = "Miktar : ${product.quantity}"
            binding.txtBasketTotal.text = "Toplam : ${product.total}$"
            binding.txtBasketDiscountPercentage.text = "İndirim: %${product.discountPercentage}"
            binding.txtBasketDiscountedPrice.text = "İndirimli Fiyat: ${product.discountedPrice}$"
        }
    }

}