package com.example.esmasalkim_finalprojesi

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.esmasalkim_finalprojesi.confige.ApiClient
import com.example.esmasalkim_finalprojesi.databinding.ActivityMainBinding
import com.example.esmasalkim_finalprojesi.models.JWTUser
import com.example.esmasalkim_finalprojesi.models.UserSend
import com.example.esmasalkim_finalprojesi.services.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    lateinit var dummyService: DummyService


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dummyService = ApiClient.getClient().create(DummyService::class.java)

        binding.btnLogin.setOnClickListener {

            val username = binding.txtUserName.text.toString().trim()
            val password = binding.txtPassword.text.toString().trim()
            val userSend = UserSend (username, password)

            if (userSend.username == "kminchelle" && userSend.password == "0lelplR"){
                dummyService.login(userSend).enqueue(object : Callback<JWTUser> {
                    override fun onResponse(call: Call<JWTUser>, response: Response<JWTUser>) {
                        val status = response.code()
                        Log.d("Status", status.toString())

                        if (status == 200){
                            val user = response.body()
                            if (user != null){
                                Log.d("User", user.toString())


                                val intent = Intent (this@MainActivity, Home::class.java)
                                Log.d("sayfagecis", intent.toString())
                                startActivity(intent)
                                Log.d("sayfagec", intent.toString())

                            }
                        }else{
                            Toast.makeText(this@MainActivity, "Username or Passsword Fail", Toast.LENGTH_SHORT).show()
                        }
                    }
                    override fun onFailure(call: Call<JWTUser>, t: Throwable) {
                        Log.e("Login Fail", t.toString())
                    }
                })
            }else{
                Toast.makeText(this@MainActivity, "Username or Passsword Fail", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
