package com.example.esmasalkim_finalprojesi.services

import com.example.esmasalkim_finalprojesi.models.JWTUser
import com.example.esmasalkim_finalprojesi.models.MyOrders
import com.example.esmasalkim_finalprojesi.models.OrderRequest
import com.example.esmasalkim_finalprojesi.models.Products
import com.example.esmasalkim_finalprojesi.models.UserInformation
import com.example.esmasalkim_finalprojesi.models.UserSend
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Query

interface DummyService {

    @POST("auth/login")
    fun login (@Body userSend: UserSend) : Call<JWTUser>

    @GET("products")
    fun allProducts(@Query("limit")limit:Int): Call<Products>

    @GET("products/search")
    fun searchProducts(@Query("q") keyword:String): Call<Products>

    @GET("products/categories")
    fun getCategories(): Call<ArrayList<String>>

    @GET("products")
    fun getSubCategories(@Query("category") category:String): Call<Products>

    @GET("users/1")
    fun getUser(): Call<UserInformation>

    @PUT("users/1")
    fun updateUser(@Body updatedUser: UserInformation): Call<UserInformation>

    @POST("carts/add")
    fun createOrder(@Body orderRequest: OrderRequest): Call<Void>

    @GET("users/5/carts")
    fun getMyOrders(): Call<MyOrders>
}


