package com.example.esmasalkim_finalprojesi.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.esmasalkim_finalprojesi.databinding.ItemSubcategoryBinding
import com.example.esmasalkim_finalprojesi.models.Product
import com.squareup.picasso.Picasso

class SubCategoryAdapter : RecyclerView.Adapter<SubCategoryAdapter.SubCategoryViewHolder>() {

    private var subCategories = listOf<Product>()

    fun setSubCategories(subCategories: List<Product>) {
        this.subCategories = subCategories
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SubCategoryViewHolder {
        val binding = ItemSubcategoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SubCategoryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SubCategoryViewHolder, position: Int) {
        val subCategory = subCategories[position]
        holder.bind(subCategory)
    }

    override fun getItemCount(): Int = subCategories.size

    inner class SubCategoryViewHolder(private val binding: ItemSubcategoryBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(subCategory: Product) {
            if (subCategory.images.isNotEmpty()) {
                Picasso.get().load(subCategory.images[0]).into(binding.imgViewSubCategory)
            }

            binding.txtSubTittle.text = subCategory.title
            binding.txtSubPrice.text = "Price: $${subCategory.price}"
            binding.txtSubRating.text = "Rating: ${subCategory.rating}/5"
            binding.txtSubStock.text = "Stock: ${subCategory.stock}"
        }
    }
}