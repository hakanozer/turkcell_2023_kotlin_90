package com.example.esmasalkim_finalprojesi.models

import java.io.Serializable

data class UserInformation (
    val firstName: String,
    val lastName: String,
    val email: String,
    val phone: String,
    val password: String,
    val image: String
) : Serializable {


    override fun toString(): String {
        return password.toString()
    }

}

