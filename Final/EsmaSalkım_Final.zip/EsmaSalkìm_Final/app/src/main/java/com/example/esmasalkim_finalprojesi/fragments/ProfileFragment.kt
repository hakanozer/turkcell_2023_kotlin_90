package com.example.esmasalkim_finalprojesi.fragments

import android.os.Bundle
import android.text.Editable
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import com.example.esmasalkim_finalprojesi.databinding.FragmentProfileBinding
import com.example.esmasalkim_finalprojesi.models.UserInformation
import com.example.esmasalkim_finalprojesi.services.DummyService
import com.google.android.material.snackbar.Snackbar
import com.squareup.picasso.Picasso
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.await
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.Response

class ProfileFragment : Fragment() {

    private lateinit var apiService: DummyService
    lateinit var binding: FragmentProfileBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        apiService = Retrofit.Builder()
            .baseUrl("https://dummyjson.com")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(DummyService::class.java)

        GlobalScope.launch(Dispatchers.Main) {
            try {
                val response = apiService.getUser().await()
                val user = response
                user?.let { showUserData(it) }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        val imgViewUpdate: ImageView = (binding.imgViewUpdate)

        imgViewUpdate.setOnClickListener {
            updateUser()
        }

    }

    private fun showUserData(user: UserInformation) {

        Picasso.get()
            .load(user.image)
            .into(binding.imgProfile)

        binding.txtFirstName.text = Editable.Factory.getInstance().newEditable(user?.firstName ?: "")
        binding.txtLastName.text = Editable.Factory.getInstance().newEditable(user?.lastName ?: "")
        binding.txtEmail.text = Editable.Factory.getInstance().newEditable(user?.email ?: "")
        binding.txtPhone.text = Editable.Factory.getInstance().newEditable(user?.phone ?: "")
        binding.txtPassword.text = Editable.Factory.getInstance().newEditable(user?.password ?: "")
    }

    private fun updateUser() {

        val updatedUser = UserInformation(
            binding.txtFirstName.text.toString(),
            binding.txtLastName.text.toString(),
            binding.txtEmail.text.toString(),
            binding.txtPhone.text.toString(),
            binding.txtPassword.text.toString(),
            binding.imgProfile.toString()
        )

        GlobalScope.launch(Dispatchers.Main) {

            try {
                val response: Response<UserInformation> = withContext(Dispatchers.IO) {
                    apiService.updateUser(updatedUser).execute()
                }
                if (response.isSuccessful()) {
                    println("Update successful: ${response.body()}")
                    Log.d("basarili", response.toString())
                    Toast.makeText(requireContext(), "Bilgileriniz Başarıyla Güncellendi!", Toast.LENGTH_SHORT).show()


                } else {
                    val errorBody = response.errorBody()?.string()
                    println("Update failed: ${response.code()} - ${response.message()}, Error Body: $errorBody")
                    Log.d("basarisiz", errorBody.toString())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    companion object {
    }
}