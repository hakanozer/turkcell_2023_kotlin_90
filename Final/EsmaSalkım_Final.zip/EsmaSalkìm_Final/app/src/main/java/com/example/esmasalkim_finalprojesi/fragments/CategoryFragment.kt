import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.esmasalkim_finalprojesi.adapters.CategoryAdapter
import com.example.esmasalkim_finalprojesi.confige.ApiClient
import com.example.esmasalkim_finalprojesi.databinding.FragmentCategoryBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CategoryFragment : Fragment() {

    private lateinit var categoryAdapter: CategoryAdapter
    private lateinit var binding: FragmentCategoryBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        binding = FragmentCategoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.receyclerViewCategory.layoutManager = GridLayoutManager(requireContext(), 2)
        categoryAdapter = CategoryAdapter(ArrayList())
        binding.receyclerViewCategory.adapter = categoryAdapter

        fetchData()
    }

    private fun fetchData() {
        val call = ApiClient.dummyService.getCategories()
        call.enqueue(object : Callback<ArrayList<String>> {

            override fun onResponse(
                call: Call<ArrayList<String>>, response: Response<ArrayList<String>>
            ) {
                if (response.isSuccessful) {
                    categoryAdapter.categories.addAll(response.body() ?: emptyList())
                    categoryAdapter.notifyDataSetChanged()
                }
            }

            override fun onFailure(call: Call<ArrayList<String>>, t: Throwable) {

            }
        })
    }
}