package com.example.esmasalkim_finalprojesi.adapters

import SubCategoryFragment
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.esmasalkim_finalprojesi.R
import java.io.Serializable

class CategoryAdapter(val categories: ArrayList<String>) :
    RecyclerView.Adapter<CategoryAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.categoryitem, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val category = categories[position]
        holder.bind(category)

        holder.itemView.setOnClickListener {

            val subCategoryFragment = SubCategoryFragment()
            val bundle = Bundle()
            bundle.putString("categoryName", category)
            subCategoryFragment.arguments = bundle

            val fragmentManager = (holder.itemView.context as AppCompatActivity).supportFragmentManager
            fragmentManager.beginTransaction()
                .replace(R.id.frame, subCategoryFragment)
                .addToBackStack(null)
                .commit()
        }
    }
    override fun getItemCount(): Int {
        return categories.size
    }
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val categoryName: TextView = itemView.findViewById(R.id.txtCategory)

        fun bind(category: String) {
            categoryName.text = category
        }
    }
}