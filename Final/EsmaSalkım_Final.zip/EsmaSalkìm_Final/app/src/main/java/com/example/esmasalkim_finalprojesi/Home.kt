package com.example.esmasalkim_finalprojesi

import CategoryFragment
import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
/*
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.esmasalkim_finalprojesi.adapters.ProductAdapter
import com.example.esmasalkim_finalprojesi.confige.ApiClient
import com.example.esmasalkim_finalprojesi.models.Product
import com.example.esmasalkim_finalprojesi.services.DummyService
import org.json.JSONArray
import org.json.JSONObject

 */
import com.example.esmasalkim_finalprojesi.databinding.ActivityHomeBinding
import com.example.esmasalkim_finalprojesi.fragments.BasketFragment
import com.example.esmasalkim_finalprojesi.fragments.ProSearchFragment
import com.example.esmasalkim_finalprojesi.fragments.ProfileFragment


class Home : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        fragmentCagir(ProSearchFragment())

        binding.btnHome.setOnClickListener {
            fragmentCagir(ProSearchFragment())
        }

        binding.btnCategory.setOnClickListener {
            fragmentCagir(CategoryFragment())
        }
        binding.btnbasket.setOnClickListener {
            fragmentCagir(BasketFragment())
        }
        binding.btnProfile.setOnClickListener {
            fragmentCagir(ProfileFragment())
        }
    }
    fun fragmentCagir(fragment: Fragment){
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.frame, fragment)
        fragmentTransaction.commit()
    }
}

