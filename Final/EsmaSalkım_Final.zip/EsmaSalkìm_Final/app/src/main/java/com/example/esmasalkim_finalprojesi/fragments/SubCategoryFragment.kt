import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.esmasalkim_finalprojesi.adapters.SubCategoryAdapter
import com.example.esmasalkim_finalprojesi.confige.ApiClient
import com.example.esmasalkim_finalprojesi.databinding.FragmentSubCategoryBinding
import com.example.esmasalkim_finalprojesi.models.Products
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.collections.filter

class SubCategoryFragment : Fragment() {

    private lateinit var subCategoryAdapter: SubCategoryAdapter
    private lateinit var binding: FragmentSubCategoryBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        binding = FragmentSubCategoryBinding.inflate(inflater, container, false)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        subCategoryAdapter = SubCategoryAdapter()

        binding.recyclerViewSubCategory.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewSubCategory.adapter = subCategoryAdapter

        val categoryName = arguments?.getString("categoryName")

        categoryName?.let {
            fetchProductsByCategory(it)
        }
    }
    private fun fetchProductsByCategory(categoryName: String) {
        val call = ApiClient.dummyService.getSubCategories(categoryName)

        call.enqueue(object : Callback<Products> {
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                if (response.isSuccessful) {
                    val products = response.body()?.products

                    products?.let {
                        val subCategory = it.filter { product ->
                            product.category == categoryName
                        }
                        subCategoryAdapter.setSubCategories(subCategory)

                        if (subCategory == null || subCategory.size == 0) {
                            Toast.makeText(
                                requireContext(),
                                "Seçtiğiniz Kategori için ürün bulunamadı.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                } else {
                    response.errorBody()
                }
            }
            override fun onFailure(call: Call<Products>, t: Throwable) {
                t.printStackTrace()
            }
        })
    }
}