package com.example.esmasalkim_finalprojesi.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.esmasalkim_finalprojesi.adapters.ProductAdapter
import com.example.esmasalkim_finalprojesi.confige.ApiClient
import com.example.esmasalkim_finalprojesi.databinding.FragmentProSearchBinding
import com.example.esmasalkim_finalprojesi.models.Product
import com.example.esmasalkim_finalprojesi.services.DummyService
import org.json.JSONArray
import org.json.JSONObject


class ProSearchFragment : Fragment() {

    private lateinit var binding: FragmentProSearchBinding
    private lateinit var dummyService: DummyService
    private lateinit var productAdapter: ProductAdapter
    private lateinit var allProducts: List<Product>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = FragmentProSearchBinding.inflate(layoutInflater)
        dummyService = ApiClient.getClient().create(DummyService::class.java)

        setupRecyclerView()

        val queue: RequestQueue = Volley.newRequestQueue(requireContext())
        val url = "https://dummyjson.com/products"

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, url, null,
            Response.Listener { response ->
                allProducts = parseProducts(response)
                productAdapter.updateData(allProducts)
            },
            Response.ErrorListener { error ->
                error.printStackTrace()
                Log.d("error", error.toString())
            }
        )

        queue.add(jsonObjectRequest)

        // SearchView için dinleyici eklendiSearchView.OnQueryTextListener
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                // Arama sırasında filtreleme işlemi
                val filteredProducts = filterProducts(newText.orEmpty())
                productAdapter.updateData(filteredProducts)
                return true
            }
        })

        arguments?.let {
        }
    }

    private fun filterProducts(query: String): List<Product> {
        return allProducts.filter { it.title.contains(query, ignoreCase = true) }
    }

    private fun parseProducts(json: JSONObject): List<Product> {
        val productsList = mutableListOf<Product>()
        val productsArray: JSONArray = json.getJSONArray("products")

        for (i in 0 until productsArray.length()) {
            val productObject = productsArray.getJSONObject(i)
            val id = productObject.getLong("id")
            val title = productObject.getString("title")
            val description = productObject.getString("description")
            val price = productObject.getLong("price")
            val discountPercentage = productObject.getDouble("discountPercentage")
            val rating = productObject.getDouble("rating")
            val stock = productObject.getLong("stock")
            val brand = productObject.getString("brand")
            val category = productObject.getString("category")
            val thumbnail = productObject.getString("thumbnail")
            val imagesArray = productObject.getJSONArray("images")
            val images = mutableListOf<String>()

            for (j in 0 until imagesArray.length()) {
                images.add(imagesArray.getString(j))
            }

            val product = Product(id, title, description, price, discountPercentage, rating, stock, brand, category, thumbnail, images)
            productsList.add(product)
        }

        return productsList
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return binding.root
    }

    private fun setupRecyclerView() {
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        productAdapter = ProductAdapter(emptyList())
        binding.recyclerView.adapter = productAdapter
    }

    companion object {
    }

}
