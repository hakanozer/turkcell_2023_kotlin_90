package com.works.oguzbaransahingil_final.adapter

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.works.oguzbaransahingil_final.R
import com.works.oguzbaransahingil_final.UrunListDetay
import com.works.oguzbaransahingil_final.models.Product
import java.io.Serializable

class ListAdapter(private var productList : List<Product>) :
    RecyclerView.Adapter<ListAdapter.ProductViewHolder>(){


    class ProductViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView){
        val txt_id : TextView = itemView.findViewById(R.id.txt_id)
        //val txt_description : TextView = itemView.findViewById(R.id.txt_description)
        //val txt_price : TextView = itemView.findViewById(R.id.txt_price)
        //val txt_discountpercentage : TextView = itemView.findViewById(R.id.txt_discountpercentage)
        //val txt_rating : TextView = itemView.findViewById(R.id.txt_rating)
        //val txt_stock : TextView = itemView.findViewById(R.id.txt_stock)
        val txt_title : TextView = itemView.findViewById(R.id.txt_title)
        //val txt_brand : TextView = itemView.findViewById(R.id.txt_brand)
        val txt_category : TextView = itemView.findViewById(R.id.txt_category)
        //val txt_thumbnail : TextView = itemView.findViewById(R.id.txt_thumbnail)
        val image_view : ImageView = itemView.findViewById(R.id.image_view)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.itemlist, parent, false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = productList[position]

        Picasso.get()
            .load(product.images.firstOrNull())
            .into(holder.image_view)

        holder.txt_id.text = product.id.toString()
        //holder.txt_description.text = product.description
        //holder.txt_price.text = product.price.toString()
        //holder.txt_discountpercentage.text = product.discountPercentage.toString()
        //holder.txt_rating.text = product.rating.toString()
        //holder.txt_stock.text = product.stock.toString()
        holder.txt_title.text = product.title
        //holder.txt_brand.text = product.brand
        holder.txt_category.text = product.category
        //holder.txt_thumbnail.text = product.thumbnail

        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context , UrunListDetay::class.java)
            intent.putExtra("product_id", productList[position].id)
            intent.putExtra("product_title", productList[position].title)
            intent.putExtra("product_description", productList[position].description)
            intent.putExtra("product_price", productList[position].price)
            intent.putExtra("product_discountPercentage", productList[position].discountPercentage)
            intent.putExtra("product_rating", productList[position].rating)
            intent.putExtra("product_stock", productList[position].stock)
            intent.putExtra("product_brand", productList[position].brand)
            intent.putExtra("product_category", productList[position].category)
            intent.putExtra("product_thumbnail", productList[position].thumbnail)
            holder.itemView.context.startActivity(intent)
        }
    }
    override fun getItemCount(): Int {
        return productList.size
    }

    @SuppressLint("NotifyDataSetChanged")
    fun updateData(products: List<Product>) {
        productList = products
        notifyDataSetChanged()

    }

}