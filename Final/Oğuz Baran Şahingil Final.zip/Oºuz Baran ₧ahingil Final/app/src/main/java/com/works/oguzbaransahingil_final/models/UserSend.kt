package com.works.oguzbaransahingil_final.models

data class UserSend(
    val username : String,
    val password : String
)
