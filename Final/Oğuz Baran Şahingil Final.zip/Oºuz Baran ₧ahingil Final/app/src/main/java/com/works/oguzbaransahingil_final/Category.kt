package com.works.oguzbaransahingil_final

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.works.oguzbaransahingil_final.adapter.ListAdapter
import com.works.oguzbaransahingil_final.models.Product
import com.works.oguzbaransahingil_final.service.DummyService
import org.json.JSONArray
import org.json.JSONObject

class Category : AppCompatActivity() {

    private lateinit var categoryAdapter: CategoryAdapter
    private lateinit var getSubCategories : List<categorytitle>
    lateinit var dummyService: DummyService

    private fun parseProducts(json: JSONObject): List<categorytitle> {
        val productsList = mutableListOf<categorytitle>()
        val productsArray: JSONArray = json.getJSONArray("products")

        for (i in 0 until productsArray.length()) {
            val productObject = productsArray.getJSONObject(i)
            val id = productObject.getLong("id")
            val title = productObject.getString("title")
            val description = productObject.getString("description")
            val price = productObject.getLong("price")
            val discountPercentage = productObject.getDouble("discountPercentage")
            val rating = productObject.getDouble("rating")
            val stock = productObject.getLong("stock")
            val brand = productObject.getString("brand")
            val category = productObject.getString("category")
            val thumbnail = productObject.getString("thumbnail")
            val imagesArray = productObject.getJSONArray("images")
            val images = mutableListOf<String>()

            for (j in 0 until imagesArray.length()) {
                images.add(imagesArray.getString(j))
            }


            val product = Product(id, title, description, price, discountPercentage, rating, stock, brand, category,  thumbnail, images)
            productsList.add(product)



        }

        return productsList
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category)
        

        val recycler_Categoryview : RecyclerView = findViewById(R.id.recycler_Categoryview)
        recycler_Categoryview.layoutManager = LinearLayoutManager(this)

        categoryAdapter = CategoryAdapter(emptyList())
        recycler_Categoryview.adapter = categoryAdapter

        val queue : RequestQueue = Volley.newRequestQueue(this)
        val url = "https://dummyjson.com/products/categories"

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, url, null,
            { response ->
                getSubCategories = parseProducts(response)
                categoryAdapter.uptadeData(getSubCategories)
            },
            { error ->
                error.printStackTrace()
            }
        )
        queue.add(jsonObjectRequest)
        fun filterProducts(query: String): List<categorytitle> {
            return getSubCategories.filter { it.title.contains(query, ignoreCase = true) }
        }
        





    }
}

private fun <E> List<E>.add(element: Product) {

}
