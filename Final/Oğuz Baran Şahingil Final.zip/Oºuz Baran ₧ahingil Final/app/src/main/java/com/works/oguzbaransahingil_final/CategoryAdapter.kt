package com.works.oguzbaransahingil_final

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

private fun Any.inflate(categorylist: Int): View {
    TODO("Not yet implemented")
}

class CategoryAdapter (private var categorylist : List<categorytitle>):
    RecyclerView.Adapter<CategoryAdapter.ProductViewHolder>() {

        class ProductViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView){
            val txt_Cate_id : TextView = itemView.findViewById(R.id.txt_Cate_id)

        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.categorylist, parent,false)
        return ProductViewHolder(view)
    }


    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = categorylist[position]


        holder.txt_Cate_id.text = product.title

        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context , CategoryListDetay::class.java)
            intent.putExtra("product_title", categorylist[position].title)

            holder.itemView.context.startActivity(intent)
        }
    }
    override fun getItemCount(): Int {
        return categorylist.size
    }

    @SuppressLint("NotifyDataSetChanged")
    fun uptadeData(Categorurun: List<categorytitle>) {
        categorylist = Categorurun
        notifyDataSetChanged()
    }
}



