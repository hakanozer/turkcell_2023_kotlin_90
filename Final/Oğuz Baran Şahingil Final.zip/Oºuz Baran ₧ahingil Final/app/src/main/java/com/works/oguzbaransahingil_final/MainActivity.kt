package com.works.oguzbaransahingil_final

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.works.oguzbaransahingil_final.configs.ApiClient
import com.works.oguzbaransahingil_final.models.JWTUser
import com.works.oguzbaransahingil_final.models.UserSend
import com.works.oguzbaransahingil_final.service.DummyService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
// Hocam bahane üretmek amaçlı yazmıyorum fakat ayda 2 veya 3 gün izin günüm oluyor.
// Yoğun çalışıyoruz ve yaptığım işten dolayı sürekli insanlarla ikili diyalog yapıyorum ve gün içinde yoruluyorum.
// Arkadaşlarıma göre aynı düzeyde olmam çok zor çünkü farklı meslek grubundayım ve boş vaktim akşam 19:00'dan sonra oluyor.
// Son dönemlerde ders tekrarı ve çalışmalarımıda yapamadım bunlar başta dediğim gibi bir bahane değil.
// Final ödevini neden tam anlamıyla yapamadığımı sadece dile getirmek istiyorum.
// Çünkü uzun bir eğitim sürecimiz oldu dersleri kaçırmadım ve siz çok emek harcadınız.
// Tekrar dile getirmek istiyorum bunları bakış açınız değişsin , beni farklı değerledirin için asla söylemiyorum.
// Sadece bu final ödevini yapamamak beni size karşı mahçup hissettirdi. Kusura bakmayın.
// BÖyle bir emeğe karşılık böyle bir final ödevi teslim etmek istemezdim , tekrardan kusura bakmayın. Teşekkürler.

class MainActivity : AppCompatActivity() {

    lateinit var edit_kullanici: EditText
    lateinit var edit_password : EditText
    lateinit var btn_login : Button
    lateinit var dummyService: DummyService


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edit_kullanici = findViewById(R.id.edit_kullanici)
        edit_password = findViewById(R.id.edit_password)
        btn_login = findViewById(R.id.btn_login)

        dummyService = ApiClient.getClient().create(DummyService::class.java)

        btn_login.setOnClickListener {
            val username = edit_kullanici.text.toString().trim()
            val password = edit_password.text.toString().trim()
            val userSend = UserSend(username,password)

            if (userSend.username == "kminchelle" && userSend.password == "0lelplR"){
                dummyService.login(userSend).enqueue(object: Callback<JWTUser> {
                    override fun onResponse(call: Call<JWTUser>, response: Response<JWTUser>) {
                        val status = response.code()

                        if (status == 200){
                            val user = response.body()
                            if (user != null){
                                val intent = Intent (this@MainActivity, urunlist::class.java)
                                startActivity(intent)
                            }
                        }else{
                            Toast.makeText(this@MainActivity , "Kullanıcı adı veya Şifreniz hatalıdır", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<JWTUser>, t: Throwable) {
                        Log.e("Login Fail", t.toString() )
                    }
                })
            }else{
                Toast.makeText(this@MainActivity , "Kullanıcı adı veya Şifreniz hatalıdır", Toast.LENGTH_SHORT).show()
            }
        }
    }
}