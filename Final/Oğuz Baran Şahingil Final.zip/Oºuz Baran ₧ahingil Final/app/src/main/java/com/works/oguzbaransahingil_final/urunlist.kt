package com.works.oguzbaransahingil_final


import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.works.oguzbaransahingil_final.adapter.ListAdapter
import com.works.oguzbaransahingil_final.configs.ApiClient
import com.works.oguzbaransahingil_final.models.Product
import com.works.oguzbaransahingil_final.service.DummyService
import org.json.JSONArray
import org.json.JSONObject


class urunlist : AppCompatActivity() {


    private lateinit var productAdapter: ListAdapter
    private lateinit var allProducts: List<Product>
    private lateinit var product: Product
    lateinit var btn_category : Button
    lateinit var btn_profil : Button
    lateinit var dummyService: DummyService
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_urunlist)



        val search_view: SearchView = findViewById(R.id.search_view)
        val recycler_view: RecyclerView = findViewById(R.id.recycler_Categoryview)
        recycler_view.layoutManager = LinearLayoutManager(this)
        btn_category = findViewById(R.id.btn_category)
        btn_profil = findViewById(R.id.btn_profil)

        dummyService = ApiClient.getClient().create(DummyService::class.java)

        btn_category.setOnClickListener {
            val intent = Intent(this@urunlist, Category::class.java)
            startActivity(intent)
        }

        btn_profil.setOnClickListener {
            val intent1 = Intent(this@urunlist, Profil::class.java)
            startActivity(intent1)
        }



        productAdapter = ListAdapter(emptyList())
        recycler_view.adapter = productAdapter

        val queue: RequestQueue = Volley.newRequestQueue(this)
        val url = "https://dummyjson.com/products?limit=10"


        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, url, null,
            { response ->
                allProducts = parseProducts(response)
                productAdapter.updateData(allProducts)
            },
            { error ->
                error.printStackTrace()
            }

        )

        queue.add(jsonObjectRequest)

        search_view.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                val filteredProducts = filterProducts(newText.orEmpty())
                productAdapter.updateData(filteredProducts)
                return true
            }
        })

    }



    private fun filterProducts(query: String): List<Product> {
        return allProducts.filter { it.title.contains(query, ignoreCase = true) }
    }

    private fun parseProducts(json: JSONObject): List<Product> {
        val productsList = mutableListOf<Product>()
        val productsArray: JSONArray = json.getJSONArray("products")

        for (i in 0 until productsArray.length()) {
            val productObject = productsArray.getJSONObject(i)
            val id = productObject.getLong("id")
            val title = productObject.getString("title")
            val description = productObject.getString("description")
            val price = productObject.getLong("price")
            val discountPercentage = productObject.getDouble("discountPercentage")
            val rating = productObject.getDouble("rating")
            val stock = productObject.getLong("stock")
            val brand = productObject.getString("brand")
            val category = productObject.getString("category")
            val thumbnail = productObject.getString("thumbnail")
            val imagesArray = productObject.getJSONArray("images")
            val images = mutableListOf<String>()

            for (j in 0 until imagesArray.length()) {
                images.add(imagesArray.getString(j))
            }


            val product = Product(id, title, description, price, discountPercentage, rating, stock, brand, category,  thumbnail, images)
            productsList.add(product)



        }

        return productsList
    }
}