package com.works.oguzbaransahingil_final

data class Categoryurun (
    val products: List<categorytitle>,
    val total: Long,
    val skip: Long,
    val limit: Long
)

data class categorytitle (
    val title: String
)
