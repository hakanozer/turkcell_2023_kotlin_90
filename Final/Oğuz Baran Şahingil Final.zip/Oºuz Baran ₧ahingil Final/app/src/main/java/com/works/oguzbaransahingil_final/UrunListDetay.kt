package com.works.oguzbaransahingil_final

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.squareup.picasso.Picasso
import com.works.oguzbaransahingil_final.configs.ApiClient
import com.works.oguzbaransahingil_final.models.Product
import com.works.oguzbaransahingil_final.service.DummyService

class UrunListDetay : AppCompatActivity() {

    private lateinit var dummyService: DummyService
    lateinit var img_Details : ImageView
    lateinit var txt_idDetails : TextView
    lateinit var txt_titleDetails : TextView
    lateinit var txt_categoryDetails : TextView
    lateinit var txt_descriptionDetails : TextView
    lateinit var txt_priceDetails : TextView
    lateinit var txt_discountPercentageDetails : TextView
    lateinit var txt_ratingDetails : TextView
    lateinit var txt_stockDetails : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_urun_list_detay)

        img_Details = findViewById(R.id.img_Cdetails)
        txt_idDetails = findViewById(R.id.txt_idCDetails)
        txt_titleDetails = findViewById(R.id.txt_titleCDetails)
        txt_categoryDetails = findViewById(R.id.txt_categoryCDetails)
        txt_descriptionDetails = findViewById(R.id.txt_descriptionCDetails)
        txt_priceDetails = findViewById(R.id.txt_priceCDetails)
        txt_discountPercentageDetails = findViewById(R.id.txt_discountPercentageCDetails)
        txt_ratingDetails = findViewById(R.id.txt_ratingCDetails)
        txt_stockDetails = findViewById(R.id.txt_stockCDetails)

        dummyService = ApiClient.getClient().create(DummyService::class.java)
        val productid = intent.extras?.getLong("product_id")
        val producttitle = intent.extras?.getLong("product_title")
        val productdescription = intent.extras?.getLong("product_description")
        val productprice = intent.extras?.getLong("product_price")
        val productdiscountPercentage = intent.extras?.getLong("product_discountPercentage")
        val productrating = intent.extras?.getLong("product_rating")
        val productstock = intent.extras?.getLong("product_stock")
        val productbrand = intent.extras?.getLong("product_brand")
        val productcategory = intent.extras?.getLong("product_category")
        val productthumbnail = intent.extras?.getLong("product_thumbnail")

        val product:Product? = intent.getSerializableExtra("product")as? Product

        if (product != null) {
            productDetails(product)
        }



    }
    @SuppressLint("SetTextI18n")
    fun productDetails(product: Product){

        Picasso.get()
            .load(product.images.firstOrNull())
            .into(img_Details)
        txt_idDetails.text = product.id.toString()
        txt_titleDetails.text = product.title
        txt_categoryDetails.text = product.category
        txt_descriptionDetails.text = "Description : ${product.description}"
        txt_priceDetails.text = "Price : ${product.price}"
        txt_discountPercentageDetails.text = product.discountPercentage.toString()
        txt_ratingDetails.text = "Rating : ${product.rating})"
        txt_stockDetails.text = "Stock : ${product.stock}"

    }


}