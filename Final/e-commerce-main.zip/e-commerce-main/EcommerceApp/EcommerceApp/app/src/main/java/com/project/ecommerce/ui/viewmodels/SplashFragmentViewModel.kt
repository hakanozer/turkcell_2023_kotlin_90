package com.project.ecommerce.ui.viewmodels


class SplashFragmentViewModel {

}