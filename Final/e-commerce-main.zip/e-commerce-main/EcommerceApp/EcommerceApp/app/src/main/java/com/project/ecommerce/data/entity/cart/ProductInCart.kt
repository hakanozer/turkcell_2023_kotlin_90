package com.project.ecommerce.data.entity.cart

data class ProductInCart(
    val id: Int,
    val quantity: Int
)
