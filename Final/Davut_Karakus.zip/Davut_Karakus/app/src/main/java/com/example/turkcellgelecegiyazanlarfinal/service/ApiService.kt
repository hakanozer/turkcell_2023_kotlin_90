package com.example.turkcellgelecegiyazanlarfinal.service

import com.example.turkcellgelecegiyazanlarfinal.model.CartRequest
import com.example.turkcellgelecegiyazanlarfinal.model.CartResponse
import com.example.turkcellgelecegiyazanlarfinal.model.Carts
import com.example.turkcellgelecegiyazanlarfinal.model.JWTUser
import com.example.turkcellgelecegiyazanlarfinal.model.Product
import com.example.turkcellgelecegiyazanlarfinal.model.ProductResponse
import com.example.turkcellgelecegiyazanlarfinal.model.Products
import com.example.turkcellgelecegiyazanlarfinal.model.Profile
import com.example.turkcellgelecegiyazanlarfinal.model.UpdateProfile
import com.example.turkcellgelecegiyazanlarfinal.model.User
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @POST("auth/login")
    suspend fun login (@Body userSend: User) : Response<JWTUser>

    @GET("products")
    suspend fun getAllData() : Response<Products>

    @GET("products/{id}")
    suspend fun getData(@Path("id") id:Long) : Response<Product>

    @GET("products/search?")
    suspend fun searchProduct(@Query("q") q:String) : Response<Products>

    @POST("carts/add")
    suspend fun addToCart(@Body request: CartRequest): Response<CartResponse>

    @GET("products/categories")
    suspend fun getCategories() : Response<List<String>>

    @GET("products/category/{category}")
    suspend fun getProductsWithCategory(@Path("category") category:String) : Response<Products>

    @GET("carts/user/{id}")
    suspend fun getProductsInCart(@Path("id") id:Long) : Response<Carts>

    @GET("users/{id}")
    suspend fun getProfileInfo(@Path("id") id:Long) : Response<Profile>

    @PUT("users/{id}")
    suspend fun updateProfile(@Path("id") id: Long, @Body request: UpdateProfile): Response<UpdateProfile>

}