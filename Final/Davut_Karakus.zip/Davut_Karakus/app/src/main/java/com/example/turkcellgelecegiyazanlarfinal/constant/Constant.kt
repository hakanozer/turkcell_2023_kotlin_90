package com.example.turkcellgelecegiyazanlarfinal.constant

object Constant {
    const val BASE_URL = "https://dummyjson.com/"
}