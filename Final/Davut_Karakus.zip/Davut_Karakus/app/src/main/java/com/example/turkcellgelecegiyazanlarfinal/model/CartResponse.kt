package com.example.turkcellgelecegiyazanlarfinal.model

import com.google.gson.annotations.SerializedName

data class CartResponse(
    @SerializedName("id")
    val id: Long,
    @SerializedName("products")
    val products: List<ProductResponse>,
    @SerializedName("total")
    val total: Long,
    @SerializedName("discountedTotal")
    val discountedTotal: Long,
    @SerializedName("userId")
    val userId: Long,
    @SerializedName("totalProducts")
    val totalProducts: Long,
    @SerializedName("totalQuantity")
    val totalQuantity: Long
)