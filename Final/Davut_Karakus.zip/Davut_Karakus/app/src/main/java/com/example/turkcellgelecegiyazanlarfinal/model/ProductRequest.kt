package com.example.turkcellgelecegiyazanlarfinal.model

import com.google.gson.annotations.SerializedName

data class ProductRequest(
    @SerializedName("id")
    val id: Int,
    @SerializedName("quantity")
    val quantity: Int
)