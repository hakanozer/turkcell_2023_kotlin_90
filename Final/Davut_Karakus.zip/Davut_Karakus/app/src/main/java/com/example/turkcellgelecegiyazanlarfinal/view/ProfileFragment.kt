package com.example.turkcellgelecegiyazanlarfinal.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.turkcellgelecegiyazanlarfinal.databinding.FragmentProfileBinding
import com.example.turkcellgelecegiyazanlarfinal.model.UpdateProfile
import com.example.turkcellgelecegiyazanlarfinal.util.globalId
import com.example.turkcellgelecegiyazanlarfinal.viewmodel.ProfileViewModel
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class ProfileFragment @Inject constructor(
) : Fragment() {
    private lateinit var binding : FragmentProfileBinding
    private lateinit var viewModel : ProfileViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentProfileBinding.inflate(inflater,container,false)
        val actionBar = (requireActivity() as AppCompatActivity).supportActionBar
        actionBar?.title = "Profile"
        actionBar?.show()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this)[ProfileViewModel::class.java]
        binding.viewModel = viewModel
        binding.lifecycleOwner = this
        context?.let { viewModel.getDataFromApi(globalId ?: 0, it) }
        binding.saveButton.setOnClickListener {
            val firstName = binding.profilefirstName.text.toString()
            val lastName = binding.profileLastName.text.toString()
            val email = binding.gmailEditText.text.toString()
            val phone = binding.phoneEditText.text.toString()
            val gender = binding.genderEditText.text.toString()
            val modelProfile = UpdateProfile(globalId ?: 0,firstName,lastName,email,phone,gender)
            context?.let { it1 -> viewModel.updateProfile(globalId ?: 0,modelProfile, it1) }
        }
        observeData()
    }

    private fun observeData(){
        viewModel.isSuccess.observe(viewLifecycleOwner, Observer{
            Toast.makeText(context,"it was successfully saved",Toast.LENGTH_LONG).show()
        })
    }
}