package com.example.turkcellgelecegiyazanlarfinal.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.GridLayoutManager
import com.example.turkcellgelecegiyazanlarfinal.adapter.CategoryRecyclerViewAdapter
import com.example.turkcellgelecegiyazanlarfinal.databinding.CategoryRecyclerRowBinding
import com.example.turkcellgelecegiyazanlarfinal.databinding.FragmentCategoryBinding
import com.example.turkcellgelecegiyazanlarfinal.viewmodel.CategoryViewModel
import dagger.hilt.android.AndroidEntryPoint
import java.util.Locale
import javax.inject.Inject

@AndroidEntryPoint
class CategoryFragment @Inject constructor() : Fragment(),CategoryRecyclerViewAdapter.OnItemClickListener {
    private lateinit var binding : FragmentCategoryBinding
    private lateinit var viewModel : CategoryViewModel
    private val recyclerViewAdapter = CategoryRecyclerViewAdapter(arrayListOf(),this)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCategoryBinding.inflate(inflater,container,false)
        val actionBar = (requireActivity() as AppCompatActivity).supportActionBar
        actionBar?.show()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this)[CategoryViewModel::class.java]
        binding.categoryList.layoutManager = GridLayoutManager(context,2)
        binding.categoryList.adapter = recyclerViewAdapter
        binding.viewModel = viewModel
        binding.lifecycleOwner = this
        observeData()
    }

    private fun observeData(){
        viewModel.categories.observe(viewLifecycleOwner, Observer{ list ->
            val updatedList = list.map { it1 -> it1.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() } }
            recyclerViewAdapter.updateCategoryList(updatedList)
        })
    }

    override fun onItemClickListenerCategory(v: View) {
        val binding = v.tag as? CategoryRecyclerRowBinding ?: return
        val category = binding.category ?: return
        val action = CategoryFragmentDirections.actionCategoryFragmentToCategoryDetailFragment(category)
        Navigation.findNavController(v).navigate(action)
    }

}