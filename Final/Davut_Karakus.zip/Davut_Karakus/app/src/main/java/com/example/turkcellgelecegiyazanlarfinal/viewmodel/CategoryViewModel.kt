package com.example.turkcellgelecegiyazanlarfinal.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.turkcellgelecegiyazanlarfinal.repo.ProductsRepository
import com.example.turkcellgelecegiyazanlarfinal.util.isWifiEnabled
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CategoryViewModel @Inject constructor(private val repo: ProductsRepository,@ApplicationContext context: Context) : ViewModel(){
    val _categories = MutableLiveData<List<String>>()
    val categoryLoading = MutableLiveData<Boolean>()
    val categoryError = MutableLiveData<Boolean>()
    val categories: LiveData<List<String>>
        get() = _categories

    init {
        getCategories(context)
    }

    private fun getCategories(context:Context) = viewModelScope.launch(Dispatchers.IO ) {
        categoryLoading.postValue(true)
        categoryError.postValue(false)
        if(isWifiEnabled(context)){
            repo.getCategories().let {response->
                if(response.isSuccessful){
                    _categories.postValue(response.body() ?: listOf())
                    categoryLoading.postValue(false)
                }else{
                    categoryLoading.postValue(false)
                    categoryError.postValue(true)
                    Log.i("CategoryViewModel","Error!")
                }
            }
        }else {
            delay(1000)
            categoryLoading.postValue(false)
            categoryError.postValue(true)
            Log.i("CategoryViewModel","Internet Connection Problem!")
        }
    }

}