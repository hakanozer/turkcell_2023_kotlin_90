package com.example.turkcellgelecegiyazanlarfinal.model

import com.google.gson.annotations.SerializedName

data class Profile (
    @SerializedName("id")
    val id: Long,
    @SerializedName("firstName")
    val firstName: String,
    @SerializedName("lastName")
    val lastName: String,
    @SerializedName("maidenName")
    val maidenName: String,
    @SerializedName("age")
    val age: Long,
    @SerializedName("gender")
    val gender: String,
    @SerializedName("email")
    val email: String,
    @SerializedName("phone")
    val phone: String,
    @SerializedName("username")
    val username: String,
    @SerializedName("password")
    val password: String,
    @SerializedName("birthDate")
    val birthDate: String,
    @SerializedName("image")
    val image: String,
    @SerializedName("bloodGroup")
    val bloodGroup: String,
    @SerializedName("height")
    val height: Long,
    @SerializedName("weight")
    val weight: Double,
    @SerializedName("eyeColor")
    val eyeColor: String,
    @SerializedName("hair")
    val hair: Hair,
    @SerializedName("domain")
    val domain: String,
    @SerializedName("ip")
    val ip: String,
    @SerializedName("address")
    val address: Address,
    @SerializedName("macAddress")
    val macAddress: String,
    @SerializedName("university")
    val university: String,
    @SerializedName("bank")
    val bank: Bank,
    @SerializedName("company")
    val company: Company,
    @SerializedName("ein")
    val ein: String,
    @SerializedName("ssn")
    val ssn: String,
    @SerializedName("userAgent")
    val userAgent: String
)