package com.example.turkcellgelecegiyazanlarfinal.view.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.turkcellgelecegiyazanlarfinal.R
import com.example.turkcellgelecegiyazanlarfinal.databinding.ActivityLoginBinding
import com.example.turkcellgelecegiyazanlarfinal.view.LoginFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoginActivity : AppCompatActivity() {
    private lateinit var binding : ActivityLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (savedInstanceState == null) {
            val loginFragment = LoginFragment()
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerView, loginFragment)
                .commit()
        }
    }

}