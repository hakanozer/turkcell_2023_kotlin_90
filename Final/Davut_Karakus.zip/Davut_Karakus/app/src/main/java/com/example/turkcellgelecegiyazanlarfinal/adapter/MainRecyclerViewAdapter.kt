package com.example.turkcellgelecegiyazanlarfinal.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.turkcellgelecegiyazanlarfinal.R
import com.example.turkcellgelecegiyazanlarfinal.databinding.RecyclerRowBinding
import com.example.turkcellgelecegiyazanlarfinal.model.Product

class MainRecyclerViewAdapter(private var productList:ArrayList<Product>, private val listener: OnItemClickListener) :  RecyclerView.Adapter<MainRecyclerViewAdapter.RvHolder>(),ItemClickListener{
    class RvHolder(var view: RecyclerRowBinding) : RecyclerView.ViewHolder(view.root) {
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RvHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = DataBindingUtil.inflate<RecyclerRowBinding>(inflater, R.layout.recycler_row,parent,false)
        return RvHolder(view)
    }

    override fun getItemCount(): Int {
        return productList.size
    }

    override fun onBindViewHolder(holder: RvHolder, position: Int) {
        holder.view.product = productList[position]
        holder.view.listener = this
        holder.view.root.tag = holder.view
    }

    fun updateProductList(newProductList:List<Product>){
        productList.clear()
        productList.addAll(newProductList)
        notifyDataSetChanged()
    }

    override fun onItemClicked(v: View) {
        listener.onItemClickListenerProducts(v)
    }

    interface OnItemClickListener {
        fun onItemClickListenerProducts(v:View)
    }

}