package com.example.turkcellgelecegiyazanlarfinal.model

import com.google.gson.annotations.SerializedName

data class UpdateProfile(
    @SerializedName("id")
    val id: Long,
    @SerializedName("firstName")
    val firstName: String,
    @SerializedName("lastName")
    val lastName: String,
    @SerializedName("email")
    val email: String,
    @SerializedName("phone")
    val phone: String,
    @SerializedName("gender")
    val gender: String
)