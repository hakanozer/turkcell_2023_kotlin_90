package com.example.turkcellgelecegiyazanlarfinal.model

import com.google.gson.annotations.SerializedName

data class Carts (
    @SerializedName("carts")
    val carts: List<CartResponse>,
    @SerializedName("total")
    val total: Long,
    @SerializedName("skip")
    val skip: Long,
    @SerializedName("limit")
    val limit: Long
)
