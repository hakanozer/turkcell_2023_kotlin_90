package com.example.turkcellgelecegiyazanlarfinal.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.turkcellgelecegiyazanlarfinal.model.User
import com.example.turkcellgelecegiyazanlarfinal.repo.ProductsRepository
import com.example.turkcellgelecegiyazanlarfinal.util.globalId
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LoginViewModel@Inject constructor(private val repo: ProductsRepository) : ViewModel() {
    val loading = MutableLiveData<Boolean>()
    val error = MutableLiveData<Boolean>()
    val loginIsSucces = MutableLiveData<Boolean>()

    fun loginUser(user: User) = viewModelScope.launch {
        loading.postValue(true)
        repo.loginUser(user).let { response ->
            if(response.isSuccessful){
                globalId = response.body()?.id
                loading.postValue(false)
                loginIsSucces.postValue(true)
            }else {
                loading.postValue(false)
                error.postValue(true)
                Log.i("LoginViewModel","Error!")
            }
        }
    }

}