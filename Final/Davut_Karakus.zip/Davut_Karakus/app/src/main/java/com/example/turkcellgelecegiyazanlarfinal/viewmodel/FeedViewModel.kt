package com.example.turkcellgelecegiyazanlarfinal.viewmodel

import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.turkcellgelecegiyazanlarfinal.model.Product
import com.example.turkcellgelecegiyazanlarfinal.repo.ProductsRepository
import com.example.turkcellgelecegiyazanlarfinal.util.isWifiEnabled
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FeedViewModel @Inject constructor(private val repository: ProductsRepository, @ApplicationContext context: Context) : ViewModel(){
    private val _products = MutableLiveData<List<Product>>()
    val productsError = MutableLiveData<Boolean>()
    val productsLoading = MutableLiveData<Boolean>()
    val products: LiveData<List<Product>>
        get() = _products

    init {
        getAllProducts(context)
    }

     private fun getAllProducts(context: Context) = viewModelScope.launch {
        if(repository.getAllProductsDao().isEmpty()) {
            getDataFromApi(context)
        }else {
            getDataFromDao(context)
        }
    }

    fun getDataFromApi(context: Context) = viewModelScope.launch(Dispatchers.IO ){
        productsLoading.postValue(true)
        productsError.postValue(false)
        if(isWifiEnabled(context)){
            repository.getAllProducts().let {response->
                if(response.isSuccessful){
                    _products.postValue(response.body()?.products ?: listOf())
                        deleteAllProducts()
                    response.body()?.products?.let {
                        insertAllProducts(it)
                    }
                    viewModelScope.launch (Dispatchers.Main){
                        Toast.makeText(context,"Data is coming from API",Toast.LENGTH_LONG).show()
                    }
                    productsLoading.postValue(false)
                }else{
                    productsLoading.postValue(false)
                    productsError.postValue(true)
                    Log.i("FeedViewModel","Error!")
                }
            }
        }else {
            delay(1000)
            productsLoading.postValue(false)
            productsError.postValue(true)
            Log.i("FeedViewModel","Internet Connection Problem!")
        }
    }

    fun searchProduct(query:String) = viewModelScope.launch(Dispatchers.Main){
        if (query.isNotEmpty()) {
            productsLoading.postValue(true)
            productsError.postValue(false)
            repository.searchProduct(query).let {response->
                if(response.isSuccessful){
                    _products.postValue(response.body()?.products ?: listOf())
                    productsLoading.postValue(false)
                }else{
                    productsLoading.postValue(false)
                    productsError.postValue(true)
                    Log.i("FeedViewModel","Error!")
                }
            }
        }
    }

    private fun getDataFromDao(context: Context) = viewModelScope.launch(Dispatchers.IO) {
        val charList = repository.getAllProductsDao()
        productsLoading.postValue(true)
        if(charList.isEmpty()) {
            productsError.postValue(true)
        }else {
            _products.postValue(charList)
            productsLoading.postValue(false)
            viewModelScope.launch (Dispatchers.Main){
                Toast.makeText(context,"Data is coming from Room",Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun insertAllProducts(list:List<Product>) = viewModelScope.launch(Dispatchers.IO) {
        repository.insertProductsDao(*list.toTypedArray())
    }
    private fun deleteAllProducts() = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteAllProductsDao()
    }

}