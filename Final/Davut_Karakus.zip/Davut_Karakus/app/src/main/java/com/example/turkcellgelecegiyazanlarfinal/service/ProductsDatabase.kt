package com.example.turkcellgelecegiyazanlarfinal.service

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.turkcellgelecegiyazanlarfinal.model.ListTypeConverter
import com.example.turkcellgelecegiyazanlarfinal.model.Product

@Database(entities = [Product::class], version = 1)
@TypeConverters(ListTypeConverter::class)
abstract class ProductsDatabase : RoomDatabase() {
    abstract fun productsDao() : ProductsDao
}