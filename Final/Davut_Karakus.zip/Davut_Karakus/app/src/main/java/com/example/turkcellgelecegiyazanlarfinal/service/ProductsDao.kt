package com.example.turkcellgelecegiyazanlarfinal.service

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.turkcellgelecegiyazanlarfinal.model.Product

@Dao
interface ProductsDao {
    @Insert
    suspend fun insertAll(vararg products: Product)
    @Query("SELECT * FROM products")
    suspend fun getAllProducts() : List<Product>
    @Query("DELETE FROM products")
    suspend fun deleteAllProducts()
    @Query("SELECT * FROM products WHERE id = :productId")
    suspend fun getProduct(productId:Int) : Product
}