package com.example.turkcellgelecegiyazanlarfinal.adapter

import android.view.View

interface ItemClickListener {
    fun onItemClicked(v: View)
}
