package com.example.turkcellgelecegiyazanlarfinal.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.turkcellgelecegiyazanlarfinal.model.CartResponse
import com.example.turkcellgelecegiyazanlarfinal.model.ProductResponse
import com.example.turkcellgelecegiyazanlarfinal.repo.ProductsRepository
import com.example.turkcellgelecegiyazanlarfinal.util.isWifiEnabled
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CartViewModel  @Inject constructor(private val repo: ProductsRepository,@ApplicationContext context: Context) : ViewModel() {
    private val _products = MutableLiveData<List<ProductResponse>>()
    val productsError = MutableLiveData<Boolean>()
    val productsLoading = MutableLiveData<Boolean>()
    val products: LiveData<List<ProductResponse>>
        get() = _products

    fun getDataFromApi(id:Long,context: Context) = viewModelScope.launch(Dispatchers.IO ) {
        productsLoading.postValue(true)
        productsError.postValue(false)
        if(isWifiEnabled(context)){
            repo.getProductsInCarts(id).let {response->
                if(response.isSuccessful){
                    val carts = response.body()
                    if (carts?.carts != null && carts.carts.isNotEmpty()) {
                        val products = carts.carts[0].products
                        _products.postValue(products)
                    }
                    productsLoading.postValue(false)
                }else{
                    productsLoading.postValue(false)
                    productsError.postValue(true)
                    Log.i("CartViewModel","Error!")
                }
            }
        }else {
            delay(1000)
            productsLoading.postValue(false)
            productsError.postValue(true)
            Log.i("CartViewModel","Internet Connection Problem!")
        }
    }

}