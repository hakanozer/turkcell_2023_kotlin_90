package com.example.turkcellgelecegiyazanlarfinal.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.turkcellgelecegiyazanlarfinal.adapter.CartRecyclerViewAdapter
import com.example.turkcellgelecegiyazanlarfinal.databinding.FragmentCartBinding
import com.example.turkcellgelecegiyazanlarfinal.util.globalId
import com.example.turkcellgelecegiyazanlarfinal.viewmodel.CartViewModel
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class CartFragment @Inject constructor() : Fragment(){
    private lateinit var binding : FragmentCartBinding
    private lateinit var viewModel : CartViewModel
    private val recyclerViewAdapter = CartRecyclerViewAdapter(arrayListOf())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCartBinding.inflate(inflater,container,false)
        val actionBar = (requireActivity() as AppCompatActivity).supportActionBar
        actionBar?.title = "Cart"
        actionBar?.show()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this)[CartViewModel::class.java]
        binding.cartProductList.layoutManager = LinearLayoutManager(context)
        binding.cartProductList.adapter = recyclerViewAdapter
        binding.viewModel = viewModel
        binding.lifecycleOwner = this
        context?.let { viewModel.getDataFromApi(globalId ?: 0, it) }
        observeData()
    }

    private fun observeData(){
        viewModel.products.observe(viewLifecycleOwner, Observer{ list ->
            recyclerViewAdapter.updateProductList(list)
        })
    }

}