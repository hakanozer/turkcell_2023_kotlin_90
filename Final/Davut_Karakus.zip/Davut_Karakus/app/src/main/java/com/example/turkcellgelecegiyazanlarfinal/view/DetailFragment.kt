package com.example.turkcellgelecegiyazanlarfinal.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.turkcellgelecegiyazanlarfinal.R
import com.example.turkcellgelecegiyazanlarfinal.databinding.FragmentDetailBinding
import com.example.turkcellgelecegiyazanlarfinal.model.CartRequest
import com.example.turkcellgelecegiyazanlarfinal.model.ProductRequest
import com.example.turkcellgelecegiyazanlarfinal.viewmodel.DetailViewModel
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class DetailFragment @Inject constructor() : Fragment() {
    private lateinit var viewModel : DetailViewModel
    private lateinit var binding : FragmentDetailBinding
    private var productId = 0L
    private var quantity = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            productId = DetailFragmentArgs.fromBundle(it).productId
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_detail,container,false)
        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        quantity = binding.quantityTextView.text.toString().toInt()
        viewModel = ViewModelProvider(this)[DetailViewModel::class.java]
        binding.viewModel = viewModel
        binding.lifecycleOwner = this
        getData()

        binding.plusButton.setOnClickListener {
            quantity++
            binding.quantityTextView.text = quantity.toString()
        }

        binding.minusButton.setOnClickListener {
            if (quantity > 1){
                quantity--
                binding.quantityTextView.text = quantity.toString()
            }
        }

        binding.addToCartButton.setOnClickListener {
            val product = ProductRequest(productId.toInt(),quantity)
            val list = arrayListOf<ProductRequest>()
            list.add(product)
            val cart = CartRequest(1,list)
            viewModel.addToCart(cart)
        }
    }

    private fun getData() {
        context?.let {
            viewModel.getData(productId, it)
        }
        viewModel.cartAddingIsSucces.observe(viewLifecycleOwner,Observer{
            if (it){
                Toast.makeText(context,"Added To Cart Successfully", Toast.LENGTH_LONG).show()
            }
        })
    }

}