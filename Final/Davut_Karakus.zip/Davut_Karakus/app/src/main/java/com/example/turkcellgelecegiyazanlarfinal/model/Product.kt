package com.example.turkcellgelecegiyazanlarfinal.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity(tableName = "products")
data class Product (
    @ColumnInfo(name = "id")
    @SerializedName("id")
    val id: Long,
    @ColumnInfo(name = "title")
    @SerializedName("title")
    val title: String,
    @ColumnInfo(name = "description")
    @SerializedName("description")
    val description: String,
    @ColumnInfo(name = "price")
    @SerializedName("price")
    val price: Long,
    @ColumnInfo(name = "discountPercentage")
    @SerializedName("discountPercentage")
    val discountPercentage: Double,
    @ColumnInfo(name = "rating")
    @SerializedName("rating")
    val rating: Double,
    @ColumnInfo(name = "stock")
    @SerializedName("stock")
    val stock: Long,
    @ColumnInfo(name = "brand")
    @SerializedName("brand")
    val brand: String,
    @ColumnInfo(name = "category")
    @SerializedName("category")
    val category: String,
    @ColumnInfo(name = "thumbnail")
    @SerializedName("thumbnail")
    val thumbnail: String,
    @ColumnInfo(name = "images")
    @SerializedName("images")
    val images: List<String>
){
    @PrimaryKey(autoGenerate = true)
    var uuid:Int = 0
}