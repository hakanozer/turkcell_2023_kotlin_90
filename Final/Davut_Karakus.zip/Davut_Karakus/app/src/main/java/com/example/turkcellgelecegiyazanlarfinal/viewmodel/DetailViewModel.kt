package com.example.turkcellgelecegiyazanlarfinal.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.turkcellgelecegiyazanlarfinal.model.CartRequest
import com.example.turkcellgelecegiyazanlarfinal.model.Product
import com.example.turkcellgelecegiyazanlarfinal.repo.ProductsRepository
import com.example.turkcellgelecegiyazanlarfinal.util.isWifiEnabled
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetailViewModel @Inject constructor(private val repo:ProductsRepository) : ViewModel() {
    val _product = MutableLiveData<Product>()
    val productLoading = MutableLiveData<Boolean>()
    val productError = MutableLiveData<Boolean>()
    val cartAddingIsSucces = MutableLiveData<Boolean>()
    fun getData(id:Long,context: Context) {
        productLoading.value = true
        if (isWifiEnabled(context)){
            getCharacter(id)
        }else {
            productLoading.value = false
            productError.value = true
        }
    }

    private fun getCharacter(id: Long) = viewModelScope.launch(Dispatchers.IO) {
        productLoading.postValue(true)
        repo.getProduct(id).let { response ->
            if(response.isSuccessful){
                _product.postValue(response.body())
                productLoading.postValue(false)
            }else {
                productLoading.postValue(false)
                productError.postValue(true)
                Log.i("DetailViewModel","Error!")
            }
        }
    }

    fun addToCart(cartRequest: CartRequest) = viewModelScope.launch {
        productLoading.postValue(true)
        repo.addToCart(cartRequest).let { response ->
            if (response.isSuccessful){
                println(response.body())
                cartAddingIsSucces.postValue(true)
                productLoading.postValue(false)
            }else {
                cartAddingIsSucces.postValue(false)
                productLoading.postValue(false)
                productError.postValue(true)
                Log.i("DetailViewModel","Error!")
            }
        }
    }
    //Detay sayfası apiden değil de roomdan çekilmek istenirse.Aşağıdaki fonksiyon kullanılabilir.

    /*private fun getCharacterFromRoom(id:Int) = viewModelScope.launch(Dispatchers.IO) {
        val char = repo.getCharacterFromRoom(id)
        _char.postValue(char)
        charLoading.postValue(false)
    }
     */

}