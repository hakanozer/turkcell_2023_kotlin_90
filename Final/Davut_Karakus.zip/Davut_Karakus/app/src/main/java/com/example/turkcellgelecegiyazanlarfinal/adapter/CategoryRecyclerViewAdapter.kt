package com.example.turkcellgelecegiyazanlarfinal.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.turkcellgelecegiyazanlarfinal.R
import com.example.turkcellgelecegiyazanlarfinal.databinding.CategoryRecyclerRowBinding

class CategoryRecyclerViewAdapter(private var categoryList:ArrayList<String>, private val listener: OnItemClickListener) :  RecyclerView.Adapter<CategoryRecyclerViewAdapter.RvHolder>(),
    ItemClickListener {
    class RvHolder(var view: CategoryRecyclerRowBinding) : RecyclerView.ViewHolder(view.root) {
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RvHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = DataBindingUtil.inflate<CategoryRecyclerRowBinding>(inflater, R.layout.category_recycler_row,parent,false)
        return RvHolder(view)
    }

    override fun getItemCount(): Int {
        return categoryList.size
    }

    override fun onBindViewHolder(holder: RvHolder, position: Int) {
        holder.view.category = categoryList[position]
        holder.view.listener = this
        holder.view.root.tag = holder.view
    }

    fun updateCategoryList(newCategoryList:List<String>){
        categoryList.clear()
        categoryList.addAll(newCategoryList)
        notifyDataSetChanged()
    }

    interface OnItemClickListener {
        fun onItemClickListenerCategory(v: View)
    }

    override fun onItemClicked(v: View) {
        listener.onItemClickListenerCategory(v)
    }

}