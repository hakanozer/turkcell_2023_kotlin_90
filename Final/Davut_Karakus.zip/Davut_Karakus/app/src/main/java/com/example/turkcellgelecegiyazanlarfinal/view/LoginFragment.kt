package com.example.turkcellgelecegiyazanlarfinal.view

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.turkcellgelecegiyazanlarfinal.databinding.FragmentLoginBinding
import com.example.turkcellgelecegiyazanlarfinal.model.User
import com.example.turkcellgelecegiyazanlarfinal.view.activities.MainActivity
import com.example.turkcellgelecegiyazanlarfinal.viewmodel.LoginViewModel
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class LoginFragment @Inject constructor(
) : Fragment() {
    private lateinit var binding : FragmentLoginBinding
    private lateinit var viewModel : LoginViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentLoginBinding.inflate(inflater,container,false)
        val actionBar = (requireActivity() as AppCompatActivity).supportActionBar
        actionBar?.hide()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this)[LoginViewModel::class.java]
        binding.viewModel = viewModel
        binding.lifecycleOwner = this
        binding.loginButton.setOnClickListener {
            val username = binding.usernameEditText.text.toString()
            val password = binding.passwordEditText.text.toString()
            if(username.isEmpty() && password.isEmpty()){
                binding.usernameEditText.error = "Please fill in the username field"
                binding.passwordEditText.error = "Please fill in the password field"
            }else if(username.isEmpty()){
                binding.usernameEditText.error = "Please fill in the username field"
            }else if(password.isEmpty()){
                binding.passwordEditText.error = "Please fill in the password field"
            }else {
                viewModel.loginUser(User(username,password))
            }
        }
        observeData()
    }

    private fun observeData() {
        viewModel.loginIsSucces.observe(viewLifecycleOwner,Observer {
            if (it) {
                navigateFeedFragment()
            }
        })
        viewModel.error.observe(viewLifecycleOwner,Observer {
            Toast.makeText(context,"Username or Password Fail",Toast.LENGTH_LONG).show()
        })
    }

    private fun navigateFeedFragment() {
        val intent = Intent(requireContext(), MainActivity::class.java)
        startActivity(intent)
        requireActivity().finish()
    }

}