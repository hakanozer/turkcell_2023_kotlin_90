package com.example.turkcellgelecegiyazanlarfinal.model

import com.google.gson.annotations.SerializedName

data class ProductResponse(
    @SerializedName("id")
    val id: Long,
    @SerializedName("title")
    val title: String,
    @SerializedName("price")
    val price: Long,
    @SerializedName("quantity")
    val quantity: Long,
    @SerializedName("total")
    val total: Long,
    @SerializedName("discountPercentage")
    val discountPercentage: Double,
    @SerializedName("discountedPrice")
    val discountedPrice: Long,
    @SerializedName("thumbnail")
    val thumbnail: String
)