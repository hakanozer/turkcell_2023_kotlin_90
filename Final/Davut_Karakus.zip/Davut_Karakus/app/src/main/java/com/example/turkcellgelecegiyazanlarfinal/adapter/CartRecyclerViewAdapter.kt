package com.example.turkcellgelecegiyazanlarfinal.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.turkcellgelecegiyazanlarfinal.R
import com.example.turkcellgelecegiyazanlarfinal.databinding.CartRecyclerRowBinding
import com.example.turkcellgelecegiyazanlarfinal.model.ProductResponse

class CartRecyclerViewAdapter(private var productList:ArrayList<ProductResponse>) :  RecyclerView.Adapter<CartRecyclerViewAdapter.RvHolder>(){
    class RvHolder(var view: CartRecyclerRowBinding) : RecyclerView.ViewHolder(view.root) {
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RvHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = DataBindingUtil.inflate<CartRecyclerRowBinding>(inflater, R.layout.cart_recycler_row,parent,false)
        return RvHolder(view)
    }

    override fun getItemCount(): Int {
        return productList.size
    }

    override fun onBindViewHolder(holder: RvHolder, position: Int) {
        holder.view.product = productList[position]
        holder.view.root.tag = holder.view
    }

    fun updateProductList(newProductList: List<ProductResponse>){
        productList.clear()
        productList.addAll(newProductList)
        notifyDataSetChanged()
    }

}