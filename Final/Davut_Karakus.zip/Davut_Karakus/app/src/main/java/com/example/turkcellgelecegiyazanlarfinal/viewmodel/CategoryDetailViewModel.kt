package com.example.turkcellgelecegiyazanlarfinal.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.turkcellgelecegiyazanlarfinal.model.Product
import com.example.turkcellgelecegiyazanlarfinal.repo.ProductsRepository
import com.example.turkcellgelecegiyazanlarfinal.util.isWifiEnabled
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CategoryDetailViewModel @Inject constructor(private val repo: ProductsRepository) : ViewModel() {
    private val _products = MutableLiveData<List<Product>>()
    val productsError = MutableLiveData<Boolean>()
    val productsLoading = MutableLiveData<Boolean>()
    val products: LiveData<List<Product>>
        get() = _products

    fun getDataFromApi(category:String,context: Context) = viewModelScope.launch(Dispatchers.IO ){
        productsLoading.postValue(true)
        productsError.postValue(false)
        if(isWifiEnabled(context)){
            repo.getProductsWithCategory(category).let {response->
                if(response.isSuccessful){
                    _products.postValue(response.body()?.products ?: listOf())
                    productsLoading.postValue(false)
                }else{
                    productsLoading.postValue(false)
                    productsError.postValue(true)
                    Log.i("CategoryDetailViewModel","Error!")
                }
            }
        }else {
            delay(1000)
            productsLoading.postValue(false)
            productsError.postValue(true)
            Log.i("CategoryDetailViewModel","Internet Connection Problem!")
        }
    }

}