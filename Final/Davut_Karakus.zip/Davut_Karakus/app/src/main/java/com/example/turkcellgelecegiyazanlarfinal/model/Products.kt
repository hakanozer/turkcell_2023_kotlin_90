package com.example.turkcellgelecegiyazanlarfinal.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

data class Products (
    @SerializedName("products")
    val products: List<Product>,
    @SerializedName("total")
    val total: Long,
    @SerializedName("skip")
    val skip: Long,
    @SerializedName("limit")
    val limit: Long
)