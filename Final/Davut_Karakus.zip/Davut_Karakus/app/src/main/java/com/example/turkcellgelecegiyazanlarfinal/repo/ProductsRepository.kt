package com.example.turkcellgelecegiyazanlarfinal.repo

import com.example.turkcellgelecegiyazanlarfinal.model.CartRequest
import com.example.turkcellgelecegiyazanlarfinal.model.Product
import com.example.turkcellgelecegiyazanlarfinal.model.UpdateProfile
import com.example.turkcellgelecegiyazanlarfinal.model.User
import com.example.turkcellgelecegiyazanlarfinal.service.ApiService
import com.example.turkcellgelecegiyazanlarfinal.service.ProductsDao
import javax.inject.Inject

class ProductsRepository @Inject constructor(private val api: ApiService, private val dao:ProductsDao){
    suspend fun loginUser(user:User) =  api.login(user)
    suspend fun getAllProducts() = api.getAllData()
    suspend fun getProduct(id:Long) = api.getData(id)
    suspend fun searchProduct(query:String) = api.searchProduct(query)
    suspend fun getAllProductsDao() = dao.getAllProducts()
    suspend fun deleteAllProductsDao() = dao.deleteAllProducts()
    suspend fun insertProductsDao(vararg products:Product) = dao.insertAll(*products)
    suspend fun addToCart(cartRequest: CartRequest) = api.addToCart(cartRequest)
    suspend fun getCategories() = api.getCategories()
    suspend fun getProductsWithCategory(category: String) = api.getProductsWithCategory(category)
    suspend fun getProductsInCarts(id:Long) = api.getProductsInCart(id)
    suspend fun getProfileInfo(id:Long) = api.getProfileInfo(id)
    suspend fun updateProfile(id:Long,profileModel:UpdateProfile) = api.updateProfile(id,profileModel)
    // Detay sayfası roomdan çekilmek istenirse aşağıdaki suspend fun kullanılabilir.
    suspend fun getProductFromRoom(charId:Int) = dao.getProduct(charId)
}