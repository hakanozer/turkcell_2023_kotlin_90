package com.example.turkcellgelecegiyazanlarfinal.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.GridLayoutManager
import com.example.turkcellgelecegiyazanlarfinal.adapter.MainRecyclerViewAdapter
import com.example.turkcellgelecegiyazanlarfinal.databinding.FragmentFeedBinding
import com.example.turkcellgelecegiyazanlarfinal.databinding.RecyclerRowBinding
import com.example.turkcellgelecegiyazanlarfinal.viewmodel.FeedViewModel
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class FeedFragment @Inject constructor(
)  : Fragment() , MainRecyclerViewAdapter.OnItemClickListener {
    private lateinit var binding : FragmentFeedBinding
    private lateinit var viewModel : FeedViewModel
    private val mainRecyclerViewAdapter = MainRecyclerViewAdapter(arrayListOf(),this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentFeedBinding.inflate(inflater,container,false)
        val actionBar = (requireActivity() as AppCompatActivity).supportActionBar
        actionBar?.show()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(this)[FeedViewModel::class.java]
        binding.productList.layoutManager = GridLayoutManager(context,2)
        binding.productList.adapter = mainRecyclerViewAdapter
        binding.viewModel = viewModel
        binding.lifecycleOwner = this
        observeData()

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText != null) {
                    viewModel.searchProduct(newText)
                }
                return true
            }
        })
    }

    override fun onResume() {
        (requireActivity() as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(false)
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner) {
            requireActivity().finish()
        }
        super.onResume()
    }

    private fun observeData() {
        viewModel.products.observe(viewLifecycleOwner, Observer{
            val sortedList = it.sortedBy { it.id }
            mainRecyclerViewAdapter.updateProductList(sortedList)
        })
    }

    override fun onItemClickListenerProducts(v: View) {
        val binding = v.tag as? RecyclerRowBinding ?: return
        val uuid = binding.product?.id ?: return
        val action = FeedFragmentDirections.actionFeedFragmentToDetailFragment(uuid)
        Navigation.findNavController(v).navigate(action)
    }
}