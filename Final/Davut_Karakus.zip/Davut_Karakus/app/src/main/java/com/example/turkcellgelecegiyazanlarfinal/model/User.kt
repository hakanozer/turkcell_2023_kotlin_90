package com.example.turkcellgelecegiyazanlarfinal.model

data class User(
    val username:String,
    val password:String
)