package com.example.turkcellgelecegiyazanlarfinal.di

import android.content.Context
import androidx.room.Room
import com.example.turkcellgelecegiyazanlarfinal.service.ProductsDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Singleton
    @Provides
    fun injectRoomDatabase(@ApplicationContext context: Context) = Room.databaseBuilder(
        context, ProductsDatabase::class.java,"ProductDB"
    ).build()

    @Singleton
    @Provides
    fun injectDao(database: ProductsDatabase) = database.productsDao()
}