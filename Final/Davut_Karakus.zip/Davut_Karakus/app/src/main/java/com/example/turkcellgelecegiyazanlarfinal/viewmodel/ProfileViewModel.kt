package com.example.turkcellgelecegiyazanlarfinal.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.turkcellgelecegiyazanlarfinal.model.Profile
import com.example.turkcellgelecegiyazanlarfinal.model.UpdateProfile
import com.example.turkcellgelecegiyazanlarfinal.repo.ProductsRepository
import com.example.turkcellgelecegiyazanlarfinal.util.isWifiEnabled
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProfileViewModel@Inject constructor(private val repo: ProductsRepository) : ViewModel() {
    val _profile = MutableLiveData<Profile>()
    val profileLoading = MutableLiveData<Boolean>()
    val profileError = MutableLiveData<Boolean>()
    val isSuccess = MutableLiveData<Boolean>()
    val profile: LiveData<Profile>
        get() = _profile

    fun getDataFromApi(id:Long,context: Context) = viewModelScope.launch(Dispatchers.IO ) {
        profileLoading.postValue(true)
        profileError.postValue(false)
        if(isWifiEnabled(context)){
            repo.getProfileInfo(id).let {response->
                if(response.isSuccessful){
                    _profile.postValue(response.body())
                    profileLoading.postValue(false)
                }else{
                    profileLoading.postValue(false)
                    profileError.postValue(true)
                    Log.i("ProfileViewModel","Error!")
                }
            }
        }else {
            delay(1000)
            profileLoading.postValue(false)
            profileError.postValue(true)
            Log.i("ProfileViewModel","Internet Connection Problem!")
        }
    }
    fun updateProfile(id:Long,profileModel:UpdateProfile,context: Context) = viewModelScope.launch(Dispatchers.IO ) {
        profileLoading.postValue(true)
        profileError.postValue(false)
        if(isWifiEnabled(context)){
            repo.updateProfile(id,profileModel).let {response->
                if(response.isSuccessful){
                    isSuccess.postValue(true)
                    profileLoading.postValue(false)
                }else{
                    profileLoading.postValue(false)
                    profileError.postValue(true)
                    Log.i("ProfileViewModel","Error!")
                }
            }
        }else {
            delay(1000)
            profileLoading.postValue(false)
            profileError.postValue(true)
            Log.i("ProfileViewModel","Internet Connection Problem!")
        }
    }
}