$(document).ready(() => {
    //alert("Document Ready Success")
    console.log("Document Ready Success")

    $('#navCenter').fadeIn(1000)

    $('input').click(function(evt) {
        $(this).fadeOut(100)
        $(this).fadeIn(200)
    })

    const url = 'https://dummyjson.com/products'
    // Ajax
    $.ajax({
        url: url,
        method: 'GET',
        success: function(data) {
            //console.log(data)
            parseArr(data.products)
        },
        error: function(err) {
            console.log(err)
        }
    })

})

function parseArr(arr) {
    var items = ''
    for (let i = 0; i < arr.length; i++) {
        const item = arr[i];
        const img = '<img class="imgThumb" src="'+item.thumbnail+'" />'
        items += '<div class="productLi">'+img+' - '+item.title+' - '+ item.price +'</div>'
    }
    $('#products').html(items)
}