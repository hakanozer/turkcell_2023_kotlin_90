package com.works.vize_2.models

data class UserSend(
    val username: String,
    val password: String
)
