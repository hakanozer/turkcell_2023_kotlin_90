package com.works.vize_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class LikedProduct : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_liked_product)
    }
}