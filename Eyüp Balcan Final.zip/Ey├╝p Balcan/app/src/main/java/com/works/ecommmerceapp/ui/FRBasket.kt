package com.works.ecommmerceapp.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.works.ecommmerceapp.R
import com.works.ecommmerceapp.databinding.FragmentBasketBinding
import com.works.ecommmerceapp.helper.SharedPrefsHelper
import com.works.ecommmerceapp.helper.Utils.toastGoster
import com.works.ecommmerceapp.model.basket.BasketModel
import com.works.ecommmerceapp.model.basket.BasketProductModel
import com.works.ecommmerceapp.model.basket.BasketResponseModel
import com.works.ecommmerceapp.model.product.ProductDetail
import com.works.ecommmerceapp.network.ApiClient
import com.works.ecommmerceapp.network.ProductService
import com.works.ecommmerceapp.ui.adapter.ProductAdapter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FRBasket : Fragment() {

    private lateinit var adapter: ProductAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var totalPriceTxtView: TextView
    private lateinit var postBtn: Button
    private lateinit var sharedManager: SharedPrefsHelper
    private lateinit var dummyService: ProductService
    private var _binding: FragmentBasketBinding? = null
    private val binding get() = _binding!!

    var totalPrice: Double = 0.0

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBasketBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setUiTool()
        dummyService = ApiClient.getClient().create(ProductService::class.java)
        getBasketProductList()
        binding.postBtn.setOnClickListener { postCard() }
    }

    private fun setUiTool() {
        recyclerView = binding.recyclerView
        totalPriceTxtView = binding.totalPrice
        postBtn = binding.postBtn
    }

    @SuppressLint("SetTextI18n")
    fun getBasketProductList() {
        sharedManager = SharedPrefsHelper(requireContext())
        val productList = sharedManager.getProductsFromShared()
        setAdapterRecyclerView(productList)
        for (product in productList) {
            totalPrice += product.price
        }
        totalPriceTxtView.text = "$totalPrice $"
    }

    private fun setAdapterRecyclerView(products: MutableList<ProductDetail>) {
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        adapter = ProductAdapter(
            productList = products,
            isDeleteIcon = true,
            onItemDeleteClick = {
                sharedManager.removeProductFromShared(it)
                adapter.removeProduct(it)
            }
        )
        recyclerView.adapter = adapter
    }

    private fun postCard() {
        val product = adapter.getProduct()
        val postProductList = mutableListOf<BasketProductModel>()
        product.forEach {
            val basketProduct = BasketProductModel(it.id, it.stock)
            postProductList.add(basketProduct)
        }
        val basketModel = BasketModel(1, postProductList)
        dummyService.addtoCart(basketModel).enqueue(object : Callback<BasketResponseModel> {
            override fun onResponse(
                call: Call<BasketResponseModel>,
                response: Response<BasketResponseModel>
            ) {
                val statusCode = response.code()
                if (statusCode == 200) {
                    Toast.makeText(
                        requireActivity(),
                        "Siparişiniz Başarıyla Verildi..",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    toastGoster(requireContext(), "Hata lütfen daha sonra tekrar deneyiniz..")
                }
            }

            override fun onFailure(call: Call<BasketResponseModel>, t: Throwable) {
                t.printStackTrace()
                toastGoster(requireContext(), getString(R.string.str_hata))
            }
        })
    }
}
