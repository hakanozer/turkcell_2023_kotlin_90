package com.works.ecommmerceapp.ui.category

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.works.ecommmerceapp.R
import com.works.ecommmerceapp.databinding.FragmentCategoriesBinding
import com.works.ecommmerceapp.helper.FragmentHelper
import com.works.ecommmerceapp.ui.adapter.CategoryAdapter
import com.works.ecommmerceapp.network.ApiClient
import com.works.ecommmerceapp.network.ProductService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FRCategories : Fragment() {
    private lateinit var categoryList : List<String>
    private lateinit var adapter: CategoryAdapter
    private lateinit var recyclerView: RecyclerView
    private var _binding: FragmentCategoriesBinding? = null
    private val binding get() = _binding!!
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCategoriesBinding.inflate(inflater, container, false)
        return binding.root
    }



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        adapter = CategoryAdapter(emptyList())
        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter
        fetchCategoryList()

        adapter.onItemClik = {category ->
            val bundle = Bundle()
            bundle.putString("category_name", category.lowercase())
            val fragmentHelper = FragmentHelper(parentFragmentManager,bundle)
            fragmentHelper.replaceFragment(FRCategoriesFilter())

        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun fetchCategoryList(){
        val dummyService = ApiClient.getClient().create(ProductService::class.java)
        val call: Call<List<String>> = dummyService.getCategories()
        call.enqueue(object : Callback<List<String>>{
            override fun onResponse(call: Call<List<String>>, response: Response<List<String>>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        adapter.setCategories(it.map{word -> word.replaceFirstChar { it.toUpperCase() }})
                        categoryList = it
                    }
                } else {
                    Log.e("Hata", "onResponse: Veri çekilemedi")
                }
            }

            override fun onFailure(call: Call<List<String>>, t: Throwable) {
                Log.e("Hata", "onFailure: Veri çekilemedi", t)
            }

        })
        }

    }

