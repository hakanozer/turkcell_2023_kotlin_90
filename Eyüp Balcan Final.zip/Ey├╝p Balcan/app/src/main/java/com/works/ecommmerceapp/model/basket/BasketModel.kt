package com.works.ecommmerceapp.model.basket

data class BasketModel(val userId: Long = 1, val products: List<BasketProductModel>)


