package com.works.ecommmerceapp.model.cart

import com.works.ecommmerceapp.model.product.ProductDetail

data class CartDetail(
    val discountedTotal: Int,
    val id: Int,
    val products: List<ProductDetail>,
    val total: Int,
    val totalProducts: Int,
    val totalQuantity: Int,
    val userId: Int
)