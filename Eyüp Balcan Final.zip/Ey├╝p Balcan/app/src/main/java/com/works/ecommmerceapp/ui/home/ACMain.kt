package com.works.ecommmerceapp.ui.home

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.messaging.FirebaseMessaging
import com.works.ecommmerceapp.R
import com.works.ecommmerceapp.databinding.ActivityMainBinding
import com.works.ecommmerceapp.helper.FragmentHelper
import com.works.ecommmerceapp.helper.SharedPrefsHelper
import com.works.ecommmerceapp.ui.FRLogin
import com.works.ecommmerceapp.ui.FROrder
import com.works.ecommmerceapp.ui.FRBasket
import com.works.ecommmerceapp.ui.FRSettings
import com.works.ecommmerceapp.ui.category.FRCategories

class ACMain : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val navView : BottomNavigationView = binding.bottomNavigationView
        val fragmentHelper = FragmentHelper(supportFragmentManager,)

        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) {
                return@OnCompleteListener
            }
        })

        if (isLoggedIn()) {
            navView.visibility = View.VISIBLE
           fragmentHelper.replaceFragment(FRHome())
        } else {
            navView.visibility = View.GONE
            fragmentHelper.replaceFragment(FRLogin())
        }
        binding.bottomNavigationView.setOnItemSelectedListener {
            when(it.itemId){
                R.id.homeFragment -> fragmentHelper.replaceFragment(FRHome())
                R.id.sepetFragment -> fragmentHelper.replaceFragment(FRBasket())
                R.id.categoriesFragment -> fragmentHelper.replaceFragment(FRCategories())
                R.id.ordersFragment -> fragmentHelper.replaceFragment(FROrder())
                R.id.settingsFragment -> fragmentHelper.replaceFragment(FRSettings())
                else ->{}
            }
            true
        }


    }

    private fun isLoggedIn(): Boolean {
        val sharedHelper = SharedPrefsHelper(this@ACMain)
        return sharedHelper.isJwtUserHave()
    }

    fun showBottomNavigation(){
       binding.bottomNavigationView.visibility = View.VISIBLE
    }

}
