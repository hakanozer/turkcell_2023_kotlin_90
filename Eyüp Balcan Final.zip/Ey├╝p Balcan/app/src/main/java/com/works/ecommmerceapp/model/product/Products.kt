package com.works.ecommmerceapp.model.product

data class Products(
    val products: List<ProductDetail>,
    val total: Long,
    val skip: Long,
    val limit: Long
)




