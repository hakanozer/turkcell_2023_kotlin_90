package com.works.ecommmerceapp.helper

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import com.works.ecommmerceapp.R

class FragmentHelper(private val fragmentManager: FragmentManager, val bundle: Bundle? = null) {

     fun replaceFragment( fragment : Fragment) {
        val transaction: FragmentTransaction = fragmentManager.beginTransaction()
        fragment.arguments= bundle
        transaction.replace(R.id.frame_layout, fragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }
}
