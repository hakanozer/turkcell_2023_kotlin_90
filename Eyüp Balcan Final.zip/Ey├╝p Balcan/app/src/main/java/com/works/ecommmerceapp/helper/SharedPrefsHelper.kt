package com.works.ecommmerceapp.helper

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.works.ecommmerceapp.model.product.ProductDetail
import com.works.ecommmerceapp.model.user.UserModel


class SharedPrefsHelper(private val context: Context?) {

    private val sharedPreferences: SharedPreferences by lazy {
        context!!.getSharedPreferences("Basket", Context.MODE_PRIVATE)
    }
    private val gson: Gson by lazy { Gson() }

    fun addProductToShared(product: ProductDetail) {
        val existingProducts = getProductsFromShared()
        existingProducts.add(product)
        saveProductsToShared(existingProducts)
    }

    fun getProductsFromShared(): MutableList<ProductDetail> {
        val productListJson = sharedPreferences.getString("productList", null)
        return if (productListJson != null) {
            val type = object : TypeToken<MutableList<ProductDetail>>() {}.type
            gson.fromJson(productListJson, type)
        } else {
            mutableListOf()
        }
    }

    private fun saveProductsToShared(products: List<ProductDetail>) {
        val productListJson = gson.toJson(products)
        sharedPreferences.edit().putString("productList", productListJson).apply()
    }

    fun removeProductFromShared(product: ProductDetail) {
        val existingProducts = getProductsFromShared()
        existingProducts.remove(product)
        saveProductsToShared(existingProducts)
    }

    fun addJwtUser(jwtUser: UserModel) {
        val jwtUserString = Gson().toJson(jwtUser)
        sharedPreferences.edit().putString("userData", jwtUserString).apply()
    }

    fun getUserDataModel(): UserModel? {
        val userModelString = sharedPreferences.getString("userData", "")
        if (!userModelString.isNullOrEmpty()) {
            return gson.fromJson(userModelString, UserModel::class.java)
        }
        return null
    }

    fun isJwtUserHave(): Boolean {
        return getUserDataModel() != null
    }
}
