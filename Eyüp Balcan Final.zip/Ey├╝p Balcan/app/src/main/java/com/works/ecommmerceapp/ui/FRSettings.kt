package com.works.ecommmerceapp.ui

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.works.ecommmerceapp.databinding.FragmentSettingsBinding
import com.works.ecommmerceapp.helper.SharedPrefsHelper
import com.works.ecommmerceapp.helper.Utils.toastGoster
import com.works.ecommmerceapp.model.user.UpdateUserModel
import com.works.ecommmerceapp.model.user.UserModel
import com.works.ecommmerceapp.network.ApiClient
import com.works.ecommmerceapp.network.ProductService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class FRSettings : Fragment() {
    private lateinit var sharedHelper: SharedPrefsHelper
    private lateinit var userModel: UserModel
    private lateinit var dummyService: ProductService
    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        dummyService = ApiClient.getClient().create(ProductService::class.java)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sharedHelper = SharedPrefsHelper(requireContext())
        sharedHelper.getUserDataModel()?.let {
            userModel = it
            fetchUserDataFromApi(it.id.toString())
        }
        binding.etUpdateButton.setOnClickListener {
            updateUserInformation()
        }
    }

    private fun updateUserInformation() {
        with(binding) {
            val updatedUserModel = UpdateUserModel(
                etUserName.text.toString(),
                etEmail.text.toString(),
                etFirstName.text.toString()
            )
            val call: Call<UserModel> = dummyService.updateUser(
                userModel.id.toString(),
                updatedUserModel
            )

            call.enqueue(object : Callback<UserModel> {
                override fun onResponse(call: Call<UserModel>, response: Response<UserModel>) {
                    if (response.isSuccessful) {
                        val updatedUser = response.body()
                        if (updatedUser != null) {
                            toastGoster(requireContext(), "Bilgileriniz güncellendi")
                            etUpdateButton.isEnabled = false
                        }
                    } else {
                        Log.e("Hata", "onResponse: Kullanıcı bilgileri güncellenemedi")
                    }
                }

                override fun onFailure(call: Call<UserModel>, t: Throwable) {
                    Log.e("Hata", "onFailure: Kullanıcı bilgileri güncellenemedi", t)
                }
            })
        }
    }

    private fun fetchUserDataFromApi(userId: String) {
        val call: Call<UserModel> = dummyService.userData(userId.toInt())
        call.enqueue(object : Callback<UserModel> {
            override fun onResponse(call: Call<UserModel>, response: Response<UserModel>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        binding.etUserName.setText(it.username)
                        binding.etEmail.setText(it.email)
                        binding.etFirstName.setText(it.firstName)
                    }
                } else {
                    Log.e("Hata", "onResponse: Veri çekilemedi")
                }
            }

            override fun onFailure(call: Call<UserModel>, t: Throwable) {
                Log.e("Hata", "onResponse: Veri çekilemedi")
            }
        })
    }
}
