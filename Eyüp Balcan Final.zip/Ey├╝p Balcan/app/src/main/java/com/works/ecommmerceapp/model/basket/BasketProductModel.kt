package com.works.ecommmerceapp.model.basket

data class BasketProductModel(val id: Long, val quantity: Long)