package com.works.ecommmerceapp.ui.home

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.works.ecommmerceapp.R
import com.works.ecommmerceapp.helper.FragmentHelper
import com.works.ecommmerceapp.model.product.ProductDetail
import com.works.ecommmerceapp.model.product.Products
import com.works.ecommmerceapp.network.ApiClient
import com.works.ecommmerceapp.network.ProductService
import com.works.ecommmerceapp.ui.FRProductDetail
import com.works.ecommmerceapp.ui.adapter.ProductAdapter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FRHome : Fragment() {
    private lateinit var adapter: ProductAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var searchView: SearchView
    private lateinit var view: View
    private lateinit var dummyService: ProductService
    private var productList: List<ProductDetail> = emptyList()
    private var searchedProductList: List<ProductDetail> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        view = inflater.inflate(R.layout.fragment_home, container, false)
        searchView = view.findViewById(R.id.search_view)
        recyclerView = view.findViewById(R.id.recyclerView)
        dummyService = ApiClient.getClient().create(ProductService::class.java)
        fetchDataFromApi()
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(searchText: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(searchText: String?): Boolean {
                searhProduct(searchText.toString())
                return false
            }
        })

        return view
    }

    private fun fetchDataFromApi() {
        val call: Call<Products> = dummyService.allProducts()
        call.enqueue(object : Callback<Products> {
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        productList = it.products
                        searchedProductList = productList
                        adapter = ProductAdapter(productList.toMutableList(), onItemClik = {
                            val bundle = Bundle()
                            bundle.putSerializable("product_json", it)
                            val fragmentHelper = FragmentHelper(parentFragmentManager, bundle)
                            fragmentHelper.replaceFragment(FRProductDetail())
                        })
                        recyclerView.layoutManager = GridLayoutManager(requireContext(), 2)
                        recyclerView.adapter = adapter
                    }
                } else {
                    Log.e("Hata", "onResponse: Veri çekilemedi")
                }
            }


            override fun onFailure(call: Call<Products>, t: Throwable) {
                Log.e("Hata", "onFailure: Veri çekilemedi", t)
            }
        })
    }

    private fun searhProduct(productName: String) {
        val call: Call<Products> = dummyService.searchProduct(productName)
        call.enqueue(object : Callback<Products> {
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        productList = it.products
                        searchedProductList = productList
                        adapter = ProductAdapter(productList.toMutableList(), onItemClik = {
                            val bundle = Bundle()
                            bundle.putSerializable("product_json", it)
                            val fragmentHelper = FragmentHelper(parentFragmentManager, bundle)
                            fragmentHelper.replaceFragment(FRProductDetail())
                        })
                        recyclerView.layoutManager = GridLayoutManager(requireContext(), 2)
                        recyclerView.adapter = adapter
                    }
                } else {
                    Log.e("Hata", "onResponse: Veri çekilemedi")
                }
            }


            override fun onFailure(call: Call<Products>, t: Throwable) {
                Log.e("Hata", "onFailure: Veri çekilemedi", t)
            }
        })
    }


}



