package com.works.ecommmerceapp.ui.category

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.works.ecommmerceapp.R
import com.works.ecommmerceapp.helper.FragmentHelper
import com.works.ecommmerceapp.model.product.ProductDetail
import com.works.ecommmerceapp.model.product.Products
import com.works.ecommmerceapp.network.ApiClient
import com.works.ecommmerceapp.network.ProductService
import com.works.ecommmerceapp.ui.FRProductDetail
import com.works.ecommmerceapp.ui.adapter.ProductAdapter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FRCategoriesFilter : Fragment() {
    private lateinit var adapter: ProductAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var productList: List<ProductDetail>
    private lateinit var searchedProductList: List<ProductDetail>
    private lateinit var searchView: SearchView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_categories_filter, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        searchView = view.findViewById(R.id.search_view)
        recyclerView = view.findViewById(R.id.recyclerView)

        arguments?.let {
            val categoryName = it.getString("category_name")
            fetchDataFromApi(categoryName)

            searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(searchText: String?): Boolean {
                    return false
                }

                override fun onQueryTextChange(searchText: String?): Boolean {
                    searchedProductList =
                        productList.filter { it.title?.lowercase()?.contains(searchText.orEmpty()) == true }
                    adapter = ProductAdapter(searchedProductList.toMutableList(), onItemClik = {})
                    recyclerView.adapter = adapter
                    return false
                }
            })
        }
    }

    private fun fetchDataFromApi(categoryName: String?) {
        val dummyService = ApiClient.getClient().create(ProductService::class.java)
        val call: Call<Products> = dummyService.getProductByCategory(categoryName.orEmpty())
        call.enqueue(object : Callback<Products> {
            override fun onResponse(call: Call<Products>, response: Response<Products>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        val list = it.products.toMutableList()
                        adapter = ProductAdapter(list, onItemClik = {
                            val bundle = Bundle()
                            bundle.putSerializable("product_json", it)
                            val fragmentHelper = FragmentHelper(parentFragmentManager, bundle)
                            fragmentHelper.replaceFragment(FRProductDetail())
                        })
                        recyclerView.layoutManager = GridLayoutManager(requireContext(), 2)
                        recyclerView.adapter = adapter
                        productList = it.products
                    }
                } else {
                    Log.e("Hata", "onResponse: Veri çekilemedi")
                }
            }

            override fun onFailure(call: Call<Products>, t: Throwable) {
                Log.e("Hata", "onFailure: Veri çekilemedi", t)
            }
        })
    }
}
