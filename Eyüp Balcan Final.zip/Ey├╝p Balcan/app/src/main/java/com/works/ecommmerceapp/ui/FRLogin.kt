package com.works.ecommmerceapp.ui

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.works.ecommmerceapp.R
import com.works.ecommmerceapp.databinding.FragmentLoginBinding
import com.works.ecommmerceapp.model.LoginModel
import com.works.ecommmerceapp.helper.FragmentHelper
import com.works.ecommmerceapp.helper.SharedPrefsHelper
import com.works.ecommmerceapp.helper.Utils.toastGoster
import com.works.ecommmerceapp.network.ProductService
import com.works.ecommmerceapp.model.user.UserModel
import com.works.ecommmerceapp.network.ApiClient
import com.works.ecommmerceapp.ui.home.ACMain
import com.works.ecommmerceapp.ui.home.FRHome
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FRLogin : Fragment() {

    private lateinit var dummyService: ProductService
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var sharedEditor: SharedPreferences.Editor
    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container,false)
        dummyService = ApiClient.getClient().create(ProductService::class.java)
        sharedPreferences = requireActivity().getSharedPreferences("userdata", AppCompatActivity.MODE_PRIVATE)
        sharedEditor = sharedPreferences.edit()

        binding.btnLogin.setOnClickListener {
            val username = _binding!!.etUserName.text.toString()
            val password = _binding!!.etPassword.text.toString()

            if (username.isNotEmpty() && password.isNotEmpty()) {
                val userSend = LoginModel(username, password)
                dummyService.login(userSend).enqueue(object : Callback<UserModel> {
                    override fun onResponse(call: Call<UserModel>, response: Response<UserModel>) {
                        if (response.isSuccessful) {
                            val userModel = response.body()
                            //kminchelle
                            //0lelplR
                           userModel.let {
                               SharedPrefsHelper(requireContext()).addJwtUser(userModel!!)
                               FragmentHelper(requireActivity().supportFragmentManager).replaceFragment(
                                   FRHome()
                               )
                               val activty = requireActivity()
                               if( activty is ACMain) {
                                   activty.showBottomNavigation()
                               }
                           }
                        } else {
                            val errorMessage = when (response.code()) {
                                401 -> "Kullanıcı adı veya şifre hatalı."
                                403 -> "Yetkisiz erişim."
                                else -> "Bir hata oluştu. Lütfen tekrar deneyin."
                            }
                            toastGoster(requireContext(), errorMessage)
                        }
                    }

                    override fun onFailure(call: Call<UserModel>, t: Throwable) {

                        toastGoster(requireContext(), getString(R.string.str_hata))
                    }
                })
            } else {
                toastGoster(requireContext(), getString(R.string.str_kullanici_adi_sifre_bos_olamaz))
            }
        }

        return binding.root
    }
}
