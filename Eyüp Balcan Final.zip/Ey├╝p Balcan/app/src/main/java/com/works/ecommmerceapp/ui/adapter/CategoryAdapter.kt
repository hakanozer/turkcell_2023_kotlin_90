package com.works.ecommmerceapp.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.works.ecommmerceapp.R


class CategoryAdapter(private var categoryList: List<String>,var onItemClik: ((String) -> Unit)? = null ) :
    RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder>() {

    inner class CategoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(category: String) {
            itemView.findViewById<TextView>(R.id.tvCategoryName).text = category
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_category, parent, false)
        return CategoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        val category = categoryList[position]
        holder.bind(category)
        holder.itemView.setOnClickListener { onItemClik?.invoke(category) }
    }

    override fun getItemCount(): Int {
        return categoryList.size
    }

    fun setCategories(categories: List<String>) {
        categoryList = categories
        notifyDataSetChanged()
    }


}