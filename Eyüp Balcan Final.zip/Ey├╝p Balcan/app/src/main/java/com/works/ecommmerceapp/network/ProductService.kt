package com.works.ecommmerceapp.network

import com.works.ecommmerceapp.model.LoginModel
import com.works.ecommmerceapp.model.basket.BasketModel
import com.works.ecommmerceapp.model.basket.BasketResponseModel
import com.works.ecommmerceapp.model.cart.CartModel
import com.works.ecommmerceapp.model.product.Products
import com.works.ecommmerceapp.model.user.UpdateUserModel
import com.works.ecommmerceapp.model.user.UserModel
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

interface ProductService {

    @POST("auth/login")
    fun login(@Body userSend: LoginModel): Call<UserModel>

    @GET("products?limit=10")
    fun allProducts(): Call<Products>

    @GET("products/search?")
    fun searchProduct(@Query("q") productName: String): Call<Products>

    @GET("user/{userId}")
    fun userData(@Path("userId") userId: Int): Call<UserModel>

    @GET("carts/user/5")
    fun setOrder(): Call<CartModel>

    @GET("products/categories")
    fun getCategories(): Call<List<String>>

    @GET("products/category/{categoryName}")
    fun getProductByCategory(@Path("categoryName") categoryName: String): Call<Products>

    @POST("carts/add")
    fun addtoCart(@Body products: BasketModel): Call<BasketResponseModel>

    @PUT("users/{userId}")
    fun updateUser(
        @Path("userId") userId: String,
        @Body updatedUser: UpdateUserModel
    ): Call<UserModel>
}