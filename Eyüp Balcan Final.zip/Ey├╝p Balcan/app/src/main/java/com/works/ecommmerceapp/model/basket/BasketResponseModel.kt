package com.works.ecommmerceapp.model.basket

import com.works.ecommmerceapp.model.product.ProductDetail

data class BasketResponseModel(
    val id: Long,
    val products: List<ProductDetail>,
    val total: Long,
    val discountedTotal: Long,
    val userID: Long,
    val totalProducts: Long,
    val totalQuantity: Long
)