package com.works.ecommmerceapp.ui.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.works.ecommmerceapp.databinding.ItemProductsBinding
import com.works.ecommmerceapp.model.product.ProductDetail


class ProductAdapter(
    private var productList: MutableList<ProductDetail>,
    private val onItemClik: ((ProductDetail) -> Unit)? = null,
    private val isDeleteIcon: Boolean = false,
    private val onItemDeleteClick: ((ProductDetail) -> Unit)? = null,
) : RecyclerView.Adapter<ProductAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemProductsBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemProductsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val product = productList[position]
        holder.apply {
            with(binding) {
                tvProduct.text = product.title
                tvPrice.text = product.price.toString() + " $"
                if (isDeleteIcon) {
                    ivDelete.visibility = View.VISIBLE
                    ivDelete.setOnClickListener {
                        onItemDeleteClick?.invoke(product)
                    }
                } else {
                    ivDelete.visibility = View.GONE
                }

                Glide.with(itemView.context)
                    .load(product.images?.firstOrNull())
                    .into(ivProduct)
                itemView.setOnClickListener {
                    onItemClik?.invoke(product)
                }

            }
        }
    }

    override fun getItemCount(): Int {
        return productList.size
    }

    @SuppressLint("NotifyDataSetChanged")
    fun removeProduct(products: ProductDetail) {
        productList.remove(products)
        notifyDataSetChanged()
    }

    fun getProduct(): MutableList<ProductDetail> {
        return productList
    }
}

