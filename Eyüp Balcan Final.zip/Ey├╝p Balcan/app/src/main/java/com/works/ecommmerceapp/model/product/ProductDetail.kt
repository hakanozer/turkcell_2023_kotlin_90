package com.works.ecommmerceapp.model.product

import java.io.Serializable

data class ProductDetail(
    val id: Long,
    val title: String?,
    val description: String,
    val price: Long,
    val discountPercentage: Double,
    val rating: Double,
    val stock: Long,
    val brand: String,
    val category: String,
    val thumbnail: String,
    val images: List<String>?
) : Serializable