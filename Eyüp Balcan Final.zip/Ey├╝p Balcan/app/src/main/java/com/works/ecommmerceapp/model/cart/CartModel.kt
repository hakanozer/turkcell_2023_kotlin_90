package com.works.ecommmerceapp.model.cart

data class CartModel(
    val carts: List<CartDetail>,
    val limit: Int,
    val skip: Int,
    val total: Int
)

