package com.works.ecommmerceapp.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.works.ecommmerceapp.R
import com.works.ecommmerceapp.databinding.FragmentDetailBinding
import com.works.ecommmerceapp.databinding.FragmentOrderBinding
import com.works.ecommmerceapp.model.cart.CartModel
import com.works.ecommmerceapp.network.ApiClient
import com.works.ecommmerceapp.network.ProductService
import com.works.ecommmerceapp.ui.adapter.CartAdapter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class FROrder : Fragment() {
    private lateinit var adapter: CartAdapter
    private lateinit var recyclerView: RecyclerView
    private  var _binding: FragmentOrderBinding? = null
    private val binding get() = _binding


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentOrderBinding.inflate(inflater, container, false)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = CartAdapter((emptyList()))
        recyclerView = _binding!!.recyclerView
        recyclerView.layoutManager = GridLayoutManager(requireContext(), 1)
        recyclerView.adapter = adapter
        fetchCartFromApi()
    }

    private fun fetchCartFromApi() {
        val dummyService = ApiClient.getClient().create(ProductService::class.java)

        val call: Call<CartModel> = dummyService.setOrder()

        call.enqueue(object : Callback<CartModel> {
            override fun onResponse(call: Call<CartModel>, response: Response<CartModel>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        adapter.setCart(it.carts)
                    }
                }
            }

            override fun onFailure(call: Call<CartModel>, t: Throwable) {
                TODO("Not yet implemented")
            }

        })
    }


}

