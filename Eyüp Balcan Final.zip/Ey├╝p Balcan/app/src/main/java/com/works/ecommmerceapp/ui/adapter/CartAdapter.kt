package com.works.ecommmerceapp.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.works.ecommmerceapp.R
import com.works.ecommmerceapp.databinding.ItemCartBinding
import com.works.ecommmerceapp.model.cart.CartDetail

class CartAdapter(private var cartList: List<CartDetail>) :
    RecyclerView.Adapter<CartAdapter.CartHolder>() {

    inner class CartHolder(val binding: ItemCartBinding) : RecyclerView.ViewHolder(binding.root) {

    }

    fun setCart(cart: List<CartDetail>) {
        cartList = cart
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartHolder {
        val binding=ItemCartBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return CartHolder(binding)
    }

    override fun getItemCount(): Int {
        return cartList.size
    }

    override fun onBindViewHolder(holder: CartHolder, position: Int) {
        val cartDetail = cartList[position]

        holder.apply {
            with(binding){
                tvCartId.text = "Cart ID: ${cartDetail.id}"
                tvTotalPrice.text = "Total Price: ${cartDetail.total}"
                tvTotalProduct.text = "Total Products: ${cartDetail.totalProducts}"
                val productAdapter = ArrayAdapter(
                    holder.itemView.context,
                    android.R.layout.simple_list_item_1,
                    cartDetail.products.map { it.title }
                )
                lvProductList.adapter = productAdapter
            }

        }
    }
}
