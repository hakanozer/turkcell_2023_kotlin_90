package com.works.ecommmerceapp.model.user

data class UpdateUserModel(
    val username: String,
    val email: String,
    val firstName: String
)