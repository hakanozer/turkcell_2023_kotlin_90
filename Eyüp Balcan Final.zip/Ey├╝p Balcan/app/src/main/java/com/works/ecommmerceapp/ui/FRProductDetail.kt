package com.works.ecommmerceapp.ui

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.works.ecommmerceapp.R
import com.works.ecommmerceapp.databinding.FragmentDetailBinding
import com.works.ecommmerceapp.helper.SharedPrefsHelper
import com.works.ecommmerceapp.model.product.ProductDetail

class FRProductDetail : Fragment() {

    private lateinit var addToCartBtn: Button
    private var _binding: FragmentDetailBinding? = null
    private val binding get() = _binding!!
    private lateinit var product: ProductDetail

    private val sharedPreferences: SharedPreferences by lazy {
        requireContext().getSharedPreferences("Basket", Context.MODE_PRIVATE)
    }

    private val gson = Gson()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        addToCartBtn = view.findViewById(R.id.addToCartButton)
        arguments?.apply {
            product = getSerializable("product_json") as? ProductDetail ?: return
            setView(product)
        }
        val sharedPrefsHelper = SharedPrefsHelper(requireContext())
        addToCartBtn.setOnClickListener {
            sharedPrefsHelper.addProductToShared(product)
        }
    }

    private fun setView(product: ProductDetail?) {
        with(binding) {
            productName.text = product?.title
            productPrice.text = product?.price.toString()
            productStock.text = product?.stock.toString()
            productDescription.text = product?.description

            Glide.with(requireContext())
                .load(product?.thumbnail)
                .placeholder(R.drawable.ic_downloading)
                .into(productImg)
        }
    }

    fun addProductToShared(product: ProductDetail) {
        val existingProducts = getProductsFromShared()
        existingProducts.add(product)
        saveProductsToShared(existingProducts)
    }

    private fun getProductsFromShared(): MutableList<ProductDetail> {
        val productListJson = sharedPreferences.getString("productList", null)
        return if (productListJson != null) {
            val type = object : TypeToken<MutableList<ProductDetail>>() {}.type
            gson.fromJson(productListJson, type)
        } else {
            mutableListOf()
        }
    }

    private fun saveProductsToShared(products: List<ProductDetail>) {
        val productListJson = gson.toJson(products)
        sharedPreferences.edit().putString("productList", productListJson).commit()
    }

}
