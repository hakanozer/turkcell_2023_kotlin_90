package com.works.sınav.Soru2

/**
 * 2.	Kullanıcıdan 5 Haneli Bir Sayı Alıyorsunuz. Bu Sayının Rakamlarını Tersten Yazdırıyorsunuz Örnek :
 * Sayı: 14532
 *  23541
 */
fun main(args: Array<String>) {

    val a = 14545
    val sonuc = ters(a)
    println(sonuc)
}
fun ters(a:Int) : Int{
    var tersCevir:Int = 0
    var num = a

    while (num != 0){
        val basamak = num %10
        tersCevir = tersCevir * 10 + basamak
        num /= 10

    }
    return tersCevir
}