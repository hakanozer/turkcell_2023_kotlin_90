package com.works.sınav.Soru1

fun main(args: Array<String>) {
    val sayi = 4545
    val topla = basamaklarinToplami(sayi)
    println("Basamak toplamı : $topla")
}

fun basamaklarinToplami(sayi: Int): Int {

    var tempSayi = sayi
    var toplam = 0

    while (tempSayi > 0) {
        toplam += tempSayi % 10
        tempSayi /= 10
    }

    return toplam
}