package com.works.sınav.Soru6

open class Mudur: Maas() {
    override fun maasHesapla(): Double {
        val calisilanEkSaat = 10
        val mudurMaas =  10 * 0.6 * 3000
        return  mudurMaas
    }
}