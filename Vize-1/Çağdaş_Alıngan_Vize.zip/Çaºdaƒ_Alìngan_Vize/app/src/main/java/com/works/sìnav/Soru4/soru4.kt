package com.works.sınav.Soru4

/**
 * 4.	getSumOfAllPrimes adında bir method olusturun bu methodunuza parametre olarak bir n
 * sayısı gönderin method, 1'den n'e kadar (n dahil) sayılar arasından, asal sayilari bulup
 * bunların toplamını döndürecek asal sayi bulmak için static boolean isPrime(int number) şeklinde
 * ayri bir method oluşturup, getSumOfAllPrimes methodunun içinde uygun şekilde kullanın.
 */
fun main(args: Array<String>) {

    val n = 25
    val toplam = getSumOfAllPrimes(n)
    println("Asal sayıların toplamı : $toplam")

}
fun getSumOfAllPrimes(n:Int):Int {

    var toplam = 0
    for (sayi in 1..(n+1)){
        if (isPrime(sayi)){
            toplam += sayi
        }
    }
    return toplam
}
fun isPrime(num:Int): Boolean {
    if (num <=1){
        return false
    }
    for (sayi in 2 until num){
        if (num %sayi ==0){
            return false
        }
    }
return true
}
