package com.works.sınav.Soru6

open class Maas {
    open fun maasHesapla():Double {
        return 0.0
    }
}