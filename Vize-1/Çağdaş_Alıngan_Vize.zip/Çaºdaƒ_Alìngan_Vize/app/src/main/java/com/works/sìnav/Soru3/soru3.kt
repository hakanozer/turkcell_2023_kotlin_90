package com.works.sınav.Soru3

/**
 * 3.	Seri Toplam Kullanıcıdan Bir N Sayısı Alıyorsunuz. 1'den N'e Kadar Aşağıdaki Seriyi Hesaplayan Bir Uygulama Yapın
 *
 * 1 + 1/1! + 2/2! + 3/3! + 4/4! +	+ n/n!
 */
// Bu soruyu yapamadım...
fun main(args: Array<String>) {

}