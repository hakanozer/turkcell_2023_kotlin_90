package com.works.sınav.Soru6

open class Memur : Maas() {
    override fun maasHesapla(): Double {
        val calisilanEkSaat = 10
        val memurMaas =  10 * 0.3 * 1000
        return memurMaas
    }
}