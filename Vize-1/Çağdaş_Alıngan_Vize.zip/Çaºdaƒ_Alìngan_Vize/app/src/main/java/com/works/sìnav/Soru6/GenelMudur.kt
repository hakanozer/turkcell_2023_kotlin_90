package com.works.sınav.Soru6

open class GenelMudur: Maas() {
    override fun maasHesapla(): Double {
        val calisilanEkSaat = 10
        val genelMudurMaas =  10 * 0.8 * 5000
        return genelMudurMaas
    }
}