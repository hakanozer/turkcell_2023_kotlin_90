package com.works.vize1.sorular

class Soru2 {
    fun ters(sayi: Int): Int {
        if (sayi < 10000 || sayi > 99999) {
            println("Geçersiz giriş! Lütfen 4 haneli bir sayı girin.")
            return 0
        }
        var sonuc = 0

        sonuc = sayi.toString().reversed().toInt()

        println(sonuc)
        return sonuc
    }
}