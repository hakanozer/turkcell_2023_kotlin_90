package com.works.vize1.sorular

class Soru5 {
    companion object{
        fun isPrime(n1: Int): Boolean {

            var sonuc = true
            if (n1 >= 2) {
                for (i in 2 until n1) {
                    if (n1 % i == 0) {
                        sonuc = false
                        break
                    }
                }
            } else {
                sonuc = false
            }
            print(sonuc)

            return sonuc
        }
    }


}