package com.works.vize1.sorular

class Soru3 {
    fun hesaplaSeriToplam(sayi: Int): Double {
        var toplam = 0.0
        var faktoriyel = 1

        for (i in 1..sayi) {
            faktoriyel *= i
            toplam += i.toDouble() / faktoriyel
        }

        return toplam
    }
}