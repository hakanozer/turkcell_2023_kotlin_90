import com.works.vize1.sorular.Soru1
import com.works.vize1.sorular.Soru2
import com.works.vize1.sorular.Soru3
import com.works.vize1.sorular.Soru5

fun main(args: Array<String>) {
    fun soru1() {
        val soru1 = Soru1()
        print("4 haneli bir sayı giriniz: ")
        val girilenSayi = readLine()
        val sayi = girilenSayi?.toIntOrNull() ?: 0
        val basamakToplami = soru1.hesaplaBasamakToplami(sayi)
        println("Girilen sayının basamakları toplamı: $basamakToplami")
    }

    soru1()
    fun soru2(){
        val soru2 = Soru2()
        print("5 haneli bir sayı giriniz: ")
        val girilenSayi = readLine()
        val sayi = girilenSayi?.toIntOrNull() ?: 0
        val tersCevir = soru2.ters(sayi)
        println("Sayının tersi: $tersCevir")
    }

    soru2()
    fun soru3(){
        val soru3 = Soru3()
        print("5 haneli bir sayı giriniz: ")
        val girilenSayi = readLine()
        val sayi = girilenSayi?.toIntOrNull() ?: 0
        val toplam = soru3.hesaplaSeriToplam(sayi)
        println("Sayının tersi: $toplam")
    }

    soru3()
    fun soru4(){
        val soru2 = Soru2()
        print("5 haneli bir sayı giriniz: ")
        val girilenSayi = readLine()
        val sayi = girilenSayi?.toIntOrNull() ?: 0
        val tersCevir = soru2.ters(sayi)
        println("Sayının tersi: $tersCevir")
    }

    soru4()

    fun soru5(){
        val soru = Soru5.isPrime(47)
    }

    soru5()

}