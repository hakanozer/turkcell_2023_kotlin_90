package com.works.vize1.sorular

class Soru1 {
    fun hesaplaBasamakToplami(sayi: Int): Int {
        if (sayi < 1000 || sayi > 9999) {
            println("Geçersiz giriş! Lütfen 4 haneli bir sayı girin.")
            return 0
        }

        val birinciBasamak = sayi / 1000
        val ikinciBasamak = (sayi % 1000) / 100
        val ucuncuBasamak = (sayi % 100) / 10
        val dorduncuBasamak = sayi % 10

        val toplam = birinciBasamak + ikinciBasamak + ucuncuBasamak + dorduncuBasamak
        return toplam
    }
}