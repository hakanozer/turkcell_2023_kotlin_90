package com.works.vize1.sorular

class Soru4 {
    fun getSumOfAllPrimes(n: Int): Int {
        var toplam = 0
        for (i in 1..n) {
            val asal = Soru5.isPrime(i)
            if (asal) {
                toplam += i
            }
        }
        return toplam
    }
}

