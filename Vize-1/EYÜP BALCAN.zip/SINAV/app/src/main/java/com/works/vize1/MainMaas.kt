import com.works.vize1.MaasSorusu.GenelMudur
import com.works.vize1.MaasSorusu.Memur
import com.works.vize1.MaasSorusu.Mudur

fun main(args: Array<String>) {
    val memur = Memur()
    val mudur = Mudur()
    val genelMudur = GenelMudur()

    val kacSaat:Int = 5



    val genelMudurMaası = genelMudur.hesaplananMaas(kacSaat)
    val mudurMaası = mudur.hesaplananMaas(kacSaat)
    val memurMaası = memur.hesaplananMaas(kacSaat)

    println("Memur maaşı: $memurMaası TL")
    println("Müdür maaşı: $mudurMaası TL")
    println("Genel Müdür maaşı: $genelMudurMaası TL")

}