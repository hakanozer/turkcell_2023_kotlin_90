package com.works.vize1.MaasSorusu


open class Calisan  (val maas: Double){

        open fun hesaplananMaas(mesaiSaati: Int): Double {
            return maas
    }
}