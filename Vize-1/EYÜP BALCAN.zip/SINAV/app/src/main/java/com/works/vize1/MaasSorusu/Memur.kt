package com.works.vize1.MaasSorusu

class Memur: Calisan(1000.0) {
    override fun hesaplananMaas(mesaiSaati: Int): Double {
        var mesaiUcreti = 0.3
        return maas +(mesaiSaati * mesaiUcreti)
    }
}