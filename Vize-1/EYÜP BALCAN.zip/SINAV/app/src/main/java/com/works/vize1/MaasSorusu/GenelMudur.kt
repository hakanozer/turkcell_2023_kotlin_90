package com.works.vize1.MaasSorusu

class GenelMudur: Calisan(5000.0) {
    override fun hesaplananMaas(mesaiSaati: Int): Double {
        var mesaiUcreti = 0.8
        return maas +(mesaiSaati * mesaiUcreti)
    }
}