package com.works.vize1.MaasSorusu

class Mudur: Calisan(3000.0) {
    override fun hesaplananMaas(mesaiSaati: Int): Double {
        var mesaiUcreti = 0.6
        return  maas +(mesaiSaati * mesaiUcreti)
    }
}