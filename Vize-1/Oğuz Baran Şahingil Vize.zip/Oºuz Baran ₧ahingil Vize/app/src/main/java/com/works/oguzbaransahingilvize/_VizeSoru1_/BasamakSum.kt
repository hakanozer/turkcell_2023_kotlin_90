package com.works.oguzbaransahingilvize._VizeSoru1_

import java.util.Scanner

class BasamakSum {

    val girdi = Scanner(System.`in`)

    fun main (){
        try {
            println("Lütfen 4 haneli sayı değerinizi giriniz : ")
            var girilensayi = girdi.nextInt()
            val sayi = girilensayi
            var sum = 0
            while ( girilensayi > 0){
                sum += girilensayi%10
                girilensayi /= 10

            }
        println("$sayi sayınızın rakamları toplamı  :  $sum")
        }catch (ex : Exception){
            println("Lütfen 4 haneli sayı değeri giriniz !")
        }
    }





}