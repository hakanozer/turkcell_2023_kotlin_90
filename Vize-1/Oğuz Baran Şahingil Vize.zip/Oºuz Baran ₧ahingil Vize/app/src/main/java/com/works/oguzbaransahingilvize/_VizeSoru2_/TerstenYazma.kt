package com.works.oguzbaransahingilvize._VizeSoru2_

fun main(args: Array<String>) {

val sonuc = tersyazim()
    println(sonuc.main())





}