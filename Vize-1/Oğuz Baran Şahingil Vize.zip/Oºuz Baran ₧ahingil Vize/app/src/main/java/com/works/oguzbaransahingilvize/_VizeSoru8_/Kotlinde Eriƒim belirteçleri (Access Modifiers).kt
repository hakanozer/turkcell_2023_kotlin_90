package com.works.oguzbaransahingilvize._VizeSoru8_

fun main(args: Array<String>) {

    println("Kotlinde Erişim belirteçleri (Access Modifiers) nedir ? ")
    println("Kotlin'de erişim belirteçleri (erişim değiştiricileri), bir sınıf, bir özelliğin veya bir fonksiyonun ne kadar göründüğü veya erişilebilir olduğunu kontrol eden anahtar kelimelerdir. Bu belirteçler, bir yazılım projesi içinde farklı çalıştırmada nasıl izinde bulunabileceğini ve hangi poliçelere ne ölçüde erişim izni verilmesine düzenlemeye yardımcı olur. Kotlin'de dört ana erişim belirteci bulunmaktadır: 1. `public`: Bu belirteç, ilgili sınıf, özelliğin veya programın herhangi bir yerden erişilebilir olduğu ücretli gelir. Yani bu parçaların herhangi bir dağılımının erişilebilirleri.")
}