package com.works.oguzbaransahingilvize._VizeSoru7_

fun main() {
    println("Class nedir ? ")
    println("Nesnelerden oluşur. Sınıflar sayesinde yazılan programlar parçalara bölünür ve oluşturulan metodlar sınıf içerisinde yer alır ve bir sınıf defalarca kullanılabilir.")

    println("=======================")

    println("Object nedir ? ")
    println("Verileri saklayan ve veriler üzerinden işlem yapmamızı sağlar. Nesneler sınıfları oluşturmaktadır. Yazılan programda tüm veriler nesneler tarafından tutulur.")

    println("=======================")

    println("Abstrack nedir ? ")
    println("Türkçe karşılığı soyutlandırmadır. Kod tekrarını azaltmaya yarar ")

    println("=======================")

    println("İnterface nedir ? ")
    println("Normal bir class tanımlamak için kullanılır. Sınıfın hangi isimde ve hangi tipte sahip olacağını söyleyen bir yapıdır.")

}