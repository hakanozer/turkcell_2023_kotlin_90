package com.works.oguzbaransahingilvize._VizeSoru5_

import java.util.Scanner

class asalsayi {

    fun isPrime(num: Int) {
        if (num > 2){
            for (i in 2..num){
                if (num % i == 0){
                    println("False")
                    break
                } else{
                    println("True")
                    break
                }
            }
        }else{
            println("Sayınız 2'den büyük olmalıdır.")
        }
    }

}