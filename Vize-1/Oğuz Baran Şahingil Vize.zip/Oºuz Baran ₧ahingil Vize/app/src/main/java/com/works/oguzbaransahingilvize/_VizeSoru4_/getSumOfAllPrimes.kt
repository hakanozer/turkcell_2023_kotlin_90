package com.works.oguzbaransahingilvize._VizeSoru4_

class getSumOfAllPrimes {
    fun getSumOfAllPrimes(n:Int):Int{
        var temp_n:Int=n
        var result:Int=0
        while(temp_n!=0){
            val flag=isPrime(temp_n)
            if (flag==true){
                result+=temp_n
            }
            temp_n--
        }
        return result

    }
    fun isPrime(num:Int):Boolean{
        var i:Int=2
        if (num <=1){
            return false
        }
        while (i<=num/2){
            if((num%i)==0){
                return false
            }
            i++
        }
        return true
    }
}