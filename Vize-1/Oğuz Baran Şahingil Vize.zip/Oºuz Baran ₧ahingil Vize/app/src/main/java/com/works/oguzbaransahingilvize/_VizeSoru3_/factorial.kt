package com.works.oguzbaransahingilvize._VizeSoru3_

import java.util.Scanner

public class factorial {

    val girdi = Scanner(System.`in`)

    fun main (){
        println("Lütfen bir sayı değeri giriniz : ")
        val sayi = girdi.nextInt()
        val deger = sayi
        var sum = 1
        for (i in 1..sayi){
            sum *= i
        }
        println("$deger sayısının factoriali  :  $sum")
    }





}