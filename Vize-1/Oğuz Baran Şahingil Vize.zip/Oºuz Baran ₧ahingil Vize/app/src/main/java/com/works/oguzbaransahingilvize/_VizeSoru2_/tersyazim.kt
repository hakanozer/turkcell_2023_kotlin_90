package com.works.oguzbaransahingilvize._VizeSoru2_

import java.util.Scanner

class tersyazim {

    val girdi = Scanner(System.`in`)

    fun main(){
        println("Lütfen 5 haneli bir sayı giriniz : ")
        val sayi = girdi.nextInt()
        val deger = sayi
        val sayiString = sayi.toString()
        val tersString = sayiString.reversed().toInt()
        println("$deger sayınızın tersten yazılışı  :  $tersString")

    }





}