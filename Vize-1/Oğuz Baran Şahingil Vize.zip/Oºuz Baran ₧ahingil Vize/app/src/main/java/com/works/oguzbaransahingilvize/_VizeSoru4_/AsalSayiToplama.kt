package com.works.oguzbaransahingilvize._VizeSoru4_

fun main(args: Array<String>) {
    val sonuc=getSumOfAllPrimes()
    val asalsonuc =sonuc.getSumOfAllPrimes(7)
    println("Sonuç: $asalsonuc")
}