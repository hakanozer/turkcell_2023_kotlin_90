package com.works.oguzbaransahingilvize._VizeSoru1_

fun main(args: Array<String>) {

    val sonuc = BasamakSum()
    println(sonuc.main())




}