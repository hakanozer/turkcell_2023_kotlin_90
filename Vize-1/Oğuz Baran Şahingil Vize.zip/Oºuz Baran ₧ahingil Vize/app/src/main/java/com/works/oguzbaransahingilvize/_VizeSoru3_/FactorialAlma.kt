package com.works.oguzbaransahingilvize._VizeSoru3_

fun main(args: Array<String>) {

    val sonuc = factorial()
    println(sonuc.main())


}