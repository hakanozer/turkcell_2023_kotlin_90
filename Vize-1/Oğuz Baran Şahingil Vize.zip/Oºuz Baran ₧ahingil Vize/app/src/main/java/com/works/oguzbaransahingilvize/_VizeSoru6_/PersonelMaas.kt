package com.works.oguzbaransahingilvize._VizeSoru6_

fun main(args: Array<String>) {

    val sonuc = maas()
    println(sonuc.maashesaplama())


}