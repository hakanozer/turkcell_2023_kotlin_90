package com.works.oguzbaransahingilvize._VizeSoru6_

import java.util.Scanner


class maas () {
    val girdi = Scanner(System.`in`)
    val memur = 1000
    val mudur = 3000
    val genelmudur = 5000
    var mesaimemur = memur*0.3
    val mesaimudur = mudur*0.6
    val mesaigenelmudur = genelmudur*0.8

    fun maashesaplama (){
        println("1 : Memur  -  2 : Müdür  -  3 : Genel Müdür")
        val personelsecim = girdi.nextInt()
        println("Kaldığınız ek mesai saatinizi yazar mısınız ? ")
        val ekmesai = girdi.nextInt()
        if (personelsecim == 1){
            val summemur = (mesaimemur*ekmesai)+memur
            println(summemur)
        }else if (personelsecim == 2){
            val summudur = (mesaimudur*ekmesai)+mudur
            println(summudur)
        }else if (personelsecim == 3) {
            val sumgenelmudur = (mesaigenelmudur * ekmesai) + genelmudur
            println(sumgenelmudur)
        }else{
            println("Yanlış değer girdiniz.")
        }

    }



}




