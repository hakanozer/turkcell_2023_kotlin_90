package com.works.oguzbaransahingilvize._VizeSoru5_

fun main(args: Array<String>) {

val sonuc = asalsayi()
    println(sonuc.isPrime(7))



}