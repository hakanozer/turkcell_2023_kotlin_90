package com.ao.vize1.questions

object QuestionThree {
    private const val value: Int = 4
    fun calculate() {
        var result = 1.0
        for (i in 1..value) {
            result += (i.toDouble() / factorial(i))
        }
        println(result)
    }

    fun factorial(n: Int): Int {
        return if (n == 1) n else n * factorial(n - 1)
    }

}