package com.ao.vize1.questions

object  QuestionOne {
    private const val value:Int = 1234
    fun sumValues(){
        val toStringValue: String = value.toString()
        var sum = 0
        toStringValue.forEach { char ->
            sum += char.toString().toInt()
        }
        println(sum)
    }
}