package com.ao.vize1.questions

open class QuestionFour {
     open fun isPrime(n: Int): Boolean {
        if (n <= 1) {
            return false
        }
        for (i in 2..<n) {
            if (n % i == 0) {
                return false
            }
        }
        return true
    }

    companion object {
        private const val value: Int = 11
        fun getSumOfAllPrimes() {
            val instance = QuestionFour()
            val primariesList: MutableList<Int> = mutableListOf()
            for (i in 2..value) {
                if (instance.isPrime(i)) {
                    primariesList.add(i)
                }
            }
            println(primariesList.sum())
        }
    }
}