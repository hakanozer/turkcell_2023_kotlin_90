package com.ao.vize1.questions

object QuestionTwo {
    private const val value: Int = 12345
    fun reversedValues() {
        val toStringValue: String = value.toString()
        val result = toStringValue.reversed()
        println(result)
    }
}