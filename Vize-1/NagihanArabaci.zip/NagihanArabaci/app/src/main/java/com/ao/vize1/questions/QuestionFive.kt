package com.ao.vize1.questions

class QuestionFive : QuestionFour() {
    override fun isPrime(n: Int): Boolean {
        return super.isPrime(n)
    }

    companion object {
        private const val value = 11
        fun isPrimaries() {
            val instance = QuestionFive()
            println(instance.isPrime(value))
        }
    }
}