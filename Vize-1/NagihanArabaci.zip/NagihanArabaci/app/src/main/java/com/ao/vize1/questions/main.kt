package com.ao.vize1.questions

import com.ao.vize1.questions.question_six.QuestionSix


fun main() {
    QuestionOne.sumValues()
    QuestionTwo.reversedValues()
    QuestionThree.calculate()
    QuestionFour.getSumOfAllPrimes()
    QuestionFive.isPrimaries()
    QuestionSix.calculate()
}