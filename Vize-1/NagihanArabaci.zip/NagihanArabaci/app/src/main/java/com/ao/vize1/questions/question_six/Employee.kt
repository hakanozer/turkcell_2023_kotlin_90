package com.ao.vize1.questions.question_six

abstract class Employee {

    abstract var salary: Double
    abstract var additional_hours: Int
    abstract var hourly_wage: Double
    abstract fun calculateSalary(): Double

}

object QuestionSix {

    fun calculate() {
        val officialSalary: Employee = Official()
        val managerSalary: Employee = Manager()
        val generalManagerSalary: Employee = GeneralManager()

        val employeeSalary = listOf(officialSalary, managerSalary, generalManagerSalary)

        for (employee in employeeSalary) {
            /// Oluşturulan nesnelerin isimlerini almak için aşağıdaki 'name' değişkeni kullanılmıştır.
            val name: String = employee.toString().split(".").last().split("@").first()
            println("$name : ${employee.calculateSalary()}")
        }
    }
}