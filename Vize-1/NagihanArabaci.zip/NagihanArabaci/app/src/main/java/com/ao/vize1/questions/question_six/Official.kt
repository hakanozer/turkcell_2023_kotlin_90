package com.ao.vize1.questions.question_six

class Official: Employee() {

        override var salary: Double = 1000.0
        override var additional_hours: Int = 30
        override var hourly_wage: Double = 9.3

        override fun calculateSalary(): Double {
            salary += hourly_wage*0.3*additional_hours
            return salary
        }
}

