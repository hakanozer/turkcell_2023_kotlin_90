package com.example.esmasalkim_vize_1


class Soru3(sayi: Int) {
    private val girilenSayi: Int

    init {
        if (sayi != null && sayi > 0) {
            girilenSayi = sayi
        } else {
            throw IllegalArgumentException("Lütfen geçerli bir sayı giriniz.")
        }
    }

    fun sayininSeriSonucunuHesapla(): Double {
        var serininSonucu = 0.0 // Sayı ondalıklı olduğundan double tanımladım varsayılan değerini.
        var faktoriyel = 1

        for (i in 1..girilenSayi) {
            faktoriyel *= i
            serininSonucu += i.toDouble() / faktoriyel
        }
        return serininSonucu +1 // Formülde ilk başta 1 olduğu için sondan ekledim.

    }
}