package com.example.esmasalkim_vize_1



class Soru2(sayi: Int) {
    private val girilenSayi: Int

    init {
        if (sayi != null && sayi.toString().length == 5) {
            girilenSayi = sayi
        } else {
            throw IllegalArgumentException("Lütfen 5 basamaklı bir sayı giriniz. 10000 ile 99999 arasında olmadığı için işleminizi gerçekleştiremiyoruz")
        }
    }

    fun sayininTersiniBul(): Int {
        //Sayı diziye dönüştürülerek dizi tersten sıralandı ve tekrar birleştirilerek hedeflenen sayı bulundu.
        val listGirilenSayininRakamlari = girilenSayi.toString().toCharArray()
        listGirilenSayininRakamlari.reverse()
        val sayininTersi = String(listGirilenSayininRakamlari).toInt()
        return sayininTersi
    }
}