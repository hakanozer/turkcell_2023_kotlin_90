package com.example.esmasalkim_vize_1

class Soru6_Mudur(maas: Double) : Soru6_Calisan(maas) {
    val mudurEkCarpim =0.6 //Statik değişken tanımladım.Kod içerisinde rakamsal ifadelere yer vermek istemedim.
    //Ana class(Üst class) olan Soru6_Calisan sınıfından özelleştirdiğimiz ve dışarıya açtığımız personel maaş hesaplama çağrıldı.

    override fun personelinAlacagiUcretHesapla(ekSaatler: Double): Double {
        return this.maas + (ekSaatler * mudurEkCarpim)
    }
}