package com.example.esmasalkim_vize_1


class Soru4(sayi: Int) {
    private val girilenSayi: Int

    init {
        if (sayi != null && sayi > 0) {
            girilenSayi = sayi
        } else {
            throw IllegalArgumentException("Lütfen geçerli bir sayı giriniz.")
        }
    }

    fun getSumOfAllPrimes(n: Int): Int {
        var asalSayilarinToplami = 0
        for (i in 2..n) {
            if (isPrime(i)) {
                asalSayilarinToplami += i
            }
        }
        return asalSayilarinToplami
    }

    fun isPrime(girilenSayi: Int): Boolean {
        //Bir sayının asal olup olmadığını ;
        //Kendisine ve 1 e bölünen başka böleni olmayan şeklinde tanımlyorz

       //Asal sayı kontrolleri için while döngüsü kısmında internet destek aldım.

        if (girilenSayi < 2) { // bir sayı 2 den küçükse asal değildir.
            return false
        }
        if (girilenSayi  <=3) { // 2 ve 3 en küçük asal sayılardır.
            return true
        }
        if (girilenSayi % 2 == 0 || girilenSayi % 3 == 0) { // Girilen sayı 2 ve 3 e bölünüyorsa asal değildir.
            return false
        }

        var i = 5
        while (i * i <= girilenSayi) {
            if (girilenSayi % i == 0 || girilenSayi % (i + 2) == 0) {
                return false
            }
            i += 6
        }

        return true
    }
}
