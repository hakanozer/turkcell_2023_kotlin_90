package com.example.esmasalkim_vize_1

class Soru6_Memur(maas: Double) : Soru6_Calisan(maas) {
    val memurEkCarpim =0.3 //Statik değişken tanımladım.Kod içerisinde rakamsal ifadelere yer vermek istemedim.
    //Ana class(Üst class) olan Soru6_Calisan sınıfından özelleştirdiğimiz ve dışarıya açtığımız personel maaş hesaplama çağrıldı.
    override fun personelinAlacagiUcretHesapla(ekSaatler: Double): Double {
        return this.maas +  (ekSaatler * memurEkCarpim)
    }
}

