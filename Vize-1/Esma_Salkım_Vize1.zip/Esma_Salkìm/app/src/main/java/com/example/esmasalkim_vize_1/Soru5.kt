package com.example.esmasalkim_vize_1


class Soru5(sayi: Int) {
    private val girilenSayi: Int

    init {
        if (sayi != null && sayi > 0) {
            girilenSayi = sayi
        } else {
            throw IllegalArgumentException("Lütfen geçerli bir sayı giriniz.")
        }
    }

    fun isPrime (num:Int): Boolean {
        var sonuc = true
        if (num >= 2){
            for ( i in 2..num-1 ){
                if ( num % i == 0){
                    sonuc = false
                    break
                }
            }
        }else{
            sonuc = false
        }
        return sonuc
    }
}
