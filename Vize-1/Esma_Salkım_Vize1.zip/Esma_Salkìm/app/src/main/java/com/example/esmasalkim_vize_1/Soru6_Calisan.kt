package com.example.esmasalkim_vize_1

open class Soru6_Calisan { // Dışardan çağırmak için open ile başladım.
    val maas: Double // Ücret double olması gerekiyor.

    open fun personelinAlacagiUcretHesapla(ekSaatler: Double): Double {
        return maas
    }

    constructor(maas: Double) {
        this.maas = maas
    }


}