package com.example.esmasalkim_vize_1

fun main(args: Array<String>) {
    vizeBirinciSoru()
    vizeİkinciSoru()
    vizeUcuncuSoru()
    vizeDorduncuSoru()
    vizeBesinciSoru()
    vizeAltinciSoru()
}

/*
Not:
•	Aşağıdaki soruları sınıf ve methodlar ile OOP ye uygun olacak şekilde yazınız. Mümkün olan bölümlerde Inheritance, Abstract, Interface, Static anahtar kelimesi kullanınız.
•	Kullanıcıdan veri alımından bahsedilen değişkenler ile değer oluşturmadır.

1.	Kullanıcıdan 4 Haneli Bir Sayı Alıyorsunuz. Bu Sayının Basamaklarının Toplamını Yazdırıyorsunuz

Örnek : String sınıfı özellikleri kullanarak yapabilirsiniz.
Sayı:4356
  4 + 3 + 5 + 6= 18

 */

fun vizeBirinciSoru() {
    // Kullanıcıdan dört basamaklı sayıyı kendim aldım.Ancak kod içerisinde 4 basamaklı olup olmadığını kontrol ettim .
        val kullaniciGirilenSayi = 2323

    //Bir class oluşturarak hem sayının kontrolünü yapıyorum hem de basamak değerlerini döndürüyorum.Soru1 class oluşturuldu.
    // İsimlendirmeler kolaylık olsun diye Soru.. şeklinde yapıldı.
        val islemler = Soru1(kullaniciGirilenSayi)
        val toplam = islemler.basamakToplamiHesapla()
        println("Girmiş olduğunuz " +kullaniciGirilenSayi+  " Sayısının Basamaklarının toplamı: $toplam")

}

/*

2.	Kullanıcıdan 5 Haneli Bir Sayı Alıyorsunuz. Bu Sayının Rakamlarını Tersten Yazdırıyorsunuz Örnek :
Sayı: 14532
 23541

*/

fun vizeİkinciSoru() {
    // Kullanıcıdan beş basamaklı sayıyı kendim aldım.Ancak kod içerisinde 5 basamaklı olup olmadığını kontrol ettim .
    val kullaniciGirilenSayi = 44233

    //Bir class oluşturarak hem sayının kontrolünü yapıyorum hem de sayıyı tersten yazdırıyorum.
    // İsimlendirmeler kolaylık olsun diye Soru.. şeklinde yapıldı.
    val islemler = Soru2(kullaniciGirilenSayi)
    val girilenSayininTersi = islemler.sayininTersiniBul()
    println("Girmiş olduğunuz " +kullaniciGirilenSayi+  " Sayısının Tersi : $girilenSayininTersi")
}

/*
3.	Seri Toplam Kullanıcıdan Bir N Sayısı Alıyorsunuz. 1'den N'e Kadar Aşağıdaki Seriyi Hesaplayan Bir Uygulama Yapın

1 + 1/1! + 2/2! + 3/3! + 4/4! +	+ n/n!

 */

fun vizeUcuncuSoru() {
    // Kullanıcıdan bir sayı aldım .
    val kullaniciGirilenSayi = 3

    //Bir class oluşturarak hem sayının kontrolünü yapıyorum hem de sayıyının faktöriyelini alarak döndürüyorum
    // İsimlendirmeler kolaylık olsun diye Soru.. şeklinde yapıldı.
    val islemler = Soru3(kullaniciGirilenSayi)
    val girilenSayininSonucu = islemler.sayininSeriSonucunuHesapla()
    println("Girmiş olduğunuz " +kullaniciGirilenSayi+  " Sayısının verilen formüle göre sonucu : $girilenSayininSonucu")
}


/*

4.	getSumOfAllPrimes adında bir method olusturun bu methodunuza parametre olarak bir n sayısı gönderin method,
 1'den n'e kadar (n dahil) sayılar arasından, asal sayilari bulup bunların toplamını döndürecek asal sayi bulmak için static boolean
 isPrime(int number) şeklinde ayri bir method oluşturup, getSumOfAllPrimes methodunun içinde uygun şekilde kullanın.
 */


fun vizeDorduncuSoru() {
    // Kullanıcıdan bir sayı aldım .
    val kullaniciGirilenSayi = 23

    //Bir class oluşturarak hem sayının kontrolünü yapıyorum hem de sayıya kadar olan asal sayıları toplamını dönüyoruö.
    // İsimlendirmeler kolaylık olsun diye Soru.. şeklinde yapıldı.
    val islemler = Soru4(kullaniciGirilenSayi)
    val asalSayilarinToplami = islemler.getSumOfAllPrimes(kullaniciGirilenSayi)
    println("Girmiş olduğunuz " +kullaniciGirilenSayi+  " Sayısına kadar olan asal sayıların toplamı : $asalSayilarinToplami")
}
/*
5.	Parametre olarak aldığı sayıyı asal mı diye kontrol edip, sayı asal ise true,
 değilse false döndüren isPrime methodunu yazın.
 */
fun vizeBesinciSoru() {
    // Kullanıcıdan bir sayı aldım .
    val kullaniciGirilenSayi = 23

    //Bir class oluşturarak hem sayının kontrolünü yapıyorum hem de sayının asal olup olmadığını dönüyorum .
    // İsimlendirmeler kolaylık olsun diye Soru.. şeklinde yapıldı.
    var sonuc = "EVET"
    val islemler = Soru5(kullaniciGirilenSayi)
    val sayiAsalMi = islemler.isPrime(kullaniciGirilenSayi)
    // isPrime metodunu direk string dönecek şekilde de yapabilir ve sonucu direk basabilirdim.
    // Kullanıcıya true/false göstermek yerine anlamlı mesaj için kontrol aşağıdadır.
    if(sayiAsalMi){
        sonuc = "EVET ASAL"
    }
    else{
        sonuc = "HAYIR ASAL DEĞİL"
    }
    println("Girmiş olduğunuz " +kullaniciGirilenSayi+  " sayısı asal mı ?   : $sonuc")
}

/*

6.	Personellerin maaşlarını hesaplayan bir uygulama yapmanız beklenmektedir.
 Burada memur çalıştığı ek saat ücreti üzerinden 0.3 müdür 0.6 ve genel müdür 0.8 ile çarpılmakta ve maaşları bu şekilde hesaplanmaktadır.
 Memur: 1000 TL müdür: 3000 TL genel Müdür 5.000 TL maaş almaktadır. Buna göre esnek ek saatlere göre bu çalışanların maaşlarını
 hesaplayacak bir model kurunuz.
 Burada OOP mantığına göre gidilmeli ve inheritance ve polimorfizm teknikleri kullanılmalıdır.

 */

fun vizeAltinciSoru() {
       val memurKokUcret: Double = 1000.0
       val mudurKokUcret: Double = 3000.0
       val genelMudurKokUcret: Double = 5000.0
       val ekSaatler = 3.0


    //Bütün alt classlar çağrıldı ve maaşları ilgili değişkenlere atandı.

        val memur = Soru6_Memur(memurKokUcret)
        val mudur = Soru6_Mudur(mudurKokUcret)
        val genelMudur = Soru6_GenelMudur(genelMudurKokUcret)

        val memurMaas = memur.personelinAlacagiUcretHesapla(ekSaatler)
        val mudurMaas = mudur.personelinAlacagiUcretHesapla(ekSaatler)
        val genelMudurMaas = genelMudur.personelinAlacagiUcretHesapla(ekSaatler)

        println("Garibim Memurun Maaşı: $memurMaas")
        println("Müdürün Maaşı: $mudurMaas")
        println("Genel Müdür Maaşı: $genelMudurMaas")

}





