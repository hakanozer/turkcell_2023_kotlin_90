package com.example.esmasalkim_vize_1



class Soru1(sayi: Int) {
    private val girilenSayi: Int

    init {
        if (sayi != null && sayi.toString().length == 4) {
            girilenSayi = sayi
        } else {
            throw IllegalArgumentException("Lütfen 4 basamaklı bir sayı giriniz. 1000 ile 9999 arasında olmadığı için işleminizi gerçekleştiremiyoruz")
        }
    }

    fun basamakToplamiHesapla(): Int {
        val birler = girilenSayi % 10
        val onlar = (girilenSayi / 10) % 10
        val yuzler = (girilenSayi / 100) % 10
        val binler = girilenSayi / 1000

        return birler + onlar + yuzler + binler
    }
}