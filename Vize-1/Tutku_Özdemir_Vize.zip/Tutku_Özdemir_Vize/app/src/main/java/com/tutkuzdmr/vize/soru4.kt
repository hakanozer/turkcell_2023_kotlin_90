package com.tutkuzdmr.vize

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AsalSayiHesaplama {

    fun isPrime(number: Int): Boolean {
        if (number <= 1) {
            return false
        }
        for (i in 2 until number) {
            if (number % i == 0) {
                return false
            }
        }
        return true
    }

    fun getSumOfAllPrimes(n: Int): Int {
        var toplam = 0
        for (i in 1..n) {
            if (isPrime(i)) {
                toplam += i
            }
        }
        return toplam
    }
}

fun main() {
    val asalSayiHesaplama = AsalSayiHesaplama()
    val n = 17
    val toplamAsal = asalSayiHesaplama.getSumOfAllPrimes(n)
    println("asal sayİ toplami: $toplamAsal")
}