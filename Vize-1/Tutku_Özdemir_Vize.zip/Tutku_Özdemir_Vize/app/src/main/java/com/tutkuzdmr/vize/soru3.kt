package com.tutkuzdmr.vize

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SeriHesaplama(val n: Int) {
    fun faktoriyel(sayi: Int): Long {
        var sonuc: Long = 1
        for (i in 1..sayi) {
            sonuc *= i.toLong()
        }
        return sonuc
    }

    fun hesaplaSeri(): Double {
        var toplam = 0.0
        for (i in 0..n) {
            toplam += (i.toDouble() / faktoriyel(i)).toDouble()
        }
        return toplam
    }
}

fun main() {
    val Girdi = 5
    try {
        val n = Girdi?.toInt()

        if (n != null) {
            val seriHesaplama = SeriHesaplama(n)
            val sonuc = seriHesaplama.hesaplaSeri()
            println("Sonuc= $sonuc")
        } else {
            println("Gecersiz bir sayi girdiniz.")
        }
    } catch (ex: NumberFormatException) {
        println("Gecersiz bir sayi girdiniz.")
    }
}