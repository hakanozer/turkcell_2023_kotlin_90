package com.tutkuzdmr.vize

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class BesBasamakSayi(val sayi: Int) {
    init {
        require(sayi in 10000..99999) {  "5 basamak bir sayi girin." }
    }

    fun tersCevir(): Int {

        var ters = 0
        var kalan = sayi
        repeat(5) {
            val basamak = kalan % 10
            ters = ters * 10 + basamak
            kalan /= 10
        }
        return ters
    }
}

fun main() {

    print("5 basamak sayi girin: ")
    val Girdi = 14532

    try {
        val sayi = Girdi?.toInt()

        if (sayi != null) {
            val besBasamakSayi = BesBasamakSayi(sayi)
            println("Sayı: $sayi")
            println("Tersten : ${besBasamakSayi.tersCevir()}")
        }

        else {

            println("Gecersiz bir sayi girdiniz.")
        }

    } catch (ex: NumberFormatException) {
        println("Geçersiz bir sayı girdiniz.")
    }
}