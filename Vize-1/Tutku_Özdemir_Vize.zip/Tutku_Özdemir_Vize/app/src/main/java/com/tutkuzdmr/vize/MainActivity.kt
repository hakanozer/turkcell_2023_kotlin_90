package com.tutkuzdmr.vize

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DortBasamakSayi(val sayi: Int) {
    init {
        require(sayi in 1000..9999) { "4 basamak bir sayi girin." }
    }

    fun basamaklarToplam(): Int {
        var toplam = 0
        var kalan = sayi
        repeat(4) {
            toplam += kalan % 10
            kalan /= 10
        }
        return toplam
    }
}

fun main() {
    print("4 Basamak sayı girin: ")
    val Girdi = 4356

    try {
        val sayi = Girdi?.toInt()
        if (sayi != null) {
            val dortBasamakSayi = DortBasamakSayi(sayi)
            println("Sayı: $sayi")
            println("Basamakların Toplamı: ${dortBasamakSayi.basamaklarToplam()}")
        } else {
            println("Gecersiz bir sayi girdiniz.")
        }
    } catch (ex: NumberFormatException) {
        println("Gecersiz bir sayi girdiniz.")
    }
}