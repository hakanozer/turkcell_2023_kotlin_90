package com.tutkuzdmr.vize

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

fun isPrime(sayi: Int): Boolean {

    if (sayi <= 1) {
        return false
    }

    for (i in 2 until sayi) {

        if (sayi % i == 0) {
            return false
        }
    }
        return true
}