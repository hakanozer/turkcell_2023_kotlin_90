package com.tutkuzdmr.vize

/*
7.
Class: soyut bir veri tipidir. Ortak özellikleri olan nesnelerin bir araya gelmesiyle oluşur.
Hayvanlar üst sınıfsa sürüngenler alt sınıftır. alt sınıf üst sınıfın özelliklerini taşır ama
başka özellikleri de olabilir. Classlardan object üretip işlemler yaptırırız.

Object: somut bir kavramdır. Classlardan üretilir. Özellik ve davranış sahibidir. Object özellikleri
değişkenlerle hafızada saklanır ve ihtiyaç olduğunda hafızadan çağırılır. Davranışlar için
fonksiyonlar oluşturulur.

Abstract:Kalıtımla alınan özelliklerin türetilen sınıf içinde override edilerek farklı özellikler
kazanabilir. Abstract classın nesnesi oluşturulamaz ve yeni class türetilemez.
Abstract class içi dolu ya da boş fonksiyon alabilir.

Interface: Bir class interface kullanıyorsa conpilera soyut olan fonksiyonları kullanacağını
söyler ve eğer kullanmazsa hata verir.

8.
Erişim belirteçleri bir sınıfın,metodun interface in erişilebilirlik durumunu belirler.

public: kısıtlama yoktur. Başka sınıflar üzerinden bile çağırılabilir. Her yerden erişebiliriz.

private: private tanımlanan bir sınıfa veya metoda sadece tanımlandığı sınıftan ulaşılabilir.

protected: private gibi tanımlandığı sınıftan çağrılır. Ancak tanımlandığı sınıftan türetilmiş
sınıftan da çağrılabilir. Kalıtımla erişmek için kullanılır.

internal:
Aynı paket ismine sahip sınıflarda public gibi çalışır.

 */